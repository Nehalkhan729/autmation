-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: localhost    Database: automation4
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `hibernate_sequence`
--

DROP TABLE IF EXISTS `hibernate_sequence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hibernate_sequence` (
  `next_val` bigint DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hibernate_sequence`
--

LOCK TABLES `hibernate_sequence` WRITE;
/*!40000 ALTER TABLE `hibernate_sequence` DISABLE KEYS */;
INSERT INTO `hibernate_sequence` VALUES (1);
/*!40000 ALTER TABLE `hibernate_sequence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login`
--

DROP TABLE IF EXISTS `login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `login` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role_id` int NOT NULL,
  `CreatedDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `CreatedBy` varchar(255) DEFAULT 'Vaibhav',
  `UpdatedDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `UpdatedBy` varchar(255) DEFAULT 'Vaibhav',
  `retry_pass` varchar(255) DEFAULT NULL,
  `role` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `role_id_idx` (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login`
--

LOCK TABLES `login` WRITE;
/*!40000 ALTER TABLE `login` DISABLE KEYS */;
INSERT INTO `login` VALUES (1,'kiran','123',1,'2024-02-27 05:59:04','Kiran','2024-08-14 09:14:10','Kiran',NULL,'user'),(2,'clover','123',2,'2024-07-29 07:54:55','clover','2024-08-14 09:13:50','clover',NULL,'admin'),(3,'Vaibhav','123',1,'2024-02-27 06:00:06','vaibhav','2024-08-18 06:14:19','vaibhav',NULL,'user'),(4,'Nitin','123',1,'2024-08-18 05:54:06','nitin','2024-08-18 05:54:06','nitin','123','user'),(5,'Afia','123',1,'2024-08-21 06:07:20','Afia','2024-08-21 06:07:20','Afia','123','user');
/*!40000 ALTER TABLE `login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_model_bot_names`
--

DROP TABLE IF EXISTS `login_model_bot_names`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `login_model_bot_names` (
  `login_model_id` bigint NOT NULL,
  `bot_names` varchar(255) DEFAULT NULL,
  KEY `FKtgkm2kkr39c1ptcqa9r22r54s` (`login_model_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_model_bot_names`
--

LOCK TABLES `login_model_bot_names` WRITE;
/*!40000 ALTER TABLE `login_model_bot_names` DISABLE KEYS */;
INSERT INTO `login_model_bot_names` VALUES (9,'TradeQuery'),(10,'PolicyRenewal'),(10,'TradeQuery'),(11,'PolicyRenewal'),(11,'TradeQuery'),(12,'PolicyRenewal'),(12,'TradeQuery');
/*!40000 ALTER TABLE `login_model_bot_names` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_model_department_names`
--

DROP TABLE IF EXISTS `login_model_department_names`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `login_model_department_names` (
  `login_model_id` bigint NOT NULL,
  `department_names` varchar(255) DEFAULT NULL,
  KEY `FK1e7t8i21h27j0vt1fvw01qehx` (`login_model_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_model_department_names`
--

LOCK TABLES `login_model_department_names` WRITE;
/*!40000 ALTER TABLE `login_model_department_names` DISABLE KEYS */;
INSERT INTO `login_model_department_names` VALUES (9,'Sales'),(10,'Sales'),(11,'Sales'),(12,'Sales');
/*!40000 ALTER TABLE `login_model_department_names` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_bot_name`
--

DROP TABLE IF EXISTS `tbl_bot_name`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_bot_name` (
  `bot_id` int NOT NULL AUTO_INCREMENT,
  `bot_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`bot_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_bot_name`
--

LOCK TABLES `tbl_bot_name` WRITE;
/*!40000 ALTER TABLE `tbl_bot_name` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_bot_name` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_botname`
--

DROP TABLE IF EXISTS `tbl_botname`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_botname` (
  `BotId` mediumint NOT NULL AUTO_INCREMENT,
  `BotName` varchar(100) DEFAULT NULL,
  `LocationId` mediumint NOT NULL,
  `DepartmentId` mediumint NOT NULL,
  `CreatedDate` datetime DEFAULT NULL,
  `CreatedBy` varchar(100) DEFAULT NULL,
  `UpdatedDate` datetime DEFAULT NULL,
  `UpdatedBy` varchar(100) DEFAULT NULL,
  `IsActive` tinyint(1) DEFAULT NULL,
  `Duration` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`BotId`),
  KEY `FK_tbl_location` (`LocationId`),
  KEY `FK_tbl_department` (`DepartmentId`),
  CONSTRAINT `FK_tbl_department` FOREIGN KEY (`DepartmentId`) REFERENCES `tbl_department` (`DepartmentId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_tbl_location` FOREIGN KEY (`LocationId`) REFERENCES `tbl_location` (`LocationId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_botname`
--

LOCK TABLES `tbl_botname` WRITE;
/*!40000 ALTER TABLE `tbl_botname` DISABLE KEYS */;
INSERT INTO `tbl_botname` VALUES (1,'Saving',101,3,'2024-03-07 16:11:40','Sakshi','2024-03-07 16:11:40','Priyanka',1,'2'),(2,'TradeQuery',102,2,'2024-06-17 16:09:02','Sakshi','2024-06-17 16:09:02','Priyanka',0,NULL),(3,'policyData',103,1,'2022-08-20 00:00:00','Rahul','2022-09-14 00:00:00','Nitin',1,NULL),(4,'FD',105,3,'2024-02-26 18:36:39','Sakshi','2024-02-26 18:36:39','Priyanka',1,NULL),(5,'RD',107,6,'2024-08-10 19:05:11','Sakshi','2024-08-10 19:05:11','Priyanka',1,NULL),(7,'BOT7',107,26,'2023-06-15 00:00:00','Deepak','2023-06-19 00:00:00','Kiran',1,NULL),(8,'BOT5',105,4,'2024-01-13 00:00:00','Monika','2024-01-18 00:00:00','Kiran',1,NULL),(9,'FD',103,1,'2024-03-11 14:39:39','Sakshi','2024-03-11 14:39:39','Priyanka',1,NULL),(10,'FD',103,1,'2024-08-17 22:03:03','Sakshi','2024-08-17 22:03:03','Priyanka',1,NULL),(11,'Bot3',109,2,'2024-03-13 12:48:03','Sakshi','2024-03-13 12:48:03','Priyanka',1,NULL),(12,'Saving',108,6,'2024-03-14 23:04:44','Sakshi','2024-03-14 23:04:44','Priyanka',0,'2'),(13,'RD',103,1,'2024-03-01 11:31:24','Sakshi','2024-03-01 11:31:24','Priyanka',1,NULL),(14,'BOT6',106,5,'2024-02-14 00:00:00','Vaibhav','2024-02-16 00:00:00','Kiran',0,NULL),(15,'Bot1',103,3,'2024-03-14 23:05:03','Sakshi','2024-03-14 23:05:03','Priyanka',0,'3'),(16,'Bot4',103,1,'2024-03-13 12:45:46','Sakshi','2024-03-13 12:45:46','Priyanka',1,NULL),(17,'Bot13',105,3,'2024-03-14 10:44:43','Sakshi','2024-03-14 10:44:43','Priyanka',1,NULL),(18,'Bot 4',101,1,'2024-03-14 10:45:18','Sakshi','2024-03-14 10:45:18','Priyanka',1,'2'),(19,'Bot5',101,2,'2024-03-14 10:46:37','Sakshi','2024-03-14 10:46:37','Priyanka',1,NULL),(20,'Bot4',103,2,'2024-03-17 20:59:04','Sakshi','2024-03-17 20:59:04','Priyanka',0,NULL),(21,'Bot8',103,5,'2024-03-14 23:00:38','Sakshi','2024-03-14 23:00:38','Priyanka',0,NULL),(22,'Saving',102,2,'2024-03-14 23:50:17','Sakshi','2024-03-14 23:50:17','Priyanka',0,NULL),(23,'BOT5',105,5,'2024-03-14 23:54:13','Sakshi','2024-03-14 23:54:13','Priyanka',0,NULL),(24,'BOT6',105,5,'2024-03-14 23:54:32','Sakshi','2024-03-14 23:54:32','Priyanka',0,NULL),(25,'BOT7',105,5,'2024-03-17 20:59:51','Sakshi','2024-03-17 20:59:51','Priyanka',0,NULL),(26,'BOT8',105,5,'2024-03-17 22:02:03','Sakshi','2024-03-17 22:02:03','Priyanka',1,NULL),(27,'BOT9',105,5,'2024-03-17 22:01:50','Sakshi','2024-03-17 22:01:50','Priyanka',1,NULL),(28,'BOT10',105,5,'2024-03-17 22:01:38','Sakshi','2024-03-17 22:01:38','Priyanka',1,'4'),(29,'BOT11',103,2,'2024-03-17 22:01:23','Sakshi','2024-03-17 22:01:23','Priyanka',1,NULL),(30,'BOT12',119,20,'2023-06-15 00:00:00','Deepak','2023-06-19 00:00:00','Kiran',1,NULL),(31,'BOT13',121,21,'2023-06-15 00:00:00','Deepak','2023-06-19 00:00:00','Kiran',1,NULL),(32,'BOT14',127,17,'2023-06-15 00:00:00','Deepak','2023-06-19 00:00:00','Kiran',1,NULL),(33,'BOT15',130,35,'2023-06-15 00:00:00','Deepak','2023-06-19 00:00:00','Kiran',1,NULL),(34,'BOT16',106,16,'2023-06-15 00:00:00','Deepak','2023-06-19 00:00:00','Kiran',1,NULL),(35,'BOT17',107,26,'2023-06-15 00:00:00','Deepak','2023-06-19 00:00:00','Kiran',1,NULL),(46,'bot18',102,2,'2024-04-10 15:31:54','Sakshi','2024-04-10 15:31:54','Priyanka',0,'2'),(47,'bot19',101,1,'2024-04-10 15:35:55','Sakshi','2024-04-10 15:35:55','Priyanka',0,'4'),(48,'Bot4',106,19,'2024-04-10 15:42:35','Sakshi','2024-04-10 15:42:35','Priyanka',0,'2');
/*!40000 ALTER TABLE `tbl_botname` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_department`
--

DROP TABLE IF EXISTS `tbl_department`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_department` (
  `DepartmentId` mediumint NOT NULL AUTO_INCREMENT,
  `DepartmentName` varchar(100) DEFAULT NULL,
  `CreatedDate` datetime DEFAULT NULL,
  `CreatedBy` varchar(100) DEFAULT NULL,
  `UpdatedDate` datetime DEFAULT NULL,
  `UpdatedBy` varchar(100) DEFAULT NULL,
  `IsActive` tinyint(1) DEFAULT NULL,
  `department_id` int NOT NULL,
  `department_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`DepartmentId`)
) ENGINE=InnoDB AUTO_INCREMENT=109 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_department`
--

LOCK TABLES `tbl_department` WRITE;
/*!40000 ALTER TABLE `tbl_department` DISABLE KEYS */;
INSERT INTO `tbl_department` VALUES (1,'Coe','2022-10-01 00:00:00','Priyanka','2022-11-01 00:00:00','Sakshi',1,0,NULL),(2,'Sales','2022-09-17 00:00:00','Nitin','2022-08-05 00:00:00','Rahul',0,0,NULL),(3,'Finance','2022-08-15 00:00:00','Alisha','2022-09-20 00:00:00','Pooja',1,0,NULL),(4,'Hr','2022-08-15 00:00:00','Vaibhav','2022-09-20 00:00:00','Mangesh',1,0,NULL),(5,'Production','2022-08-15 00:00:00','Vaibhav','2022-09-20 00:00:00','Mangesh',1,0,NULL),(6,'Test','2024-03-13 07:24:43','Sakshi','2024-03-13 07:24:43','Sakshi',1,6,NULL),(7,'Bussines','2023-10-01 00:00:00','Monika','2023-11-01 00:00:00','Kiran',0,4,NULL),(8,'Thane','2024-02-26 10:24:10','Sakshi','2024-02-26 10:24:10','Sakshi',1,6,NULL),(9,'Development','2023-11-01 00:00:00','Megha','2023-11-01 00:00:00','Chinmay',1,4,NULL),(10,'Development','2024-02-01 00:00:00','Omkar','2024-02-01 00:00:00','Ritesh',1,1,NULL),(11,'Oracle','2023-11-01 00:00:00','Deepak','2023-11-01 00:00:00','Chinmay',0,2,NULL),(12,'HR','2023-10-01 00:00:00','Ankita','2023-10-01 00:00:00','Kiran',1,3,NULL),(13,'Middle-wear','2023-07-01 00:00:00','Vaibhav','2023-07-01 00:00:00','Amit',0,4,NULL),(14,'Backend','2023-05-01 00:00:00','Sayali','2023-05-01 00:00:00','Chinmay',1,5,NULL),(15,'Mechanical','2024-03-13 08:47:08','Sakshi','2024-03-13 08:47:08','Sakshi',1,6,NULL),(16,'SocialMedia','2024-03-13 11:26:25','Sakshi','2024-03-13 11:26:25','Sakshi',1,6,NULL),(17,'SocialMedia','2024-03-14 05:34:09','Sakshi','2024-03-14 05:34:09','Sakshi',1,6,NULL),(18,'Learning','2024-03-13 17:43:59','Sakshi','2024-03-13 17:43:59','Sakshi',1,6,NULL),(19,'Marketing','2023-11-01 00:00:00','Shiv','2023-11-01 00:00:00','Aishwarya',0,8,NULL),(20,'Electric','2024-03-14 14:50:03','Sakshi','2024-03-14 14:50:03','Sakshi',1,6,NULL),(21,'Computer','2024-03-17 16:27:42','Sakshi','2024-03-17 16:27:42','Sakshi',1,6,NULL),(22,'Instrument','2024-03-14 14:51:41','Sakshi','2024-03-14 14:51:41','Sakshi',1,6,NULL),(23,'Matching','2024-03-17 15:27:34','Sakshi','2024-03-17 15:27:34','Sakshi',0,6,NULL),(24,'Production','2023-11-01 00:00:00','Payal','2023-11-01 00:00:00','Chinmay',0,8,NULL),(25,'HR','2023-11-01 00:00:00','Kartik','2023-11-01 00:00:00','Kiran',0,8,NULL),(26,'Sales','2023-11-01 00:00:00','Dhruv','2023-11-01 00:00:00','Chinmay',0,8,NULL),(27,'Middleware','2023-11-01 00:00:00','Kiran','2023-11-01 00:00:00','Vaibhav',0,8,NULL),(28,'Oracle','2023-11-01 00:00:00','Aishwarya','2023-11-01 00:00:00','Chinmay',0,8,NULL),(29,'Sales','2023-11-01 00:00:00','Omakr','2023-11-01 00:00:00','Kiran',0,8,NULL),(30,'Packaging','2023-11-01 00:00:00','om','2023-11-01 00:00:00','Sakshi',0,8,NULL),(31,'Dispatch','2023-11-01 00:00:00','Parag','2023-11-01 00:00:00','Chinmay',0,8,NULL),(32,'Content','2023-11-01 00:00:00','Tushar','2023-11-01 00:00:00','khalid',0,8,NULL),(34,'Deveops','2023-11-01 00:00:00','Aishwarya','2023-11-01 00:00:00','khalid',0,8,NULL),(35,'Sales','2023-11-01 00:00:00','Amey','2023-11-01 00:00:00','khalid',0,8,NULL);
/*!40000 ALTER TABLE `tbl_department` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_location`
--

DROP TABLE IF EXISTS `tbl_location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_location` (
  `LocationId` mediumint NOT NULL AUTO_INCREMENT,
  `LocationName` varchar(100) DEFAULT NULL,
  `CreatedDate` datetime DEFAULT NULL,
  `CreatedBy` varchar(100) DEFAULT NULL,
  `UpdatedDate` datetime DEFAULT NULL,
  `UpdatedBy` varchar(100) DEFAULT NULL,
  `IsActive` tinyint(1) DEFAULT NULL,
  `id` int NOT NULL,
  `location_name` varchar(255) DEFAULT NULL,
  `location_id` int NOT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `is_active` bit(1) DEFAULT NULL,
  `updated_by` varchar(255) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  PRIMARY KEY (`LocationId`)
) ENGINE=InnoDB AUTO_INCREMENT=272 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_location`
--

LOCK TABLES `tbl_location` WRITE;
/*!40000 ALTER TABLE `tbl_location` DISABLE KEYS */;
INSERT INTO `tbl_location` VALUES (101,'Andheri','2024-08-17 22:37:39','Sakshi','2024-08-17 22:37:39','Sakshi',0,0,NULL,101,NULL,NULL,NULL,NULL,NULL),(102,'Panvel','2021-10-05 00:00:00','Pooja','2021-11-15 00:00:00','Neha',1,0,NULL,0,NULL,NULL,NULL,NULL,NULL),(103,'Kurla','2022-08-10 00:00:00','Rahul','2022-09-15 00:00:00','Nitin',1,0,NULL,0,NULL,NULL,NULL,NULL,NULL),(105,'Kharghar','2022-11-11 05:00:00','Aditi','2022-11-25 11:15:00','Manali',0,0,NULL,0,NULL,NULL,NULL,NULL,NULL),(106,'Latur','2024-03-11 16:28:51','Sakshi','2024-03-11 16:28:51','Sakshi',1,6,NULL,106,NULL,NULL,NULL,NULL,NULL),(107,'Aeroli','2024-02-22 10:23:34','Sakshi','2024-02-22 10:23:34','Sakshi',1,6,NULL,1,NULL,NULL,NULL,NULL,NULL),(108,'Vashi','2024-02-26 04:27:18','Sakshi','2024-02-26 04:27:18','Sakshi',1,6,NULL,1,NULL,NULL,NULL,NULL,NULL),(109,'Aeroli','2024-02-26 09:55:52','Sakshi','2024-02-26 09:55:52','Sakshi',1,6,NULL,1,NULL,NULL,NULL,NULL,NULL),(110,'Solapur','2024-03-17 21:28:25','Sakshi','2024-03-17 21:28:25','Sakshi',1,6,NULL,110,NULL,NULL,NULL,NULL,NULL),(111,'solapur','2024-03-01 06:00:58','Sakshi','2024-03-01 06:00:58','Sakshi',1,6,NULL,1,NULL,NULL,NULL,NULL,NULL),(112,'Nagpur','2023-04-11 00:00:00','Shivani','2023-04-12 00:00:00','aishwarya',0,5,NULL,0,NULL,NULL,NULL,NULL,NULL),(113,'Chandrapur','2023-05-17 00:00:00','Megha','2023-05-18 00:00:00','aishwarya',0,5,NULL,0,NULL,NULL,NULL,NULL,NULL),(114,'Belapur','2024-03-17 21:49:20','Sakshi','2024-03-17 21:49:20','Sakshi',0,6,NULL,114,NULL,NULL,NULL,NULL,NULL),(115,'Satara','2024-03-14 14:48:12','Sakshi','2024-03-14 14:48:12','Sakshi',1,6,NULL,1,NULL,NULL,NULL,NULL,NULL),(116,'Parbhani','2024-03-17 13:57:18','Sakshi','2024-03-17 13:57:18','Sakshi',1,6,NULL,1,NULL,NULL,NULL,NULL,NULL),(117,'Beed','2024-03-17 21:50:13','Sakshi','2024-03-17 21:50:13','Sakshi',1,6,NULL,117,NULL,NULL,NULL,NULL,NULL),(118,'Nanded','2024-03-17 21:50:26','Sakshi','2024-03-17 21:50:26','Sakshi',1,6,NULL,118,NULL,NULL,NULL,NULL,NULL),(119,'Badlapur','2023-08-17 00:00:00','Kajol','2023-08-22 00:00:00','aishwarya',0,5,NULL,0,NULL,NULL,NULL,NULL,NULL),(120,'Bhandup','2023-05-17 00:00:00','Pratik','2023-05-18 00:00:00','aishwarya',0,5,NULL,0,NULL,NULL,NULL,NULL,NULL),(121,'Malabar Hill','2024-01-17 00:00:00','Spandhan','2024-01-18 00:00:00','aishwarya',0,5,NULL,0,NULL,NULL,NULL,NULL,NULL),(122,'Bhuleshwar','2024-01-19 00:00:00','Naya','0202-01-20 00:00:00','aishwarya',0,5,NULL,0,NULL,NULL,NULL,NULL,NULL),(123,'Ambivali','2023-06-17 00:00:00','Ishaan','2023-06-18 00:00:00','aishwarya',0,5,NULL,0,NULL,NULL,NULL,NULL,NULL),(124,'Byculla','2023-07-15 00:00:00','Kanan','2023-07-18 00:00:00','aishwarya',0,5,NULL,0,NULL,NULL,NULL,NULL,NULL),(125,'Dharavi','2023-08-21 00:00:00','Atharv','2023-08-22 00:00:00','aishwarya',0,5,NULL,0,NULL,NULL,NULL,NULL,NULL),(126,'Juhu','2023-09-13 00:00:00','Navi','2023-09-15 00:00:00','aishwarya',0,5,NULL,0,NULL,NULL,NULL,NULL,NULL),(128,'Chembur','2023-11-14 00:00:00','Aarna','2023-11-16 00:00:00','aishwarya',0,5,NULL,0,NULL,NULL,NULL,NULL,NULL),(129,'Behram Baug','2023-12-17 00:00:00','Amar','2023-12-18 00:00:00','aishwarya',0,5,NULL,0,NULL,NULL,NULL,NULL,NULL),(130,'Bharam Nagar','2024-01-06 00:00:00','Agastya','2024-01-08 00:00:00','aishwarya',0,5,NULL,0,NULL,NULL,NULL,NULL,NULL),(131,'Ambujwadi','2024-01-09 00:00:00','Nila','2024-01-11 00:00:00','aishwarya',0,5,NULL,0,NULL,NULL,NULL,NULL,NULL),(132,'Seawoods','2024-02-03 00:00:00','Tenzin','2024-02-05 00:00:00','aishwarya',0,5,NULL,0,NULL,NULL,NULL,NULL,NULL),(133,'Seven Bungalows','2024-02-07 00:00:00','Aditi','2024-02-09 00:00:00','aishwarya',0,5,NULL,0,NULL,NULL,NULL,NULL,NULL),(134,'Taloja','2024-02-14 00:00:00','Ananya','2024-02-18 00:00:00','aishwarya',0,5,NULL,0,NULL,NULL,NULL,NULL,NULL),(135,'Kamothe','2024-02-17 00:00:00','Ambar','2024-02-18 00:00:00','aishwarya',0,5,NULL,0,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `tbl_location` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_real_time_data`
--

DROP TABLE IF EXISTS `tbl_real_time_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_real_time_data` (
  `process_id` int NOT NULL AUTO_INCREMENT,
  `bot_id` int NOT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `department_id` int NOT NULL,
  `end_time` date DEFAULT NULL,
  `host_name` varchar(255) DEFAULT NULL,
  `is_active` bit(1) NOT NULL,
  `location_id` int NOT NULL,
  `process_name` varchar(255) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `start_time` date DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `transaction_id` int NOT NULL,
  `updated_by` varchar(255) DEFAULT NULL,
  `updated_date` date DEFAULT NULL,
  PRIMARY KEY (`process_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_real_time_data`
--

LOCK TABLES `tbl_real_time_data` WRITE;
/*!40000 ALTER TABLE `tbl_real_time_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_real_time_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_realtimedata`
--

DROP TABLE IF EXISTS `tbl_realtimedata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_realtimedata` (
  `ProcessId` mediumint NOT NULL AUTO_INCREMENT,
  `BotId` mediumint NOT NULL,
  `DepartmentId` mediumint NOT NULL,
  `LocationId` mediumint NOT NULL,
  `Process_Name` varchar(100) DEFAULT NULL,
  `Host_Name` varchar(100) DEFAULT NULL,
  `Transaction_ID` mediumint NOT NULL,
  `StartTime` datetime DEFAULT NULL,
  `EndTime` datetime DEFAULT NULL,
  `Status` varchar(100) DEFAULT NULL,
  `Remarks` varchar(100) DEFAULT NULL,
  `CreatedDate` datetime DEFAULT NULL,
  `CreatedBy` varchar(100) DEFAULT NULL,
  `UpdatedDate` datetime DEFAULT NULL,
  `UpdatedBy` varchar(100) DEFAULT NULL,
  `IsActive` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`ProcessId`),
  KEY `FK_tbl_botname` (`BotId`),
  KEY `FK_tbl_department1` (`DepartmentId`),
  KEY `FK_tbl_location1` (`LocationId`),
  CONSTRAINT `FK_tbl_botname` FOREIGN KEY (`BotId`) REFERENCES `tbl_botname` (`BotId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_tbl_department1` FOREIGN KEY (`DepartmentId`) REFERENCES `tbl_department` (`DepartmentId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_tbl_location1` FOREIGN KEY (`LocationId`) REFERENCES `tbl_location` (`LocationId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1707 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_realtimedata`
--

LOCK TABLES `tbl_realtimedata` WRITE;
/*!40000 ALTER TABLE `tbl_realtimedata` DISABLE KEYS */;
INSERT INTO `tbl_realtimedata` VALUES (1,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2022-10-15 11:30:00','2022-10-15 02:00:00','processed','success','2022-10-10 11:00:00','Kashmeera','2022-11-20 12:02:00','Mansi',1),(2,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2022-10-15 11:30:00','2022-10-15 02:00:00','Unprocessed','success','2022-10-10 11:00:00','Kashmeera','2022-11-20 12:02:00','Mansi',1),(3,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2022-10-15 11:30:00','2022-10-15 02:00:00','processed','success','2022-10-10 11:00:00','Kashmeera','2022-11-20 12:02:00','Mansi',1),(4,2,2,102,'Motor fleet Process','PriyankaYadav',211,'2022-10-15 11:30:00','2022-10-15 02:00:00','processed','success','2022-10-10 11:00:00','Kashmeera','2022-11-20 12:02:00','Mansi',1),(5,3,3,103,'Motor fleet Process','PriyankaYadav',211,'2022-10-15 11:30:00','2022-10-15 02:00:00','processed','success','2022-10-10 11:00:00','Kashmeera','2022-11-20 12:02:00','Mansi',1),(6,1,4,103,'Account closure process','Aishwarya',211,'2023-10-15 11:30:00','2023-10-15 02:00:00','processed','success','2023-10-10 11:00:00','Kashmeera','2023-11-20 12:02:00','Admin',1),(7,4,3,105,'Bank Reconciliation','Shivani',211,'2024-01-15 11:30:00','2024-01-15 02:00:00','Unprocessed','success','2024-01-10 11:00:00','Kashmeera','2024-01-22 12:02:00','Admin',1),(8,2,2,102,'Accounts payable','Monika',211,'2023-10-15 11:30:00','2023-10-15 02:00:00','processed','success','2023-10-10 11:00:00','Kashmeera','2023-11-20 12:02:00','Admin',1),(9,2,2,102,'Mortgage processing','Akshay',211,'2024-02-15 11:30:00','2024-02-15 02:00:00','processed','Unprocessed','2024-02-10 11:00:00','Kashmeera','2024-02-21 12:02:00','Admin',1),(10,3,3,109,'Bank Reconciliation','Cinmay',211,'2023-10-15 11:30:00','2023-10-15 02:00:00','processed','Unprocessed','2023-10-10 11:00:00','Kashmeera','2023-11-21 12:02:00','Admin',1),(11,5,6,107,'Accounts payable','Monika',211,'2024-02-15 11:30:00','2024-02-15 02:00:00','processed','success','2023-10-10 11:00:00','Kashmeera','2023-11-20 12:02:00','Admin',1),(12,9,8,108,'Credit card application processing','Akshay',211,'2023-02-15 11:30:00','2023-02-15 02:00:00','processed','Unprocessed','2024-02-10 11:00:00','Kashmeera','2024-02-21 12:02:00','Admin',1),(13,10,5,109,'Bank Reconciliation','Cinmay',211,'2024-10-15 11:30:00','2024-10-15 02:00:00','processed','Unprocessed','2023-10-10 11:00:00','Kashmeera','2023-11-21 12:02:00','Admin',1),(15,9,9,109,'Motor ','Deepak',213,'2024-01-15 11:30:00','2024-01-15 02:00:00','Unprocessed','unsuccess','2024-01-15 11:00:00','Kashmira','2024-01-15 12:02:00','Admin',1),(16,21,21,121,'Motor fleet Process','PriyankaYadav',211,'2022-10-15 11:30:00','2022-10-15 02:00:00','processed','success','2022-10-10 11:00:00','Kashmeera','2022-11-20 12:02:00','Mansi',1),(17,10,10,110,'Debit-card ','Sandesh',213,'2024-02-15 11:30:00','2024-02-18 02:00:00','Unprocessed','unsuccess','2024-02-15 11:00:00','gayatri','2024-02-18 12:02:00','Admin',1),(18,2,2,102,'Sales ','Amit',213,'2023-06-15 11:30:00','2023-06-22 02:00:00','Unprocessed','unsuccess','2023-06-15 11:00:00','gayatri','2023-06-22 12:02:00','Admin',1),(19,21,21,121,'Motor ','Amit',213,'2023-06-15 11:30:00','2023-06-22 02:00:00','processed','unsuccess','2023-06-15 11:00:00','gayatri','2023-06-22 12:02:00','Admin',1),(20,18,18,129,'Sales ','Amit',213,'2023-06-15 11:30:00','2023-06-22 02:00:00','processed','unsuccess','2023-06-15 11:00:00','gayatri','2023-06-22 12:02:00','Admin',1),(21,11,12,130,'Accounts payable ','Amit',213,'2023-06-15 11:30:00','2023-06-22 02:00:00','processed','unsuccess','2023-06-15 11:00:00','gayatri','2023-06-22 12:02:00','Admin',1),(22,16,16,126,'Sales ','Amit',213,'2023-06-15 11:30:00','2023-06-22 02:00:00','processed','unsuccess','2023-06-15 11:00:00','gayatri','2023-06-22 12:02:00','Admin',1),(24,14,14,114,'Debit-card ','Amit',213,'2023-06-15 11:30:00','2023-06-22 02:00:00','Unprocessed','unsuccess','2023-06-15 11:00:00','gayatri','2023-06-22 12:02:00','Admin',1),(25,35,35,135,'Bank Reconciliation ','Amit',213,'2023-06-15 11:30:00','2023-06-22 02:00:00','Unprocessed','unsuccess','2023-06-15 11:00:00','gayatri','2023-06-22 12:02:00','Admin',1),(26,18,28,132,'Sales ','Amit',213,'2023-06-15 11:30:00','2023-06-22 02:00:00','processed','unsuccess','2023-06-15 11:00:00','gayatri','2023-06-22 12:02:00','Admin',1),(27,7,9,109,'Bank Reconciliation ','Amit',213,'2023-06-15 11:30:00','2023-06-22 02:00:00','Unprocessed','unsuccess','2023-06-15 11:00:00','gayatri','2023-06-22 12:02:00','Admin',1),(28,18,28,132,'Bank Reconciliation ','Amit',213,'2023-06-15 11:30:00','2023-06-22 02:00:00','processed','unsuccess','2023-06-15 11:00:00','gayatri','2023-06-22 12:02:00','Admin',1),(29,7,9,109,'Sales ','Amit',213,'2023-06-15 11:30:00','2023-06-22 02:00:00','Unprocessed','unsuccess','2023-06-15 11:00:00','gayatri','2023-06-22 12:02:00','Admin',1),(30,18,28,132,'Debit-card ','Amit',213,'2023-06-15 11:30:00','2023-06-22 02:00:00','Unprocessed','unsuccess','2023-06-15 11:00:00','gayatri','2023-06-22 12:02:00','Admin',1),(31,11,12,130,'Motor ','Amit',213,'2023-06-15 11:30:00','2023-06-22 02:00:00','Unprocessed','unsuccess','2023-06-15 11:00:00','gayatri','2023-06-22 12:02:00','Admin',1),(32,7,9,109,'Sales ','Amit',213,'2023-06-15 11:30:00','2023-06-22 02:00:00','processed','unsuccess','2023-06-15 11:00:00','gayatri','2023-06-22 12:02:00','Admin',1),(33,20,20,120,'Bank Reconciliation ','Amit',213,'2023-06-15 11:30:00','2023-06-22 02:00:00','Unprocessed','unsuccess','2023-06-15 11:00:00','gayatri','2023-06-22 12:02:00','Admin',1),(34,11,12,130,'Bank Reconciliation ','Amit',213,'2023-06-15 11:30:00','2023-06-22 02:00:00','Unprocessed','unsuccess','2023-06-15 11:00:00','gayatri','2023-06-22 12:02:00','Admin',1),(35,35,35,135,'Debit-card ','Amit',213,'2023-06-15 11:30:00','2023-06-22 02:00:00','Unprocessed','unsuccess','2023-06-15 11:00:00','gayatri','2023-06-22 12:02:00','Admin',1),(36,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-05-30 15:20:27','2024-05-30 15:20:27','processed','success','2024-05-30 15:20:27','Kashmeera','2024-05-30 15:20:27','Mansi',1),(37,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-05-30 15:20:27','2024-05-30 15:20:27','Unprocessed','success','2024-05-30 15:20:27','Kashmeera','2024-05-30 15:20:27','Mansi',2),(38,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-05-30 15:20:27','2024-05-30 15:20:27','processed','success','2024-05-30 15:20:27','Kashmeera','2024-05-30 15:20:27','Mansi',3),(39,2,2,102,'Motor fleet Process','PriyankaYadav',211,'2024-05-30 15:20:27','2024-05-30 15:20:27','processed','success','2024-05-30 15:20:27','Kashmeera','2024-05-30 15:20:27','Mansi',4),(40,2,2,102,'Motor fleet Process','PriyankaYadav',211,'2024-05-30 15:20:27','2024-05-30 15:20:27','processed','success','2024-05-30 15:20:27','Kashmeera','2024-05-30 15:20:27','Mansi',5),(41,2,2,102,'Account closure process','Aishwarya',211,'2024-05-30 15:20:27','2024-05-30 15:20:27','processed','success','2024-05-30 15:20:27','Kashmeera','2024-05-30 15:20:27','Admin',6),(42,2,2,102,'Bank Reconciliation','Shivani',211,'2024-05-30 15:20:27','2024-05-30 15:20:27','Unprocessed','success','2024-05-30 15:20:27','Kashmeera','2024-05-30 15:20:27','Admin',7),(43,3,3,103,'Accounts payable','Monika',211,'2024-05-30 15:20:27','2024-05-30 15:20:27','processed','success','2024-05-30 15:20:27','Kashmeera','2024-05-30 15:20:27','Admin',8),(44,3,3,103,'Mortgage processing','Akshay',211,'2024-05-30 15:20:27','2024-05-30 15:20:27','processed','Unprocessed','2024-05-30 15:20:27','Kashmeera','2024-05-30 15:20:27','Admin',9),(45,3,3,103,'Bank Reconciliation','Cinmay',211,'2024-05-30 15:20:27','2024-05-30 15:20:27','processed','Unprocessed','2024-05-30 15:20:27','Kashmeera','2024-05-30 15:20:27','Admin',10),(46,3,3,103,'Accounts payable','Monika',211,'2024-05-30 15:20:27','2024-05-30 15:20:27','processed','success','2024-05-30 15:20:27','Kashmeera','2024-05-30 15:20:27','Admin',11),(47,3,3,103,'Credit card application processing','Akshay',211,'2024-05-30 15:20:27','2024-05-30 15:20:27','processed','Unprocessed','2024-05-30 15:20:27','Kashmeera','2024-05-30 15:20:27','Admin',12),(48,3,3,103,'Bank Reconciliation','Cinmay',211,'2024-05-30 15:20:27','2024-05-30 15:20:27','processed','Unprocessed','2024-05-30 15:20:27','Kashmeera','2024-05-30 15:20:27','Admin',13),(49,3,3,103,'Motor','Deepak',213,'2024-05-30 15:20:27','2024-05-30 15:20:27','Unprocessed','unsuccess','2024-05-30 15:20:27','Kashmira','2024-05-30 15:20:27','Admin',15),(50,10,10,110,'Motor fleet Process','PriyankaYadav',211,'2024-05-30 15:20:27','2024-05-30 15:20:27','processed','success','2024-05-30 15:20:27','Kashmeera','2024-05-30 15:20:27','Mansi',16),(51,10,10,110,'Debit-card','Sandesh',213,'2024-05-30 15:20:27','2024-05-30 15:20:27','Unprocessed','unsuccess','2024-05-30 15:20:27','gayatri','2024-05-30 15:20:27','Admin',17),(52,10,10,110,'Sales','Amit',213,'2024-05-30 15:20:27','2024-05-30 15:20:27','Unprocessed','unsuccess','2024-05-30 15:20:27','gayatri','2024-05-30 15:20:27','Admin',18),(53,10,10,110,'Motor','Amit',213,'2024-05-30 15:20:28','2024-05-30 15:20:28','processed','unsuccess','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',19),(54,10,10,110,'Sales','Amit',213,'2024-05-30 15:20:28','2024-05-30 15:20:28','processed','unsuccess','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',20),(55,10,10,110,'Accounts payable','Amit',213,'2024-05-30 15:20:28','2024-05-30 15:20:28','processed','unsuccess','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',21),(56,10,10,110,'Sales','Amit',213,'2024-05-30 15:20:28','2024-05-30 15:20:28','processed','unsuccess','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',22),(57,10,10,110,'Debit-card','Amit',213,'2024-05-30 15:20:28','2024-05-30 15:20:28','Unprocessed','unsuccess','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',24),(58,10,10,110,'Bank Reconciliation','Amit',213,'2024-05-30 15:20:28','2024-05-30 15:20:28','Unprocessed','unsuccess','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',25),(59,10,10,110,'Sales','Amit',213,'2024-05-30 15:20:28','2024-05-30 15:20:28','processed','unsuccess','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',26),(60,10,10,110,'Bank Reconciliation','Amit',213,'2024-05-30 15:20:28','2024-05-30 15:20:28','Unprocessed','unsuccess','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',27),(61,5,5,105,'Bank Reconciliation','Amit',213,'2024-05-30 15:20:28','2024-05-30 15:20:28','processed','unsuccess','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',28),(62,5,5,105,'Sales','Amit',213,'2024-05-30 15:20:28','2024-05-30 15:20:28','Unprocessed','unsuccess','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',29),(63,5,5,105,'Debit-card','Amit',213,'2024-05-30 15:20:28','2024-05-30 15:20:28','Unprocessed','unsuccess','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',30),(64,5,5,105,'Motor','Amit',213,'2024-05-30 15:20:28','2024-05-30 15:20:28','Unprocessed','unsuccess','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',31),(65,5,5,105,'Sales','Amit',213,'2024-05-30 15:20:28','2024-05-30 15:20:28','processed','unsuccess','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',32),(66,5,5,105,'Bank Reconciliation','Amit',213,'2024-05-30 15:20:28','2024-05-30 15:20:28','Unprocessed','unsuccess','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',33),(67,5,5,105,'Bank Reconciliation','Amit',213,'2024-05-30 15:20:28','2024-05-30 15:20:28','Unprocessed','unsuccess','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',34),(68,15,15,115,'Debit-card','Amit',213,'2024-05-30 15:20:28','2024-05-30 15:20:28','Unprocessed','unsuccess','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',35),(69,1,1,101,'Motor fleet Process','aiswarya',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','Unprocessed','unsuccess','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',36),(70,1,1,101,'Motor fleet Process','aiswarya',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','Unprocessed','unsuccess','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',37),(71,1,1,101,'Motor fleet Process','aiswarya',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','processed','success','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',38),(72,1,1,101,'Motor fleet Process','aiswarya',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','processed','success','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',39),(73,1,1,101,'Motor fleet Process','aiswarya',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','processed','success','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',40),(74,2,2,102,'Account closure process','aiswarya',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','processed','success','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',41),(75,2,2,102,'Bank Reconciliation','aiswarya',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','processed','success','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',42),(76,2,2,102,'Accounts payable','aiswarya',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','processed','success','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',43),(77,2,2,102,'Mortgage processing','aiswarya',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','processed','success','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',44),(78,3,3,103,'Bank Reconciliation','aiswarya',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','processed','success','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',45),(79,3,3,103,'Accounts payable','aiswarya',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','processed','success','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',46),(80,3,3,103,'Credit card application processing','aiswarya',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','processed','success','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',47),(81,3,3,103,'Bank Reconciliation','aiswarya',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','processed','success','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',48),(82,3,3,103,'Motor fleet Process','aiswarya',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','Unprocessed','unsuccess','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',49),(83,3,3,103,'Motor ','aiswarya',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','Unprocessed','unsuccess','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',50),(84,3,3,103,'Motor fleet Process','aiswarya',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','Unprocessed','unsuccess','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',51),(85,10,10,110,'Debit-card ','aiswarya',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','Unprocessed','unsuccess','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',52),(86,10,10,110,'Sales ','aiswarya',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','Unprocessed','unsuccess','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',53),(87,10,10,110,'Motor ','aiswarya',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','Unprocessed','unsuccess','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',54),(88,10,10,110,'Sales ','aiswarya',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','processed','success','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',55),(89,10,10,110,'Accounts payable ','aiswarya',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','processed','success','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',56),(90,10,10,110,'Sales ','aiswarya',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','processed','success','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',57),(91,10,10,110,'Debit-card ','aiswarya',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','processed','success','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',58),(92,10,10,110,'Bank Reconciliation ','aiswarya',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','Unprocessed','unsuccess','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',59),(93,10,10,110,'Sales ','chinmay',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','Unprocessed','unsuccess','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',60),(94,10,10,110,'Bank Reconciliation ','chinmay',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','Unprocessed','unsuccess','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',61),(95,10,10,110,'Bank Reconciliation ','chinmay',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','Unprocessed','unsuccess','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',62),(96,5,5,105,'Sales ','chinmay',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','Unprocessed','unsuccess','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',63),(97,5,5,105,'Debit-card ','chinmay',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','Unprocessed','unsuccess','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',64),(98,5,5,105,'Motor ','chinmay',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','Unprocessed','unsuccess','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',65),(99,5,5,105,'Sales ','chinmay',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','Unprocessed','unsuccess','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',66),(100,5,5,105,'Bank Reconciliation ','chinmay',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','processed','success','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',67),(101,5,5,105,'Bank Reconciliation ','chinmay',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','processed','success','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',68),(102,5,5,105,'Debit-card ','chinmay',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','processed','success','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',69),(103,15,15,115,'Motor fleet Process','chinmay',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','processed','success','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',70),(104,15,15,115,'Motor fleet Process','chinmay',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','processed','success','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',71),(105,15,15,115,'Motor fleet Process','chinmay',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','processed','success','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',72),(106,15,15,115,'Motor fleet Process','chinmay',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','Unprocessed','unsuccess','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',73),(107,15,15,115,'Motor fleet Process','chinmay',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','Unprocessed','unsuccess','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',74),(108,15,15,115,'Account closure process','chinmay',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','Unprocessed','unsuccess','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',75),(109,12,12,112,'Bank Reconciliation','chinmay',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','Unprocessed','unsuccess','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',76),(110,12,12,112,'Accounts payable','chinmay',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','Unprocessed','unsuccess','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',77),(111,12,12,112,'Mortgage processing','chinmay',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','Unprocessed','unsuccess','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',78),(112,12,12,112,'Bank Reconciliation','chinmay',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','Unprocessed','unsuccess','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',79),(113,12,12,112,'Accounts payable','chinmay',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','processed','success','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',80),(114,20,20,120,'Credit card application processing','chinmay',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','processed','success','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',81),(115,20,20,120,'Bank Reconciliation','chinmay',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','processed','success','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',82),(116,20,20,120,'Motor fleet Process','chinmay',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','processed','success','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',83),(117,20,20,120,'Motor ','chinmay',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','processed','success','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',84),(118,20,20,120,'Motor fleet Process','chinmay',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','processed','success','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',85),(119,20,20,120,'Debit-card ','chinmay',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','Unprocessed','unsuccess','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',86),(120,20,20,120,'Sales ','chinmay',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','Unprocessed','unsuccess','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',87),(121,35,35,135,'Motor ','chinmay',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','Unprocessed','unsuccess','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',88),(122,35,35,135,'Sales ','chinmay',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','Unprocessed','unsuccess','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',89),(123,35,35,135,'Accounts payable ','chinmay',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','Unprocessed','unsuccess','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',90),(124,35,35,135,'Sales ','chinmay',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','Unprocessed','unsuccess','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',91),(125,35,35,135,'Debit-card ','chinmay',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','Unprocessed','unsuccess','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',92),(126,35,35,135,'Bank Reconciliation ','chinmay',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','Unprocessed','unsuccess','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',93),(127,35,35,135,'Sales ','chinmay',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','Unprocessed','unsuccess','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',94),(128,35,35,135,'Bank Reconciliation ','chinmay',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','processed','success','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',95),(129,35,35,135,'Bank Reconciliation ','chinmay',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','processed','success','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',96),(130,35,35,135,'Sales ','chinmay',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','processed','success','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',97),(131,35,35,135,'Debit-card ','chinmay',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','processed','success','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',98),(132,35,35,135,'Motor ','chinmay',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','processed','success','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',99),(133,9,9,109,'Sales ','chinmay',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','processed','success','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',100),(134,9,9,109,'Bank Reconciliation ','chinmay',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','Unprocessed','unsuccess','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',101),(135,9,9,109,'Bank Reconciliation ','chinmay',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','Unprocessed','unsuccess','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',102),(136,9,9,109,'Debit-card ','chinmay',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','Unprocessed','unsuccess','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',103),(137,9,9,109,'Motor fleet Process','chinmay',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','Unprocessed','unsuccess','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',104),(138,9,9,109,'Motor fleet Process','chinmay',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','Unprocessed','unsuccess','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',105),(139,9,9,109,'Motor fleet Process','chinmay',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','Unprocessed','unsuccess','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',106),(140,9,9,109,'Motor fleet Process','chinmay',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','Unprocessed','unsuccess','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',107),(141,9,9,109,'Motor fleet Process','chinmay',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','Unprocessed','unsuccess','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',108),(142,9,9,109,'Account closure process','chinmay',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','Unprocessed','unsuccess','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',109),(143,9,9,109,'Bank Reconciliation','chinmay',214,'2024-05-30 15:20:28','2024-05-30 15:20:28','Unprocessed','unsuccess','2024-05-30 15:20:28','gayatri','2024-05-30 15:20:28','Admin',110),(144,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-05-30 19:09:26','2024-05-30 19:09:26','processed','success','2024-05-30 19:09:26','Kashmeera','2024-05-30 19:09:26','Mansi',1),(145,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-05-30 19:09:27','2024-05-30 19:09:27','Unprocessed','success','2024-05-30 19:09:27','Kashmeera','2024-05-30 19:09:27','Mansi',2),(146,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-05-30 19:09:27','2024-05-30 19:09:27','processed','success','2024-05-30 19:09:27','Kashmeera','2024-05-30 19:09:27','Mansi',3),(147,2,2,102,'Motor fleet Process','PriyankaYadav',211,'2024-05-30 19:09:27','2024-05-30 19:09:27','processed','success','2024-05-30 19:09:27','Kashmeera','2024-05-30 19:09:27','Mansi',4),(148,2,2,102,'Motor fleet Process','PriyankaYadav',211,'2024-05-30 19:09:27','2024-05-30 19:09:27','processed','success','2024-05-30 19:09:27','Kashmeera','2024-05-30 19:09:27','Mansi',5),(149,2,2,102,'Account closure process','Aishwarya',211,'2024-05-30 19:09:27','2024-05-30 19:09:27','processed','success','2024-05-30 19:09:27','Kashmeera','2024-05-30 19:09:27','Admin',6),(150,2,2,102,'Bank Reconciliation','Shivani',211,'2024-05-30 19:09:27','2024-05-30 19:09:27','Unprocessed','success','2024-05-30 19:09:27','Kashmeera','2024-05-30 19:09:27','Admin',7),(151,3,3,103,'Accounts payable','Monika',211,'2024-05-30 19:09:27','2024-05-30 19:09:27','processed','success','2024-05-30 19:09:27','Kashmeera','2024-05-30 19:09:27','Admin',8),(152,3,3,103,'Mortgage processing','Akshay',211,'2024-05-30 19:09:27','2024-05-30 19:09:27','processed','Unprocessed','2024-05-30 19:09:27','Kashmeera','2024-05-30 19:09:27','Admin',9),(153,3,3,103,'Bank Reconciliation','Cinmay',211,'2024-05-30 19:09:27','2024-05-30 19:09:27','processed','Unprocessed','2024-05-30 19:09:27','Kashmeera','2024-05-30 19:09:27','Admin',10),(154,3,3,103,'Accounts payable','Monika',211,'2024-05-30 19:09:27','2024-05-30 19:09:27','processed','success','2024-05-30 19:09:27','Kashmeera','2024-05-30 19:09:27','Admin',11),(155,3,3,103,'Credit card application processing','Akshay',211,'2024-05-30 19:09:27','2024-05-30 19:09:27','processed','Unprocessed','2024-05-30 19:09:27','Kashmeera','2024-05-30 19:09:27','Admin',12),(156,3,3,103,'Bank Reconciliation','Cinmay',211,'2024-05-30 19:09:27','2024-05-30 19:09:27','processed','Unprocessed','2024-05-30 19:09:27','Kashmeera','2024-05-30 19:09:27','Admin',13),(157,3,3,103,'Motor','Deepak',213,'2024-05-30 19:09:27','2024-05-30 19:09:27','Unprocessed','unsuccess','2024-05-30 19:09:27','Kashmira','2024-05-30 19:09:27','Admin',15),(158,10,10,110,'Motor fleet Process','PriyankaYadav',211,'2024-05-30 19:09:27','2024-05-30 19:09:27','processed','success','2024-05-30 19:09:27','Kashmeera','2024-05-30 19:09:27','Mansi',16),(159,10,10,110,'Debit-card','Sandesh',213,'2024-05-30 19:09:27','2024-05-30 19:09:27','Unprocessed','unsuccess','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',17),(160,10,10,110,'Sales','Amit',213,'2024-05-30 19:09:27','2024-05-30 19:09:27','Unprocessed','unsuccess','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',18),(161,10,10,110,'Motor','Amit',213,'2024-05-30 19:09:27','2024-05-30 19:09:27','processed','unsuccess','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',19),(162,10,10,110,'Sales','Amit',213,'2024-05-30 19:09:27','2024-05-30 19:09:27','processed','unsuccess','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',20),(163,10,10,110,'Accounts payable','Amit',213,'2024-05-30 19:09:27','2024-05-30 19:09:27','processed','unsuccess','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',21),(164,10,10,110,'Sales','Amit',213,'2024-05-30 19:09:27','2024-05-30 19:09:27','processed','unsuccess','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',22),(165,10,10,110,'Debit-card','Amit',213,'2024-05-30 19:09:27','2024-05-30 19:09:27','Unprocessed','unsuccess','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',24),(166,10,10,110,'Bank Reconciliation','Amit',213,'2024-05-30 19:09:27','2024-05-30 19:09:27','Unprocessed','unsuccess','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',25),(167,10,10,110,'Sales','Amit',213,'2024-05-30 19:09:27','2024-05-30 19:09:27','processed','unsuccess','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',26),(168,10,10,110,'Bank Reconciliation','Amit',213,'2024-05-30 19:09:27','2024-05-30 19:09:27','Unprocessed','unsuccess','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',27),(169,5,5,105,'Bank Reconciliation','Amit',213,'2024-05-30 19:09:27','2024-05-30 19:09:27','processed','unsuccess','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',28),(170,5,5,105,'Sales','Amit',213,'2024-05-30 19:09:27','2024-05-30 19:09:27','Unprocessed','unsuccess','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',29),(171,5,5,105,'Debit-card','Amit',213,'2024-05-30 19:09:27','2024-05-30 19:09:27','Unprocessed','unsuccess','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',30),(172,5,5,105,'Motor','Amit',213,'2024-05-30 19:09:27','2024-05-30 19:09:27','Unprocessed','unsuccess','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',31),(173,5,5,105,'Sales','Amit',213,'2024-05-30 19:09:27','2024-05-30 19:09:27','processed','unsuccess','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',32),(174,5,5,105,'Bank Reconciliation','Amit',213,'2024-05-30 19:09:27','2024-05-30 19:09:27','Unprocessed','unsuccess','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',33),(175,5,5,105,'Bank Reconciliation','Amit',213,'2024-05-30 19:09:27','2024-05-30 19:09:27','Unprocessed','unsuccess','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',34),(176,15,15,115,'Debit-card','Amit',213,'2024-05-30 19:09:27','2024-05-30 19:09:27','Unprocessed','unsuccess','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',35),(177,1,1,101,'Motor fleet Process','aiswarya',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','Unprocessed','unsuccess','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',36),(178,1,1,101,'Motor fleet Process','aiswarya',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','Unprocessed','unsuccess','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',37),(179,1,1,101,'Motor fleet Process','aiswarya',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','processed','success','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',38),(180,1,1,101,'Motor fleet Process','aiswarya',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','processed','success','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',39),(181,1,1,101,'Motor fleet Process','aiswarya',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','processed','success','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',40),(182,2,2,102,'Account closure process','aiswarya',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','processed','success','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',41),(183,2,2,102,'Bank Reconciliation','aiswarya',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','processed','success','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',42),(184,2,2,102,'Accounts payable','aiswarya',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','processed','success','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',43),(185,2,2,102,'Mortgage processing','aiswarya',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','processed','success','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',44),(186,3,3,103,'Bank Reconciliation','aiswarya',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','processed','success','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',45),(187,3,3,103,'Accounts payable','aiswarya',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','processed','success','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',46),(188,3,3,103,'Credit card application processing','aiswarya',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','processed','success','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',47),(189,3,3,103,'Bank Reconciliation','aiswarya',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','processed','success','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',48),(190,3,3,103,'Motor fleet Process','aiswarya',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','Unprocessed','unsuccess','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',49),(191,3,3,103,'Motor ','aiswarya',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','Unprocessed','unsuccess','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',50),(192,3,3,103,'Motor fleet Process','aiswarya',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','Unprocessed','unsuccess','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',51),(193,10,10,110,'Debit-card ','aiswarya',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','Unprocessed','unsuccess','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',52),(194,10,10,110,'Sales ','aiswarya',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','Unprocessed','unsuccess','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',53),(195,10,10,110,'Motor ','aiswarya',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','Unprocessed','unsuccess','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',54),(196,10,10,110,'Sales ','aiswarya',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','processed','success','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',55),(197,10,10,110,'Accounts payable ','aiswarya',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','processed','success','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',56),(198,10,10,110,'Sales ','aiswarya',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','processed','success','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',57),(199,10,10,110,'Debit-card ','aiswarya',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','processed','success','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',58),(200,10,10,110,'Bank Reconciliation ','aiswarya',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','Unprocessed','unsuccess','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',59),(201,10,10,110,'Sales ','chinmay',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','Unprocessed','unsuccess','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',60),(202,10,10,110,'Bank Reconciliation ','chinmay',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','Unprocessed','unsuccess','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',61),(203,10,10,110,'Bank Reconciliation ','chinmay',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','Unprocessed','unsuccess','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',62),(204,5,5,105,'Sales ','chinmay',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','Unprocessed','unsuccess','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',63),(205,5,5,105,'Debit-card ','chinmay',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','Unprocessed','unsuccess','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',64),(206,5,5,105,'Motor ','chinmay',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','Unprocessed','unsuccess','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',65),(207,5,5,105,'Sales ','chinmay',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','Unprocessed','unsuccess','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',66),(208,5,5,105,'Bank Reconciliation ','chinmay',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','processed','success','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',67),(209,5,5,105,'Bank Reconciliation ','chinmay',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','processed','success','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',68),(210,5,5,105,'Debit-card ','chinmay',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','processed','success','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',69),(211,15,15,115,'Motor fleet Process','chinmay',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','processed','success','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',70),(212,15,15,115,'Motor fleet Process','chinmay',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','processed','success','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',71),(213,15,15,115,'Motor fleet Process','chinmay',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','processed','success','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',72),(214,15,15,115,'Motor fleet Process','chinmay',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','Unprocessed','unsuccess','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',73),(215,15,15,115,'Motor fleet Process','chinmay',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','Unprocessed','unsuccess','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',74),(216,15,15,115,'Account closure process','chinmay',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','Unprocessed','unsuccess','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',75),(217,12,12,112,'Bank Reconciliation','chinmay',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','Unprocessed','unsuccess','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',76),(218,12,12,112,'Accounts payable','chinmay',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','Unprocessed','unsuccess','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',77),(219,12,12,112,'Mortgage processing','chinmay',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','Unprocessed','unsuccess','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',78),(220,12,12,112,'Bank Reconciliation','chinmay',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','Unprocessed','unsuccess','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',79),(221,12,12,112,'Accounts payable','chinmay',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','processed','success','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',80),(222,20,20,120,'Credit card application processing','chinmay',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','processed','success','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',81),(223,20,20,120,'Bank Reconciliation','chinmay',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','processed','success','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',82),(224,20,20,120,'Motor fleet Process','chinmay',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','processed','success','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',83),(225,20,20,120,'Motor ','chinmay',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','processed','success','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',84),(226,20,20,120,'Motor fleet Process','chinmay',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','processed','success','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',85),(227,20,20,120,'Debit-card ','chinmay',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','Unprocessed','unsuccess','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',86),(228,20,20,120,'Sales ','chinmay',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','Unprocessed','unsuccess','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',87),(229,35,35,135,'Motor ','chinmay',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','Unprocessed','unsuccess','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',88),(230,35,35,135,'Sales ','chinmay',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','Unprocessed','unsuccess','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',89),(231,35,35,135,'Accounts payable ','chinmay',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','Unprocessed','unsuccess','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',90),(232,35,35,135,'Sales ','chinmay',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','Unprocessed','unsuccess','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',91),(233,35,35,135,'Debit-card ','chinmay',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','Unprocessed','unsuccess','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',92),(234,35,35,135,'Bank Reconciliation ','chinmay',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','Unprocessed','unsuccess','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',93),(235,35,35,135,'Sales ','chinmay',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','Unprocessed','unsuccess','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',94),(236,35,35,135,'Bank Reconciliation ','chinmay',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','processed','success','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',95),(237,35,35,135,'Bank Reconciliation ','chinmay',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','processed','success','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',96),(238,35,35,135,'Sales ','chinmay',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','processed','success','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',97),(239,35,35,135,'Debit-card ','chinmay',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','processed','success','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',98),(240,35,35,135,'Motor ','chinmay',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','processed','success','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',99),(241,9,9,109,'Sales ','chinmay',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','processed','success','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',100),(242,9,9,109,'Bank Reconciliation ','chinmay',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','Unprocessed','unsuccess','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',101),(243,9,9,109,'Bank Reconciliation ','chinmay',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','Unprocessed','unsuccess','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',102),(244,9,9,109,'Debit-card ','chinmay',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','Unprocessed','unsuccess','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',103),(245,9,9,109,'Motor fleet Process','chinmay',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','Unprocessed','unsuccess','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',104),(246,9,9,109,'Motor fleet Process','chinmay',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','Unprocessed','unsuccess','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',105),(247,9,9,109,'Motor fleet Process','chinmay',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','Unprocessed','unsuccess','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',106),(248,9,9,109,'Motor fleet Process','chinmay',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','Unprocessed','unsuccess','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',107),(249,9,9,109,'Motor fleet Process','chinmay',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','Unprocessed','unsuccess','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',108),(250,9,9,109,'Account closure process','chinmay',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','Unprocessed','unsuccess','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',109),(251,9,9,109,'Bank Reconciliation','chinmay',214,'2024-05-30 19:09:27','2024-05-30 19:09:27','Unprocessed','unsuccess','2024-05-30 19:09:27','gayatri','2024-05-30 19:09:27','Admin',110),(252,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-05-30 20:07:11','2024-05-30 20:07:11','processed','success','2024-05-30 20:07:11','Kashmeera','2024-05-30 20:07:11','Mansi',1),(253,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-05-30 20:07:11','2024-05-30 20:07:11','Unprocessed','success','2024-05-30 20:07:11','Kashmeera','2024-05-30 20:07:11','Mansi',2),(254,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-05-30 20:07:12','2024-05-30 20:07:12','processed','success','2024-05-30 20:07:12','Kashmeera','2024-05-30 20:07:12','Mansi',3),(255,2,2,102,'Motor fleet Process','PriyankaYadav',211,'2024-05-30 20:07:12','2024-05-30 20:07:12','processed','success','2024-05-30 20:07:12','Kashmeera','2024-05-30 20:07:12','Mansi',4),(256,2,2,102,'Motor fleet Process','PriyankaYadav',211,'2024-05-30 20:07:12','2024-05-30 20:07:12','processed','success','2024-05-30 20:07:12','Kashmeera','2024-05-30 20:07:12','Mansi',5),(257,2,2,102,'Account closure process','Aishwarya',211,'2024-05-30 20:07:12','2024-05-30 20:07:12','processed','success','2024-05-30 20:07:12','Kashmeera','2024-05-30 20:07:12','Admin',6),(258,2,2,102,'Bank Reconciliation','Shivani',211,'2024-05-30 20:07:12','2024-05-30 20:07:12','Unprocessed','success','2024-05-30 20:07:12','Kashmeera','2024-05-30 20:07:12','Admin',7),(259,3,3,103,'Accounts payable','Monika',211,'2024-05-30 20:07:12','2024-05-30 20:07:12','processed','success','2024-05-30 20:07:12','Kashmeera','2024-05-30 20:07:12','Admin',8),(260,3,3,103,'Mortgage processing','Akshay',211,'2024-05-30 20:07:12','2024-05-30 20:07:12','processed','Unprocessed','2024-05-30 20:07:12','Kashmeera','2024-05-30 20:07:12','Admin',9),(261,3,3,103,'Bank Reconciliation','Cinmay',211,'2024-05-30 20:07:12','2024-05-30 20:07:12','processed','Unprocessed','2024-05-30 20:07:12','Kashmeera','2024-05-30 20:07:12','Admin',10),(262,3,3,103,'Accounts payable','Monika',211,'2024-05-30 20:07:12','2024-05-30 20:07:12','processed','success','2024-05-30 20:07:12','Kashmeera','2024-05-30 20:07:12','Admin',11),(263,3,3,103,'Credit card application processing','Akshay',211,'2024-05-30 20:07:12','2024-05-30 20:07:12','processed','Unprocessed','2024-05-30 20:07:12','Kashmeera','2024-05-30 20:07:12','Admin',12),(264,3,3,103,'Bank Reconciliation','Cinmay',211,'2024-05-30 20:07:12','2024-05-30 20:07:12','processed','Unprocessed','2024-05-30 20:07:12','Kashmeera','2024-05-30 20:07:12','Admin',13),(265,3,3,103,'Motor','Deepak',213,'2024-05-30 20:07:12','2024-05-30 20:07:12','Unprocessed','unsuccess','2024-05-30 20:07:12','Kashmira','2024-05-30 20:07:12','Admin',15),(266,10,10,110,'Motor fleet Process','PriyankaYadav',211,'2024-05-30 20:07:12','2024-05-30 20:07:12','processed','success','2024-05-30 20:07:12','Kashmeera','2024-05-30 20:07:12','Mansi',16),(267,10,10,110,'Debit-card','Sandesh',213,'2024-05-30 20:07:12','2024-05-30 20:07:12','Unprocessed','unsuccess','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',17),(268,10,10,110,'Sales','Amit',213,'2024-05-30 20:07:12','2024-05-30 20:07:12','Unprocessed','unsuccess','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',18),(269,10,10,110,'Motor','Amit',213,'2024-05-30 20:07:12','2024-05-30 20:07:12','processed','unsuccess','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',19),(270,10,10,110,'Sales','Amit',213,'2024-05-30 20:07:12','2024-05-30 20:07:12','processed','unsuccess','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',20),(271,10,10,110,'Accounts payable','Amit',213,'2024-05-30 20:07:12','2024-05-30 20:07:12','processed','unsuccess','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',21),(272,10,10,110,'Sales','Amit',213,'2024-05-30 20:07:12','2024-05-30 20:07:12','processed','unsuccess','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',22),(273,10,10,110,'Debit-card','Amit',213,'2024-05-30 20:07:12','2024-05-30 20:07:12','Unprocessed','unsuccess','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',24),(274,10,10,110,'Bank Reconciliation','Amit',213,'2024-05-30 20:07:12','2024-05-30 20:07:12','Unprocessed','unsuccess','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',25),(275,10,10,110,'Sales','Amit',213,'2024-05-30 20:07:12','2024-05-30 20:07:12','processed','unsuccess','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',26),(276,10,10,110,'Bank Reconciliation','Amit',213,'2024-05-30 20:07:12','2024-05-30 20:07:12','Unprocessed','unsuccess','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',27),(277,5,5,105,'Bank Reconciliation','Amit',213,'2024-05-30 20:07:12','2024-05-30 20:07:12','processed','unsuccess','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',28),(278,5,5,105,'Sales','Amit',213,'2024-05-30 20:07:12','2024-05-30 20:07:12','Unprocessed','unsuccess','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',29),(279,5,5,105,'Debit-card','Amit',213,'2024-05-30 20:07:12','2024-05-30 20:07:12','Unprocessed','unsuccess','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',30),(280,5,5,105,'Motor','Amit',213,'2024-05-30 20:07:12','2024-05-30 20:07:12','Unprocessed','unsuccess','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',31),(281,5,5,105,'Sales','Amit',213,'2024-05-30 20:07:12','2024-05-30 20:07:12','processed','unsuccess','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',32),(282,5,5,105,'Bank Reconciliation','Amit',213,'2024-05-30 20:07:12','2024-05-30 20:07:12','Unprocessed','unsuccess','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',33),(283,5,5,105,'Bank Reconciliation','Amit',213,'2024-05-30 20:07:12','2024-05-30 20:07:12','Unprocessed','unsuccess','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',34),(284,15,15,115,'Debit-card','Amit',213,'2024-05-30 20:07:12','2024-05-30 20:07:12','Unprocessed','unsuccess','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',35),(285,1,1,101,'Motor fleet Process','aiswarya',214,'2024-05-30 20:07:12','2024-05-30 20:07:12','Unprocessed','unsuccess','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',36),(286,1,1,101,'Motor fleet Process','aiswarya',214,'2024-05-30 20:07:12','2024-05-30 20:07:12','Unprocessed','unsuccess','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',37),(287,1,1,101,'Motor fleet Process','aiswarya',214,'2024-05-30 20:07:12','2024-05-30 20:07:12','processed','success','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',38),(288,1,1,101,'Motor fleet Process','aiswarya',214,'2024-05-30 20:07:12','2024-05-30 20:07:12','processed','success','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',39),(289,1,1,101,'Motor fleet Process','aiswarya',214,'2024-05-30 20:07:12','2024-05-30 20:07:12','processed','success','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',40),(290,2,2,102,'Account closure process','aiswarya',214,'2024-05-30 20:07:12','2024-05-30 20:07:12','processed','success','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',41),(291,2,2,102,'Bank Reconciliation','aiswarya',214,'2024-05-30 20:07:12','2024-05-30 20:07:12','processed','success','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',42),(292,2,2,102,'Accounts payable','aiswarya',214,'2024-05-30 20:07:12','2024-05-30 20:07:12','processed','success','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',43),(293,2,2,102,'Mortgage processing','aiswarya',214,'2024-05-30 20:07:12','2024-05-30 20:07:12','processed','success','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',44),(294,3,3,103,'Bank Reconciliation','aiswarya',214,'2024-05-30 20:07:12','2024-05-30 20:07:12','processed','success','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',45),(295,3,3,103,'Accounts payable','aiswarya',214,'2024-05-30 20:07:12','2024-05-30 20:07:12','processed','success','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',46),(296,3,3,103,'Credit card application processing','aiswarya',214,'2024-05-30 20:07:12','2024-05-30 20:07:12','processed','success','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',47),(297,3,3,103,'Bank Reconciliation','aiswarya',214,'2024-05-30 20:07:12','2024-05-30 20:07:12','processed','success','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',48),(298,3,3,103,'Motor fleet Process','aiswarya',214,'2024-05-30 20:07:12','2024-05-30 20:07:12','Unprocessed','unsuccess','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',49),(299,3,3,103,'Motor ','aiswarya',214,'2024-05-30 20:07:12','2024-05-30 20:07:12','Unprocessed','unsuccess','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',50),(300,3,3,103,'Motor fleet Process','aiswarya',214,'2024-05-30 20:07:12','2024-05-30 20:07:12','Unprocessed','unsuccess','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',51),(301,10,10,110,'Debit-card ','aiswarya',214,'2024-05-30 20:07:12','2024-05-30 20:07:12','Unprocessed','unsuccess','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',52),(302,10,10,110,'Sales ','aiswarya',214,'2024-05-30 20:07:12','2024-05-30 20:07:12','Unprocessed','unsuccess','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',53),(303,10,10,110,'Motor ','aiswarya',214,'2024-05-30 20:07:12','2024-05-30 20:07:12','Unprocessed','unsuccess','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',54),(304,10,10,110,'Sales ','aiswarya',214,'2024-05-30 20:07:12','2024-05-30 20:07:12','processed','success','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',55),(305,10,10,110,'Accounts payable ','aiswarya',214,'2024-05-30 20:07:12','2024-05-30 20:07:12','processed','success','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',56),(306,10,10,110,'Sales ','aiswarya',214,'2024-05-30 20:07:12','2024-05-30 20:07:12','processed','success','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',57),(307,10,10,110,'Debit-card ','aiswarya',214,'2024-05-30 20:07:12','2024-05-30 20:07:12','processed','success','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',58),(308,10,10,110,'Bank Reconciliation ','aiswarya',214,'2024-05-30 20:07:12','2024-05-30 20:07:12','Unprocessed','unsuccess','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',59),(309,10,10,110,'Sales ','chinmay',214,'2024-05-30 20:07:12','2024-05-30 20:07:12','Unprocessed','unsuccess','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',60),(310,10,10,110,'Bank Reconciliation ','chinmay',214,'2024-05-30 20:07:12','2024-05-30 20:07:12','Unprocessed','unsuccess','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',61),(311,10,10,110,'Bank Reconciliation ','chinmay',214,'2024-05-30 20:07:12','2024-05-30 20:07:12','Unprocessed','unsuccess','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',62),(312,5,5,105,'Sales ','chinmay',214,'2024-05-30 20:07:12','2024-05-30 20:07:12','Unprocessed','unsuccess','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',63),(313,5,5,105,'Debit-card ','chinmay',214,'2024-05-30 20:07:12','2024-05-30 20:07:12','Unprocessed','unsuccess','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',64),(314,5,5,105,'Motor ','chinmay',214,'2024-05-30 20:07:12','2024-05-30 20:07:12','Unprocessed','unsuccess','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',65),(315,5,5,105,'Sales ','chinmay',214,'2024-05-30 20:07:12','2024-05-30 20:07:12','Unprocessed','unsuccess','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',66),(316,5,5,105,'Bank Reconciliation ','chinmay',214,'2024-05-30 20:07:12','2024-05-30 20:07:12','processed','success','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',67),(317,5,5,105,'Bank Reconciliation ','chinmay',214,'2024-05-30 20:07:12','2024-05-30 20:07:12','processed','success','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',68),(318,5,5,105,'Debit-card ','chinmay',214,'2024-05-30 20:07:12','2024-05-30 20:07:12','processed','success','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',69),(319,15,15,115,'Motor fleet Process','chinmay',214,'2024-05-30 20:07:12','2024-05-30 20:07:12','processed','success','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',70),(320,15,15,115,'Motor fleet Process','chinmay',214,'2024-05-30 20:07:12','2024-05-30 20:07:12','processed','success','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',71),(321,15,15,115,'Motor fleet Process','chinmay',214,'2024-05-30 20:07:12','2024-05-30 20:07:12','processed','success','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',72),(322,15,15,115,'Motor fleet Process','chinmay',214,'2024-05-30 20:07:12','2024-05-30 20:07:12','Unprocessed','unsuccess','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',73),(323,15,15,115,'Motor fleet Process','chinmay',214,'2024-05-30 20:07:12','2024-05-30 20:07:12','Unprocessed','unsuccess','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',74),(324,15,15,115,'Account closure process','chinmay',214,'2024-05-30 20:07:12','2024-05-30 20:07:12','Unprocessed','unsuccess','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',75),(325,12,12,112,'Bank Reconciliation','chinmay',214,'2024-05-30 20:07:12','2024-05-30 20:07:12','Unprocessed','unsuccess','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',76),(326,12,12,112,'Accounts payable','chinmay',214,'2024-05-30 20:07:12','2024-05-30 20:07:12','Unprocessed','unsuccess','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',77),(327,12,12,112,'Mortgage processing','chinmay',214,'2024-05-30 20:07:12','2024-05-30 20:07:12','Unprocessed','unsuccess','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',78),(328,12,12,112,'Bank Reconciliation','chinmay',214,'2024-05-30 20:07:12','2024-05-30 20:07:12','Unprocessed','unsuccess','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',79),(329,12,12,112,'Accounts payable','chinmay',214,'2024-05-30 20:07:12','2024-05-30 20:07:12','processed','success','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',80),(330,20,20,120,'Credit card application processing','chinmay',214,'2024-05-30 20:07:12','2024-05-30 20:07:12','processed','success','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',81),(331,20,20,120,'Bank Reconciliation','chinmay',214,'2024-05-30 20:07:12','2024-05-30 20:07:12','processed','success','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',82),(332,20,20,120,'Motor fleet Process','chinmay',214,'2024-05-30 20:07:12','2024-05-30 20:07:12','processed','success','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',83),(333,20,20,120,'Motor ','chinmay',214,'2024-05-30 20:07:12','2024-05-30 20:07:12','processed','success','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',84),(334,20,20,120,'Motor fleet Process','chinmay',214,'2024-05-30 20:07:12','2024-05-30 20:07:12','processed','success','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',85),(335,20,20,120,'Debit-card ','chinmay',214,'2024-05-30 20:07:12','2024-05-30 20:07:12','Unprocessed','unsuccess','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',86),(336,20,20,120,'Sales ','chinmay',214,'2024-05-30 20:07:12','2024-05-30 20:07:12','Unprocessed','unsuccess','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',87),(337,35,35,135,'Motor ','chinmay',214,'2024-05-30 20:07:12','2024-05-30 20:07:12','Unprocessed','unsuccess','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',88),(338,35,35,135,'Sales ','chinmay',214,'2024-05-30 20:07:12','2024-05-30 20:07:12','Unprocessed','unsuccess','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',89),(339,35,35,135,'Accounts payable ','chinmay',214,'2024-05-30 20:07:12','2024-05-30 20:07:12','Unprocessed','unsuccess','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',90),(340,35,35,135,'Sales ','chinmay',214,'2024-05-30 20:07:12','2024-05-30 20:07:12','Unprocessed','unsuccess','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',91),(341,35,35,135,'Debit-card ','chinmay',214,'2024-05-30 20:07:12','2024-05-30 20:07:12','Unprocessed','unsuccess','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',92),(342,35,35,135,'Bank Reconciliation ','chinmay',214,'2024-05-30 20:07:12','2024-05-30 20:07:12','Unprocessed','unsuccess','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',93),(343,35,35,135,'Sales ','chinmay',214,'2024-05-30 20:07:12','2024-05-30 20:07:12','Unprocessed','unsuccess','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',94),(344,35,35,135,'Bank Reconciliation ','chinmay',214,'2024-05-30 20:07:12','2024-05-30 20:07:12','processed','success','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',95),(345,35,35,135,'Bank Reconciliation ','chinmay',214,'2024-05-30 20:07:12','2024-05-30 20:07:12','processed','success','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',96),(346,35,35,135,'Sales ','chinmay',214,'2024-05-30 20:07:12','2024-05-30 20:07:12','processed','success','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',97),(347,35,35,135,'Debit-card ','chinmay',214,'2024-05-30 20:07:12','2024-05-30 20:07:12','processed','success','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',98),(348,35,35,135,'Motor ','chinmay',214,'2024-05-30 20:07:12','2024-05-30 20:07:12','processed','success','2024-05-30 20:07:12','gayatri','2024-05-30 20:07:12','Admin',99),(349,9,9,109,'Sales ','chinmay',214,'2024-05-30 20:07:13','2024-05-30 20:07:13','processed','success','2024-05-30 20:07:13','gayatri','2024-05-30 20:07:13','Admin',100),(350,9,9,109,'Bank Reconciliation ','chinmay',214,'2024-05-30 20:07:13','2024-05-30 20:07:13','Unprocessed','unsuccess','2024-05-30 20:07:13','gayatri','2024-05-30 20:07:13','Admin',101),(351,9,9,109,'Bank Reconciliation ','chinmay',214,'2024-05-30 20:07:13','2024-05-30 20:07:13','Unprocessed','unsuccess','2024-05-30 20:07:13','gayatri','2024-05-30 20:07:13','Admin',102),(352,9,9,109,'Debit-card ','chinmay',214,'2024-05-30 20:07:13','2024-05-30 20:07:13','Unprocessed','unsuccess','2024-05-30 20:07:13','gayatri','2024-05-30 20:07:13','Admin',103),(353,9,9,109,'Motor fleet Process','chinmay',214,'2024-05-30 20:07:13','2024-05-30 20:07:13','Unprocessed','unsuccess','2024-05-30 20:07:13','gayatri','2024-05-30 20:07:13','Admin',104),(354,9,9,109,'Motor fleet Process','chinmay',214,'2024-05-30 20:07:13','2024-05-30 20:07:13','Unprocessed','unsuccess','2024-05-30 20:07:13','gayatri','2024-05-30 20:07:13','Admin',105),(355,9,9,109,'Motor fleet Process','chinmay',214,'2024-05-30 20:07:13','2024-05-30 20:07:13','Unprocessed','unsuccess','2024-05-30 20:07:13','gayatri','2024-05-30 20:07:13','Admin',106),(356,9,9,109,'Motor fleet Process','chinmay',214,'2024-05-30 20:07:13','2024-05-30 20:07:13','Unprocessed','unsuccess','2024-05-30 20:07:13','gayatri','2024-05-30 20:07:13','Admin',107),(357,9,9,109,'Motor fleet Process','chinmay',214,'2024-05-30 20:07:13','2024-05-30 20:07:13','Unprocessed','unsuccess','2024-05-30 20:07:13','gayatri','2024-05-30 20:07:13','Admin',108),(358,9,9,109,'Account closure process','chinmay',214,'2024-05-30 20:07:13','2024-05-30 20:07:13','Unprocessed','unsuccess','2024-05-30 20:07:13','gayatri','2024-05-30 20:07:13','Admin',109),(359,9,9,109,'Bank Reconciliation','chinmay',214,'2024-05-30 20:07:13','2024-05-30 20:07:13','Unprocessed','unsuccess','2024-05-30 20:07:13','gayatri','2024-05-30 20:07:13','Admin',110),(360,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-05-30 20:26:11','2024-05-30 20:26:11','processed','success','2024-05-30 20:26:11','Kashmeera','2024-05-30 20:26:11','Mansi',1),(361,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-05-30 20:26:11','2024-05-30 20:26:11','Unprocessed','success','2024-05-30 20:26:11','Kashmeera','2024-05-30 20:26:11','Mansi',2),(362,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-05-30 20:26:11','2024-05-30 20:26:11','processed','success','2024-05-30 20:26:11','Kashmeera','2024-05-30 20:26:11','Mansi',3),(363,2,2,102,'Motor fleet Process','PriyankaYadav',211,'2024-05-30 20:26:11','2024-05-30 20:26:11','processed','success','2024-05-30 20:26:11','Kashmeera','2024-05-30 20:26:11','Mansi',4),(364,2,2,102,'Motor fleet Process','PriyankaYadav',211,'2024-05-30 20:26:11','2024-05-30 20:26:11','processed','success','2024-05-30 20:26:11','Kashmeera','2024-05-30 20:26:11','Mansi',5),(365,2,2,102,'Account closure process','Aishwarya',211,'2024-05-30 20:26:11','2024-05-30 20:26:11','processed','success','2024-05-30 20:26:11','Kashmeera','2024-05-30 20:26:11','Admin',6),(366,2,2,102,'Bank Reconciliation','Shivani',211,'2024-05-30 20:26:11','2024-05-30 20:26:11','Unprocessed','success','2024-05-30 20:26:11','Kashmeera','2024-05-30 20:26:11','Admin',7),(367,3,3,103,'Accounts payable','Monika',211,'2024-05-30 20:26:11','2024-05-30 20:26:11','processed','success','2024-05-30 20:26:11','Kashmeera','2024-05-30 20:26:11','Admin',8),(368,3,3,103,'Mortgage processing','Akshay',211,'2024-05-30 20:26:11','2024-05-30 20:26:11','processed','Unprocessed','2024-05-30 20:26:11','Kashmeera','2024-05-30 20:26:11','Admin',9),(369,3,3,103,'Bank Reconciliation','Cinmay',211,'2024-05-30 20:26:11','2024-05-30 20:26:11','processed','Unprocessed','2024-05-30 20:26:11','Kashmeera','2024-05-30 20:26:11','Admin',10),(370,3,3,103,'Accounts payable','Monika',211,'2024-05-30 20:26:11','2024-05-30 20:26:11','processed','success','2024-05-30 20:26:11','Kashmeera','2024-05-30 20:26:11','Admin',11),(371,3,3,103,'Credit card application processing','Akshay',211,'2024-05-30 20:26:11','2024-05-30 20:26:11','processed','Unprocessed','2024-05-30 20:26:11','Kashmeera','2024-05-30 20:26:11','Admin',12),(372,3,3,103,'Bank Reconciliation','Cinmay',211,'2024-05-30 20:26:11','2024-05-30 20:26:11','processed','Unprocessed','2024-05-30 20:26:11','Kashmeera','2024-05-30 20:26:11','Admin',13),(373,3,3,103,'Motor','Deepak',213,'2024-05-30 20:26:11','2024-05-30 20:26:11','Unprocessed','unsuccess','2024-05-30 20:26:11','Kashmira','2024-05-30 20:26:11','Admin',15),(374,10,10,110,'Motor fleet Process','PriyankaYadav',211,'2024-05-30 20:26:12','2024-05-30 20:26:12','processed','success','2024-05-30 20:26:12','Kashmeera','2024-05-30 20:26:12','Mansi',16),(375,10,10,110,'Debit-card','Sandesh',213,'2024-05-30 20:26:12','2024-05-30 20:26:12','Unprocessed','unsuccess','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',17),(376,10,10,110,'Sales','Amit',213,'2024-05-30 20:26:12','2024-05-30 20:26:12','Unprocessed','unsuccess','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',18),(377,10,10,110,'Motor','Amit',213,'2024-05-30 20:26:12','2024-05-30 20:26:12','processed','unsuccess','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',19),(378,10,10,110,'Sales','Amit',213,'2024-05-30 20:26:12','2024-05-30 20:26:12','processed','unsuccess','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',20),(379,10,10,110,'Accounts payable','Amit',213,'2024-05-30 20:26:12','2024-05-30 20:26:12','processed','unsuccess','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',21),(380,10,10,110,'Sales','Amit',213,'2024-05-30 20:26:12','2024-05-30 20:26:12','processed','unsuccess','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',22),(381,10,10,110,'Debit-card','Amit',213,'2024-05-30 20:26:12','2024-05-30 20:26:12','Unprocessed','unsuccess','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',24),(382,10,10,110,'Bank Reconciliation','Amit',213,'2024-05-30 20:26:12','2024-05-30 20:26:12','Unprocessed','unsuccess','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',25),(383,10,10,110,'Sales','Amit',213,'2024-05-30 20:26:12','2024-05-30 20:26:12','processed','unsuccess','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',26),(384,10,10,110,'Bank Reconciliation','Amit',213,'2024-05-30 20:26:12','2024-05-30 20:26:12','Unprocessed','unsuccess','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',27),(385,5,5,105,'Bank Reconciliation','Amit',213,'2024-05-30 20:26:12','2024-05-30 20:26:12','processed','unsuccess','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',28),(386,5,5,105,'Sales','Amit',213,'2024-05-30 20:26:12','2024-05-30 20:26:12','Unprocessed','unsuccess','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',29),(387,5,5,105,'Debit-card','Amit',213,'2024-05-30 20:26:12','2024-05-30 20:26:12','Unprocessed','unsuccess','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',30),(388,5,5,105,'Motor','Amit',213,'2024-05-30 20:26:12','2024-05-30 20:26:12','Unprocessed','unsuccess','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',31),(389,5,5,105,'Sales','Amit',213,'2024-05-30 20:26:12','2024-05-30 20:26:12','processed','unsuccess','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',32),(390,5,5,105,'Bank Reconciliation','Amit',213,'2024-05-30 20:26:12','2024-05-30 20:26:12','Unprocessed','unsuccess','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',33),(391,5,5,105,'Bank Reconciliation','Amit',213,'2024-05-30 20:26:12','2024-05-30 20:26:12','Unprocessed','unsuccess','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',34),(392,15,15,115,'Debit-card','Amit',213,'2024-05-30 20:26:12','2024-05-30 20:26:12','Unprocessed','unsuccess','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',35),(393,1,1,101,'Motor fleet Process','aiswarya',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','Unprocessed','unsuccess','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',36),(394,1,1,101,'Motor fleet Process','aiswarya',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','Unprocessed','unsuccess','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',37),(395,1,1,101,'Motor fleet Process','aiswarya',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','processed','success','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',38),(396,1,1,101,'Motor fleet Process','aiswarya',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','processed','success','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',39),(397,1,1,101,'Motor fleet Process','aiswarya',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','processed','success','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',40),(398,2,2,102,'Account closure process','aiswarya',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','processed','success','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',41),(399,2,2,102,'Bank Reconciliation','aiswarya',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','processed','success','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',42),(400,2,2,102,'Accounts payable','aiswarya',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','processed','success','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',43),(401,2,2,102,'Mortgage processing','aiswarya',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','processed','success','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',44),(402,3,3,103,'Bank Reconciliation','aiswarya',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','processed','success','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',45),(403,3,3,103,'Accounts payable','aiswarya',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','processed','success','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',46),(404,3,3,103,'Credit card application processing','aiswarya',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','processed','success','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',47),(405,3,3,103,'Bank Reconciliation','aiswarya',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','processed','success','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',48),(406,3,3,103,'Motor fleet Process','aiswarya',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','Unprocessed','unsuccess','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',49),(407,3,3,103,'Motor ','aiswarya',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','Unprocessed','unsuccess','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',50),(408,3,3,103,'Motor fleet Process','aiswarya',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','Unprocessed','unsuccess','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',51),(409,10,10,110,'Debit-card ','aiswarya',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','Unprocessed','unsuccess','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',52),(410,10,10,110,'Sales ','aiswarya',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','Unprocessed','unsuccess','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',53),(411,10,10,110,'Motor ','aiswarya',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','Unprocessed','unsuccess','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',54),(412,10,10,110,'Sales ','aiswarya',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','processed','success','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',55),(413,10,10,110,'Accounts payable ','aiswarya',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','processed','success','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',56),(414,10,10,110,'Sales ','aiswarya',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','processed','success','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',57),(415,10,10,110,'Debit-card ','aiswarya',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','processed','success','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',58),(416,10,10,110,'Bank Reconciliation ','aiswarya',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','Unprocessed','unsuccess','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',59),(417,10,10,110,'Sales ','chinmay',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','Unprocessed','unsuccess','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',60),(418,10,10,110,'Bank Reconciliation ','chinmay',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','Unprocessed','unsuccess','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',61),(419,10,10,110,'Bank Reconciliation ','chinmay',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','Unprocessed','unsuccess','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',62),(420,5,5,105,'Sales ','chinmay',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','Unprocessed','unsuccess','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',63),(421,5,5,105,'Debit-card ','chinmay',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','Unprocessed','unsuccess','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',64),(422,5,5,105,'Motor ','chinmay',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','Unprocessed','unsuccess','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',65),(423,5,5,105,'Sales ','chinmay',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','Unprocessed','unsuccess','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',66),(424,5,5,105,'Bank Reconciliation ','chinmay',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','processed','success','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',67),(425,5,5,105,'Bank Reconciliation ','chinmay',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','processed','success','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',68),(426,5,5,105,'Debit-card ','chinmay',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','processed','success','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',69),(427,15,15,115,'Motor fleet Process','chinmay',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','processed','success','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',70),(428,15,15,115,'Motor fleet Process','chinmay',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','processed','success','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',71),(429,15,15,115,'Motor fleet Process','chinmay',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','processed','success','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',72),(430,15,15,115,'Motor fleet Process','chinmay',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','Unprocessed','unsuccess','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',73),(431,15,15,115,'Motor fleet Process','chinmay',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','Unprocessed','unsuccess','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',74),(432,15,15,115,'Account closure process','chinmay',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','Unprocessed','unsuccess','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',75),(433,12,12,112,'Bank Reconciliation','chinmay',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','Unprocessed','unsuccess','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',76),(434,12,12,112,'Accounts payable','chinmay',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','Unprocessed','unsuccess','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',77),(435,12,12,112,'Mortgage processing','chinmay',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','Unprocessed','unsuccess','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',78),(436,12,12,112,'Bank Reconciliation','chinmay',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','Unprocessed','unsuccess','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',79),(437,12,12,112,'Accounts payable','chinmay',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','processed','success','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',80),(438,20,20,120,'Credit card application processing','chinmay',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','processed','success','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',81),(439,20,20,120,'Bank Reconciliation','chinmay',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','processed','success','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',82),(440,20,20,120,'Motor fleet Process','chinmay',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','processed','success','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',83),(441,20,20,120,'Motor ','chinmay',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','processed','success','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',84),(442,20,20,120,'Motor fleet Process','chinmay',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','processed','success','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',85),(443,20,20,120,'Debit-card ','chinmay',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','Unprocessed','unsuccess','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',86),(444,20,20,120,'Sales ','chinmay',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','Unprocessed','unsuccess','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',87),(445,35,35,135,'Motor ','chinmay',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','Unprocessed','unsuccess','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',88),(446,35,35,135,'Sales ','chinmay',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','Unprocessed','unsuccess','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',89),(447,35,35,135,'Accounts payable ','chinmay',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','Unprocessed','unsuccess','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',90),(448,35,35,135,'Sales ','chinmay',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','Unprocessed','unsuccess','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',91),(449,35,35,135,'Debit-card ','chinmay',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','Unprocessed','unsuccess','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',92),(450,35,35,135,'Bank Reconciliation ','chinmay',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','Unprocessed','unsuccess','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',93),(451,35,35,135,'Sales ','chinmay',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','Unprocessed','unsuccess','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',94),(452,35,35,135,'Bank Reconciliation ','chinmay',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','processed','success','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',95),(453,35,35,135,'Bank Reconciliation ','chinmay',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','processed','success','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',96),(454,35,35,135,'Sales ','chinmay',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','processed','success','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',97),(455,35,35,135,'Debit-card ','chinmay',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','processed','success','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',98),(456,35,35,135,'Motor ','chinmay',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','processed','success','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',99),(457,9,9,109,'Sales ','chinmay',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','processed','success','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',100),(458,9,9,109,'Bank Reconciliation ','chinmay',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','Unprocessed','unsuccess','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',101),(459,9,9,109,'Bank Reconciliation ','chinmay',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','Unprocessed','unsuccess','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',102),(460,9,9,109,'Debit-card ','chinmay',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','Unprocessed','unsuccess','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',103),(461,9,9,109,'Motor fleet Process','chinmay',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','Unprocessed','unsuccess','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',104),(462,9,9,109,'Motor fleet Process','chinmay',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','Unprocessed','unsuccess','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',105),(463,9,9,109,'Motor fleet Process','chinmay',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','Unprocessed','unsuccess','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',106),(464,9,9,109,'Motor fleet Process','chinmay',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','Unprocessed','unsuccess','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',107),(465,9,9,109,'Motor fleet Process','chinmay',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','Unprocessed','unsuccess','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',108),(466,9,9,109,'Account closure process','chinmay',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','Unprocessed','unsuccess','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',109),(467,9,9,109,'Bank Reconciliation','chinmay',214,'2024-05-30 20:26:12','2024-05-30 20:26:12','Unprocessed','unsuccess','2024-05-30 20:26:12','gayatri','2024-05-30 20:26:12','Admin',110),(468,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-05-30 20:52:00','2024-05-30 20:52:00','processed','success','2024-05-30 20:52:00','Kashmeera','2024-05-30 20:52:00','Mansi',1),(469,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-05-30 20:52:00','2024-05-30 20:52:00','Unprocessed','success','2024-05-30 20:52:00','Kashmeera','2024-05-30 20:52:00','Mansi',2),(470,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-05-30 20:52:00','2024-05-30 20:52:00','processed','success','2024-05-30 20:52:00','Kashmeera','2024-05-30 20:52:00','Mansi',3),(471,2,2,102,'Motor fleet Process','PriyankaYadav',211,'2024-05-30 20:52:00','2024-05-30 20:52:00','processed','success','2024-05-30 20:52:00','Kashmeera','2024-05-30 20:52:00','Mansi',4),(472,2,2,102,'Motor fleet Process','PriyankaYadav',211,'2024-05-30 20:52:00','2024-05-30 20:52:00','processed','success','2024-05-30 20:52:00','Kashmeera','2024-05-30 20:52:00','Mansi',5),(473,2,2,102,'Account closure process','Aishwarya',211,'2024-05-30 20:52:00','2024-05-30 20:52:00','processed','success','2024-05-30 20:52:00','Kashmeera','2024-05-30 20:52:00','Admin',6),(474,2,2,102,'Bank Reconciliation','Shivani',211,'2024-05-30 20:52:00','2024-05-30 20:52:00','Unprocessed','success','2024-05-30 20:52:00','Kashmeera','2024-05-30 20:52:00','Admin',7),(475,3,3,103,'Accounts payable','Monika',211,'2024-05-30 20:52:00','2024-05-30 20:52:00','processed','success','2024-05-30 20:52:00','Kashmeera','2024-05-30 20:52:00','Admin',8),(476,3,3,103,'Mortgage processing','Akshay',211,'2024-05-30 20:52:00','2024-05-30 20:52:00','processed','Unprocessed','2024-05-30 20:52:00','Kashmeera','2024-05-30 20:52:00','Admin',9),(477,3,3,103,'Bank Reconciliation','Cinmay',211,'2024-05-30 20:52:00','2024-05-30 20:52:00','processed','Unprocessed','2024-05-30 20:52:00','Kashmeera','2024-05-30 20:52:00','Admin',10),(478,3,3,103,'Accounts payable','Monika',211,'2024-05-30 20:52:00','2024-05-30 20:52:00','processed','success','2024-05-30 20:52:00','Kashmeera','2024-05-30 20:52:00','Admin',11),(479,3,3,103,'Credit card application processing','Akshay',211,'2024-05-30 20:52:00','2024-05-30 20:52:00','processed','Unprocessed','2024-05-30 20:52:00','Kashmeera','2024-05-30 20:52:00','Admin',12),(480,3,3,103,'Bank Reconciliation','Cinmay',211,'2024-05-30 20:52:00','2024-05-30 20:52:00','processed','Unprocessed','2024-05-30 20:52:00','Kashmeera','2024-05-30 20:52:00','Admin',13),(481,3,3,103,'Motor','Deepak',213,'2024-05-30 20:52:00','2024-05-30 20:52:00','Unprocessed','unsuccess','2024-05-30 20:52:00','Kashmira','2024-05-30 20:52:00','Admin',15),(482,10,10,110,'Motor fleet Process','PriyankaYadav',211,'2024-05-30 20:52:00','2024-05-30 20:52:00','processed','success','2024-05-30 20:52:00','Kashmeera','2024-05-30 20:52:00','Mansi',16),(483,10,10,110,'Debit-card','Sandesh',213,'2024-05-30 20:52:00','2024-05-30 20:52:00','Unprocessed','unsuccess','2024-05-30 20:52:00','gayatri','2024-05-30 20:52:00','Admin',17),(484,10,10,110,'Sales','Amit',213,'2024-05-30 20:52:00','2024-05-30 20:52:00','Unprocessed','unsuccess','2024-05-30 20:52:00','gayatri','2024-05-30 20:52:00','Admin',18),(485,10,10,110,'Motor','Amit',213,'2024-05-30 20:52:00','2024-05-30 20:52:00','processed','unsuccess','2024-05-30 20:52:00','gayatri','2024-05-30 20:52:00','Admin',19),(486,10,10,110,'Sales','Amit',213,'2024-05-30 20:52:00','2024-05-30 20:52:00','processed','unsuccess','2024-05-30 20:52:00','gayatri','2024-05-30 20:52:00','Admin',20),(487,10,10,110,'Accounts payable','Amit',213,'2024-05-30 20:52:00','2024-05-30 20:52:00','processed','unsuccess','2024-05-30 20:52:00','gayatri','2024-05-30 20:52:00','Admin',21),(488,10,10,110,'Sales','Amit',213,'2024-05-30 20:52:00','2024-05-30 20:52:00','processed','unsuccess','2024-05-30 20:52:00','gayatri','2024-05-30 20:52:00','Admin',22),(489,10,10,110,'Debit-card','Amit',213,'2024-05-30 20:52:00','2024-05-30 20:52:00','Unprocessed','unsuccess','2024-05-30 20:52:00','gayatri','2024-05-30 20:52:00','Admin',24),(490,10,10,110,'Bank Reconciliation','Amit',213,'2024-05-30 20:52:00','2024-05-30 20:52:00','Unprocessed','unsuccess','2024-05-30 20:52:00','gayatri','2024-05-30 20:52:00','Admin',25),(491,10,10,110,'Sales','Amit',213,'2024-05-30 20:52:00','2024-05-30 20:52:00','processed','unsuccess','2024-05-30 20:52:00','gayatri','2024-05-30 20:52:00','Admin',26),(492,10,10,110,'Bank Reconciliation','Amit',213,'2024-05-30 20:52:00','2024-05-30 20:52:00','Unprocessed','unsuccess','2024-05-30 20:52:00','gayatri','2024-05-30 20:52:00','Admin',27),(493,5,5,105,'Bank Reconciliation','Amit',213,'2024-05-30 20:52:00','2024-05-30 20:52:00','processed','unsuccess','2024-05-30 20:52:00','gayatri','2024-05-30 20:52:00','Admin',28),(494,5,5,105,'Sales','Amit',213,'2024-05-30 20:52:00','2024-05-30 20:52:00','Unprocessed','unsuccess','2024-05-30 20:52:00','gayatri','2024-05-30 20:52:00','Admin',29),(495,5,5,105,'Debit-card','Amit',213,'2024-05-30 20:52:00','2024-05-30 20:52:00','Unprocessed','unsuccess','2024-05-30 20:52:00','gayatri','2024-05-30 20:52:00','Admin',30),(496,5,5,105,'Motor','Amit',213,'2024-05-30 20:52:00','2024-05-30 20:52:00','Unprocessed','unsuccess','2024-05-30 20:52:00','gayatri','2024-05-30 20:52:00','Admin',31),(497,5,5,105,'Sales','Amit',213,'2024-05-30 20:52:00','2024-05-30 20:52:00','processed','unsuccess','2024-05-30 20:52:00','gayatri','2024-05-30 20:52:00','Admin',32),(498,5,5,105,'Bank Reconciliation','Amit',213,'2024-05-30 20:52:00','2024-05-30 20:52:00','Unprocessed','unsuccess','2024-05-30 20:52:00','gayatri','2024-05-30 20:52:00','Admin',33),(499,5,5,105,'Bank Reconciliation','Amit',213,'2024-05-30 20:52:00','2024-05-30 20:52:00','Unprocessed','unsuccess','2024-05-30 20:52:00','gayatri','2024-05-30 20:52:00','Admin',34),(500,15,15,115,'Debit-card','Amit',213,'2024-05-30 20:52:00','2024-05-30 20:52:00','Unprocessed','unsuccess','2024-05-30 20:52:00','gayatri','2024-05-30 20:52:00','Admin',35),(501,1,1,101,'Motor fleet Process','aiswarya',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','Unprocessed','unsuccess','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',36),(502,1,1,101,'Motor fleet Process','aiswarya',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','Unprocessed','unsuccess','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',37),(503,1,1,101,'Motor fleet Process','aiswarya',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','processed','success','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',38),(504,1,1,101,'Motor fleet Process','aiswarya',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','processed','success','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',39),(505,1,1,101,'Motor fleet Process','aiswarya',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','processed','success','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',40),(506,2,2,102,'Account closure process','aiswarya',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','processed','success','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',41),(507,2,2,102,'Bank Reconciliation','aiswarya',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','processed','success','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',42),(508,2,2,102,'Accounts payable','aiswarya',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','processed','success','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',43),(509,2,2,102,'Mortgage processing','aiswarya',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','processed','success','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',44),(510,3,3,103,'Bank Reconciliation','aiswarya',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','processed','success','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',45),(511,3,3,103,'Accounts payable','aiswarya',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','processed','success','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',46),(512,3,3,103,'Credit card application processing','aiswarya',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','processed','success','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',47),(513,3,3,103,'Bank Reconciliation','aiswarya',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','processed','success','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',48),(514,3,3,103,'Motor fleet Process','aiswarya',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','Unprocessed','unsuccess','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',49),(515,3,3,103,'Motor ','aiswarya',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','Unprocessed','unsuccess','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',50),(516,3,3,103,'Motor fleet Process','aiswarya',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','Unprocessed','unsuccess','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',51),(517,10,10,110,'Debit-card ','aiswarya',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','Unprocessed','unsuccess','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',52),(518,10,10,110,'Sales ','aiswarya',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','Unprocessed','unsuccess','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',53),(519,10,10,110,'Motor ','aiswarya',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','Unprocessed','unsuccess','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',54),(520,10,10,110,'Sales ','aiswarya',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','processed','success','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',55),(521,10,10,110,'Accounts payable ','aiswarya',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','processed','success','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',56),(522,10,10,110,'Sales ','aiswarya',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','processed','success','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',57),(523,10,10,110,'Debit-card ','aiswarya',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','processed','success','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',58),(524,10,10,110,'Bank Reconciliation ','aiswarya',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','Unprocessed','unsuccess','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',59),(525,10,10,110,'Sales ','chinmay',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','Unprocessed','unsuccess','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',60),(526,10,10,110,'Bank Reconciliation ','chinmay',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','Unprocessed','unsuccess','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',61),(527,10,10,110,'Bank Reconciliation ','chinmay',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','Unprocessed','unsuccess','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',62),(528,5,5,105,'Sales ','chinmay',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','Unprocessed','unsuccess','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',63),(529,5,5,105,'Debit-card ','chinmay',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','Unprocessed','unsuccess','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',64),(530,5,5,105,'Motor ','chinmay',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','Unprocessed','unsuccess','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',65),(531,5,5,105,'Sales ','chinmay',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','Unprocessed','unsuccess','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',66),(532,5,5,105,'Bank Reconciliation ','chinmay',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','processed','success','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',67),(533,5,5,105,'Bank Reconciliation ','chinmay',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','processed','success','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',68),(534,5,5,105,'Debit-card ','chinmay',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','processed','success','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',69),(535,15,15,115,'Motor fleet Process','chinmay',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','processed','success','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',70),(536,15,15,115,'Motor fleet Process','chinmay',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','processed','success','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',71),(537,15,15,115,'Motor fleet Process','chinmay',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','processed','success','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',72),(538,15,15,115,'Motor fleet Process','chinmay',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','Unprocessed','unsuccess','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',73),(539,15,15,115,'Motor fleet Process','chinmay',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','Unprocessed','unsuccess','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',74),(540,15,15,115,'Account closure process','chinmay',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','Unprocessed','unsuccess','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',75),(541,12,12,112,'Bank Reconciliation','chinmay',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','Unprocessed','unsuccess','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',76),(542,12,12,112,'Accounts payable','chinmay',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','Unprocessed','unsuccess','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',77),(543,12,12,112,'Mortgage processing','chinmay',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','Unprocessed','unsuccess','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',78),(544,12,12,112,'Bank Reconciliation','chinmay',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','Unprocessed','unsuccess','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',79),(545,12,12,112,'Accounts payable','chinmay',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','processed','success','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',80),(546,20,20,120,'Credit card application processing','chinmay',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','processed','success','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',81),(547,20,20,120,'Bank Reconciliation','chinmay',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','processed','success','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',82),(548,20,20,120,'Motor fleet Process','chinmay',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','processed','success','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',83),(549,20,20,120,'Motor ','chinmay',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','processed','success','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',84),(550,20,20,120,'Motor fleet Process','chinmay',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','processed','success','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',85),(551,20,20,120,'Debit-card ','chinmay',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','Unprocessed','unsuccess','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',86),(552,20,20,120,'Sales ','chinmay',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','Unprocessed','unsuccess','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',87),(553,35,35,135,'Motor ','chinmay',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','Unprocessed','unsuccess','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',88),(554,35,35,135,'Sales ','chinmay',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','Unprocessed','unsuccess','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',89),(555,35,35,135,'Accounts payable ','chinmay',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','Unprocessed','unsuccess','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',90),(556,35,35,135,'Sales ','chinmay',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','Unprocessed','unsuccess','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',91),(557,35,35,135,'Debit-card ','chinmay',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','Unprocessed','unsuccess','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',92),(558,35,35,135,'Bank Reconciliation ','chinmay',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','Unprocessed','unsuccess','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',93),(559,35,35,135,'Sales ','chinmay',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','Unprocessed','unsuccess','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',94),(560,35,35,135,'Bank Reconciliation ','chinmay',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','processed','success','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',95),(561,35,35,135,'Bank Reconciliation ','chinmay',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','processed','success','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',96),(562,35,35,135,'Sales ','chinmay',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','processed','success','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',97),(563,35,35,135,'Debit-card ','chinmay',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','processed','success','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',98),(564,35,35,135,'Motor ','chinmay',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','processed','success','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',99),(565,9,9,109,'Sales ','chinmay',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','processed','success','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',100),(566,9,9,109,'Bank Reconciliation ','chinmay',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','Unprocessed','unsuccess','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',101),(567,9,9,109,'Bank Reconciliation ','chinmay',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','Unprocessed','unsuccess','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',102),(568,9,9,109,'Debit-card ','chinmay',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','Unprocessed','unsuccess','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',103),(569,9,9,109,'Motor fleet Process','chinmay',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','Unprocessed','unsuccess','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',104),(570,9,9,109,'Motor fleet Process','chinmay',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','Unprocessed','unsuccess','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',105),(571,9,9,109,'Motor fleet Process','chinmay',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','Unprocessed','unsuccess','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',106),(572,9,9,109,'Motor fleet Process','chinmay',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','Unprocessed','unsuccess','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',107),(573,9,9,109,'Motor fleet Process','chinmay',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','Unprocessed','unsuccess','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',108),(574,9,9,109,'Account closure process','chinmay',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','Unprocessed','unsuccess','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',109),(575,9,9,109,'Bank Reconciliation','chinmay',214,'2024-05-30 20:52:01','2024-05-30 20:52:01','Unprocessed','unsuccess','2024-05-30 20:52:01','gayatri','2024-05-30 20:52:01','Admin',110),(576,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-05-30 23:05:55','2024-05-30 23:05:55','processed','success','2024-05-30 23:05:55','Kashmeera','2024-05-30 23:05:55','Mansi',1),(577,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-05-30 23:05:55','2024-05-30 23:05:55','Unprocessed','success','2024-05-30 23:05:55','Kashmeera','2024-05-30 23:05:55','Mansi',2),(578,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-05-30 23:05:55','2024-05-30 23:05:55','processed','success','2024-05-30 23:05:55','Kashmeera','2024-05-30 23:05:55','Mansi',3),(579,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-05-31 12:14:17','2024-05-31 12:14:17','processed','success','2024-05-31 12:14:17','Kashmeera','2024-05-31 12:14:17','Mansi',1),(580,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-05-31 12:14:17','2024-05-31 12:14:17','Unprocessed','success','2024-05-31 12:14:17','Kashmeera','2024-05-31 12:14:17','Mansi',2),(581,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-05-31 12:14:17','2024-05-31 12:14:17','processed','success','2024-05-31 12:14:17','Kashmeera','2024-05-31 12:14:17','Mansi',3),(582,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-05-31 12:30:14','2024-05-31 12:30:14','processed','success','2024-05-31 12:30:14','Kashmeera','2024-05-31 12:30:14','Mansi',1),(583,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-05-31 12:30:14','2024-05-31 12:30:14','Unprocessed','success','2024-05-31 12:30:14','Kashmeera','2024-05-31 12:30:14','Mansi',2),(584,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-05-31 12:30:14','2024-05-31 12:30:14','processed','success','2024-05-31 12:30:14','Kashmeera','2024-05-31 12:30:14','Mansi',3),(585,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-05-31 12:33:31','2024-05-31 12:33:31','processed','success','2024-05-31 12:33:31','Kashmeera','2024-05-31 12:33:31','Mansi',1),(586,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-05-31 12:33:31','2024-05-31 12:33:31','Unprocessed','success','2024-05-31 12:33:31','Kashmeera','2024-05-31 12:33:31','Mansi',2),(587,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-05-31 12:33:31','2024-05-31 12:33:31','processed','success','2024-05-31 12:33:31','Kashmeera','2024-05-31 12:33:31','Mansi',3),(588,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-05-31 12:39:45','2024-05-31 12:39:45','processed','success','2024-05-31 12:39:45','Kashmeera','2024-05-31 12:39:45','Mansi',1),(589,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-05-31 12:39:45','2024-05-31 12:39:45','Unprocessed','success','2024-05-31 12:39:45','Kashmeera','2024-05-31 12:39:45','Mansi',2),(590,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-05-31 12:39:45','2024-05-31 12:39:45','processed','success','2024-05-31 12:39:45','Kashmeera','2024-05-31 12:39:45','Mansi',3),(591,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-01 09:41:56','2024-06-01 09:41:56','processed','success','2024-06-01 09:41:56','Kashmeera','2024-06-01 09:41:56','Mansi',1),(592,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-01 09:41:56','2024-06-01 09:41:56','Unprocessed','success','2024-06-01 09:41:56','Kashmeera','2024-06-01 09:41:56','Mansi',2),(593,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-01 09:41:56','2024-06-01 09:41:56','processed','success','2024-06-01 09:41:56','Kashmeera','2024-06-01 09:41:56','Mansi',3),(594,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-01 10:01:53','2024-06-01 10:01:53','processed','success','2024-06-01 10:01:53','Kashmeera','2024-06-01 10:01:53','Mansi',1),(595,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-01 10:02:59','2024-06-01 10:02:59','Unprocessed','success','2024-06-01 10:02:59','Kashmeera','2024-06-01 10:02:59','Mansi',2),(596,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-01 10:03:29','2024-06-01 10:03:29','processed','success','2024-06-01 10:03:29','Kashmeera','2024-06-01 10:03:29','Mansi',3),(597,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-01 23:43:41','2024-06-01 23:43:41','processed','success','2024-06-01 23:43:41','Kashmeera','2024-06-01 23:43:41','Mansi',1),(598,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-01 23:43:41','2024-06-01 23:43:41','Unprocessed','success','2024-06-01 23:43:41','Kashmeera','2024-06-01 23:43:41','Mansi',2),(599,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-01 23:43:41','2024-06-01 23:43:41','processed','success','2024-06-01 23:43:41','Kashmeera','2024-06-01 23:43:41','Mansi',3),(600,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-01 23:46:07','2024-06-01 23:46:07','processed','success','2024-06-01 23:46:07','Kashmeera','2024-06-01 23:46:07','Mansi',1),(601,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-01 23:46:07','2024-06-01 23:46:07','Unprocessed','success','2024-06-01 23:46:07','Kashmeera','2024-06-01 23:46:07','Mansi',2),(602,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-01 23:46:07','2024-06-01 23:46:07','processed','success','2024-06-01 23:46:07','Kashmeera','2024-06-01 23:46:07','Mansi',3),(603,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-01 23:48:24','2024-06-01 23:48:24','processed','success','2024-06-01 23:48:24','Kashmeera','2024-06-01 23:48:24','Mansi',1),(604,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-01 23:48:24','2024-06-01 23:48:24','Unprocessed','success','2024-06-01 23:48:24','Kashmeera','2024-06-01 23:48:24','Mansi',2),(605,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-01 23:48:24','2024-06-01 23:48:24','processed','success','2024-06-01 23:48:24','Kashmeera','2024-06-01 23:48:24','Mansi',3),(606,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-01 23:52:20','2024-06-01 23:52:20','processed','success','2024-06-01 23:52:20','Kashmeera','2024-06-01 23:52:20','Mansi',1),(607,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-01 23:52:20','2024-06-01 23:52:20','Unprocessed','success','2024-06-01 23:52:20','Kashmeera','2024-06-01 23:52:20','Mansi',2),(608,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-01 23:52:20','2024-06-01 23:52:20','processed','success','2024-06-01 23:52:20','Kashmeera','2024-06-01 23:52:20','Mansi',3),(609,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-01 23:54:05','2024-06-01 23:54:05','processed','success','2024-06-01 23:54:05','Kashmeera','2024-06-01 23:54:05','Mansi',1),(610,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-01 23:54:05','2024-06-01 23:54:05','Unprocessed','success','2024-06-01 23:54:05','Kashmeera','2024-06-01 23:54:05','Mansi',2),(611,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-01 23:54:05','2024-06-01 23:54:05','processed','success','2024-06-01 23:54:05','Kashmeera','2024-06-01 23:54:05','Mansi',3),(612,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-01 23:56:14','2024-06-01 23:56:14','processed','success','2024-06-01 23:56:14','Kashmeera','2024-06-01 23:56:14','Mansi',1),(613,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-01 23:56:14','2024-06-01 23:56:14','Unprocessed','success','2024-06-01 23:56:14','Kashmeera','2024-06-01 23:56:14','Mansi',2),(614,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-01 23:56:14','2024-06-01 23:56:14','processed','success','2024-06-01 23:56:14','Kashmeera','2024-06-01 23:56:14','Mansi',3),(615,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-01 23:59:20','2024-06-01 23:59:20','processed','success','2024-06-01 23:59:20','Kashmeera','2024-06-01 23:59:20','Mansi',1),(616,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-01 23:59:20','2024-06-01 23:59:20','Unprocessed','success','2024-06-01 23:59:20','Kashmeera','2024-06-01 23:59:20','Mansi',2),(617,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-01 23:59:20','2024-06-01 23:59:20','processed','success','2024-06-01 23:59:20','Kashmeera','2024-06-01 23:59:20','Mansi',3),(627,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-02 00:06:03','2024-06-02 00:06:03','processed','success','2024-06-02 00:06:03','Kashmeera','2024-06-02 00:06:03','Mansi',1),(628,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-02 00:06:03','2024-06-02 00:06:03','Unprocessed','success','2024-06-02 00:06:03','Kashmeera','2024-06-02 00:06:03','Mansi',2),(629,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-02 00:06:03','2024-06-02 00:06:03','processed','success','2024-06-02 00:06:03','Kashmeera','2024-06-02 00:06:03','Mansi',3),(633,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-02 00:39:24','2024-06-02 00:39:24','processed','success','2024-06-02 00:39:24','Kashmeera','2024-06-02 00:39:24','Mansi',1),(634,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-02 00:39:24','2024-06-02 00:39:24','Unprocessed','success','2024-06-02 00:39:24','Kashmeera','2024-06-02 00:39:24','Mansi',2),(635,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-02 00:39:24','2024-06-02 00:39:24','processed','success','2024-06-02 00:39:24','Kashmeera','2024-06-02 00:39:24','Mansi',3),(636,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-03 12:28:59','2024-06-03 12:28:59','processed','success','2024-06-03 12:28:59','Kashmeera','2024-06-03 12:28:59','Mansi',1),(637,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-03 12:28:59','2024-06-03 12:28:59','Unprocessed','success','2024-06-03 12:28:59','Kashmeera','2024-06-03 12:28:59','Mansi',2),(638,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-03 12:28:59','2024-06-03 12:28:59','processed','success','2024-06-03 12:28:59','Kashmeera','2024-06-03 12:28:59','Mansi',3),(639,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-03 13:51:25','2024-06-03 13:51:25','processed','success','2024-06-03 13:51:25','Kashmeera','2024-06-03 13:51:25','Mansi',1),(640,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-03 13:51:25','2024-06-03 13:51:25','Unprocessed','success','2024-06-03 13:51:25','Kashmeera','2024-06-03 13:51:25','Mansi',2),(641,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-03 13:51:25','2024-06-03 13:51:25','processed','success','2024-06-03 13:51:25','Kashmeera','2024-06-03 13:51:25','Mansi',3),(642,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-03 15:00:32','2024-06-03 15:00:32','processed','success','2024-06-03 15:00:32','Kashmeera','2024-06-03 15:00:32','Mansi',1),(643,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-03 15:00:33','2024-06-03 15:00:33','Unprocessed','success','2024-06-03 15:00:33','Kashmeera','2024-06-03 15:00:33','Mansi',2),(644,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-03 15:00:33','2024-06-03 15:00:33','processed','success','2024-06-03 15:00:33','Kashmeera','2024-06-03 15:00:33','Mansi',3),(645,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-03 15:02:08','2024-06-03 15:02:08','processed','success','2024-06-03 15:02:08','Kashmeera','2024-06-03 15:02:08','Mansi',1),(646,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-03 15:02:08','2024-06-03 15:02:08','Unprocessed','success','2024-06-03 15:02:08','Kashmeera','2024-06-03 15:02:08','Mansi',2),(647,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-03 15:02:08','2024-06-03 15:02:08','processed','success','2024-06-03 15:02:08','Kashmeera','2024-06-03 15:02:08','Mansi',3),(648,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-03 15:44:34','2024-06-03 15:44:34','processed','success','2024-06-03 15:44:34','Kashmeera','2024-06-03 15:44:34','Mansi',1),(649,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-03 15:44:34','2024-06-03 15:44:34','Unprocessed','success','2024-06-03 15:44:34','Kashmeera','2024-06-03 15:44:34','Mansi',2),(650,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-03 15:44:34','2024-06-03 15:44:34','processed','success','2024-06-03 15:44:34','Kashmeera','2024-06-03 15:44:34','Mansi',3),(651,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-03 17:20:41','2024-06-03 17:20:41','processed','success','2024-06-03 17:20:41','Kashmeera','2024-06-03 17:20:41','Mansi',1),(652,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-03 17:20:41','2024-06-03 17:20:41','Unprocessed','success','2024-06-03 17:20:41','Kashmeera','2024-06-03 17:20:41','Mansi',2),(653,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-03 17:20:41','2024-06-03 17:20:41','processed','success','2024-06-03 17:20:41','Kashmeera','2024-06-03 17:20:41','Mansi',3),(1033,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-19 17:58:23','2024-06-19 17:58:23','processed','success','2024-06-19 17:58:23','Kashmeera','2024-06-19 17:58:23','Mansi',3),(1034,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-19 18:00:09','2024-06-19 18:00:09','processed','success','2024-06-19 18:00:09','Kashmeera','2024-06-19 18:00:09','Mansi',1),(1035,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-19 18:00:09','2024-06-19 18:00:09','Unprocessed','success','2024-06-19 18:00:09','Kashmeera','2024-06-19 18:00:09','Mansi',2),(1036,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-19 18:00:09','2024-06-19 18:00:09','processed','success','2024-06-19 18:00:09','Kashmeera','2024-06-19 18:00:09','Mansi',3),(1037,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-19 18:01:05','2024-06-19 18:01:05','processed','success','2024-06-19 18:01:05','Kashmeera','2024-06-19 18:01:05','Mansi',1),(1038,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-19 18:01:05','2024-06-19 18:01:05','Unprocessed','success','2024-06-19 18:01:05','Kashmeera','2024-06-19 18:01:05','Mansi',2),(1039,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-19 18:01:05','2024-06-19 18:01:05','processed','success','2024-06-19 18:01:05','Kashmeera','2024-06-19 18:01:05','Mansi',3),(1040,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-19 18:14:23','2024-06-19 18:14:23','processed','success','2024-06-19 18:14:23','Kashmeera','2024-06-19 18:14:23','Mansi',1),(1041,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-19 18:14:23','2024-06-19 18:14:23','Unprocessed','success','2024-06-19 18:14:23','Kashmeera','2024-06-19 18:14:23','Mansi',2),(1042,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-19 18:14:23','2024-06-19 18:14:23','processed','success','2024-06-19 18:14:23','Kashmeera','2024-06-19 18:14:23','Mansi',3),(1043,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-19 18:15:26','2024-06-19 18:15:26','processed','success','2024-06-19 18:15:26','Kashmeera','2024-06-19 18:15:26','Mansi',1),(1044,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-19 18:15:26','2024-06-19 18:15:26','Unprocessed','success','2024-06-19 18:15:26','Kashmeera','2024-06-19 18:15:26','Mansi',2),(1045,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-19 18:15:26','2024-06-19 18:15:26','processed','success','2024-06-19 18:15:26','Kashmeera','2024-06-19 18:15:26','Mansi',3),(1046,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-19 21:39:19','2024-06-19 21:39:19','processed','success','2024-06-19 21:39:19','Kashmeera','2024-06-19 21:39:19','Mansi',1),(1047,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-19 21:39:19','2024-06-19 21:39:19','Unprocessed','success','2024-06-19 21:39:19','Kashmeera','2024-06-19 21:39:19','Mansi',2),(1048,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-19 21:39:19','2024-06-19 21:39:19','processed','success','2024-06-19 21:39:19','Kashmeera','2024-06-19 21:39:19','Mansi',3),(1049,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-19 21:42:35','2024-06-19 21:42:35','processed','success','2024-06-19 21:42:35','Kashmeera','2024-06-19 21:42:35','Mansi',1),(1050,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-19 21:42:35','2024-06-19 21:42:35','Unprocessed','success','2024-06-19 21:42:35','Kashmeera','2024-06-19 21:42:35','Mansi',2),(1051,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-19 21:42:35','2024-06-19 21:42:35','processed','success','2024-06-19 21:42:35','Kashmeera','2024-06-19 21:42:35','Mansi',3),(1052,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-19 21:48:50','2024-06-19 21:48:50','processed','success','2024-06-19 21:48:50','Kashmeera','2024-06-19 21:48:50','Mansi',1),(1053,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-19 21:48:50','2024-06-19 21:48:50','Unprocessed','success','2024-06-19 21:48:50','Kashmeera','2024-06-19 21:48:50','Mansi',2),(1054,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-19 21:48:50','2024-06-19 21:48:50','processed','success','2024-06-19 21:48:50','Kashmeera','2024-06-19 21:48:50','Mansi',3),(1055,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 08:47:20','2024-06-20 08:47:20','processed','success','2024-06-20 08:47:20','Kashmeera','2024-06-20 08:47:20','Mansi',1),(1056,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 08:47:20','2024-06-20 08:47:20','processed','success','2024-06-20 08:47:20','Kashmeera','2024-06-20 08:47:20','Mansi',1),(1057,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 08:47:20','2024-06-20 08:47:20','Unprocessed','success','2024-06-20 08:47:20','Kashmeera','2024-06-20 08:47:20','Mansi',2),(1058,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 08:47:20','2024-06-20 08:47:20','Unprocessed','success','2024-06-20 08:47:20','Kashmeera','2024-06-20 08:47:20','Mansi',2),(1059,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 08:47:20','2024-06-20 08:47:20','processed','success','2024-06-20 08:47:20','Kashmeera','2024-06-20 08:47:20','Mansi',3),(1060,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 08:47:20','2024-06-20 08:47:20','processed','success','2024-06-20 08:47:20','Kashmeera','2024-06-20 08:47:20','Mansi',3),(1061,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 08:48:51','2024-06-20 08:48:51','processed','success','2024-06-20 08:48:51','Kashmeera','2024-06-20 08:48:51','Mansi',1),(1062,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 08:48:51','2024-06-20 08:48:51','Unprocessed','success','2024-06-20 08:48:51','Kashmeera','2024-06-20 08:48:51','Mansi',2),(1063,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 08:48:51','2024-06-20 08:48:51','processed','success','2024-06-20 08:48:51','Kashmeera','2024-06-20 08:48:51','Mansi',1),(1064,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 08:48:51','2024-06-20 08:48:51','processed','success','2024-06-20 08:48:51','Kashmeera','2024-06-20 08:48:51','Mansi',3),(1065,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 08:48:51','2024-06-20 08:48:51','Unprocessed','success','2024-06-20 08:48:51','Kashmeera','2024-06-20 08:48:51','Mansi',2),(1066,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 08:48:51','2024-06-20 08:48:51','processed','success','2024-06-20 08:48:51','Kashmeera','2024-06-20 08:48:51','Mansi',3),(1067,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 09:25:09','2024-06-20 09:25:09','processed','success','2024-06-20 09:25:09','Kashmeera','2024-06-20 09:25:09','Mansi',1),(1068,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 09:25:10','2024-06-20 09:25:10','Unprocessed','success','2024-06-20 09:25:10','Kashmeera','2024-06-20 09:25:10','Mansi',2),(1069,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 09:25:10','2024-06-20 09:25:10','processed','success','2024-06-20 09:25:10','Kashmeera','2024-06-20 09:25:10','Mansi',3),(1070,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 09:39:18','2024-06-20 09:39:18','processed','success','2024-06-20 09:39:18','Kashmeera','2024-06-20 09:39:18','Mansi',1),(1071,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 09:39:18','2024-06-20 09:39:18','Unprocessed','success','2024-06-20 09:39:18','Kashmeera','2024-06-20 09:39:18','Mansi',2),(1072,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 09:39:18','2024-06-20 09:39:18','processed','success','2024-06-20 09:39:18','Kashmeera','2024-06-20 09:39:18','Mansi',3),(1073,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 09:52:08','2024-06-20 09:52:08','processed','success','2024-06-20 09:52:08','Kashmeera','2024-06-20 09:52:08','Mansi',1),(1074,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 09:52:08','2024-06-20 09:52:08','Unprocessed','success','2024-06-20 09:52:08','Kashmeera','2024-06-20 09:52:08','Mansi',2),(1075,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 09:52:08','2024-06-20 09:52:08','processed','success','2024-06-20 09:52:08','Kashmeera','2024-06-20 09:52:08','Mansi',3),(1076,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 09:56:00','2024-06-20 09:56:00','processed','success','2024-06-20 09:56:00','Kashmeera','2024-06-20 09:56:00','Mansi',1),(1077,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 09:56:00','2024-06-20 09:56:00','Unprocessed','success','2024-06-20 09:56:00','Kashmeera','2024-06-20 09:56:00','Mansi',2),(1078,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 09:56:00','2024-06-20 09:56:00','processed','success','2024-06-20 09:56:00','Kashmeera','2024-06-20 09:56:00','Mansi',3),(1079,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 09:56:39','2024-06-20 09:56:39','processed','success','2024-06-20 09:56:39','Kashmeera','2024-06-20 09:56:39','Mansi',1),(1080,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 09:56:39','2024-06-20 09:56:39','Unprocessed','success','2024-06-20 09:56:39','Kashmeera','2024-06-20 09:56:39','Mansi',2),(1081,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 09:56:39','2024-06-20 09:56:39','processed','success','2024-06-20 09:56:39','Kashmeera','2024-06-20 09:56:39','Mansi',3),(1082,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 10:18:07','2024-06-20 10:18:07','processed','success','2024-06-20 10:18:07','Kashmeera','2024-06-20 10:18:07','Mansi',1),(1083,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 10:18:07','2024-06-20 10:18:07','Unprocessed','success','2024-06-20 10:18:07','Kashmeera','2024-06-20 10:18:07','Mansi',2),(1084,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 10:18:07','2024-06-20 10:18:07','processed','success','2024-06-20 10:18:07','Kashmeera','2024-06-20 10:18:07','Mansi',3),(1085,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 10:20:00','2024-06-20 10:20:00','processed','success','2024-06-20 10:20:00','Kashmeera','2024-06-20 10:20:00','Mansi',1),(1086,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 10:20:00','2024-06-20 10:20:00','Unprocessed','success','2024-06-20 10:20:00','Kashmeera','2024-06-20 10:20:00','Mansi',2),(1087,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 10:20:00','2024-06-20 10:20:00','processed','success','2024-06-20 10:20:00','Kashmeera','2024-06-20 10:20:00','Mansi',3),(1088,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 10:24:01','2024-06-20 10:24:01','processed','success','2024-06-20 10:24:01','Kashmeera','2024-06-20 10:24:01','Mansi',1),(1089,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 10:24:01','2024-06-20 10:24:01','Unprocessed','success','2024-06-20 10:24:01','Kashmeera','2024-06-20 10:24:01','Mansi',2),(1090,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 10:24:01','2024-06-20 10:24:01','processed','success','2024-06-20 10:24:01','Kashmeera','2024-06-20 10:24:01','Mansi',3),(1091,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 10:26:19','2024-06-20 10:26:19','processed','success','2024-06-20 10:26:19','Kashmeera','2024-06-20 10:26:19','Mansi',1),(1092,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 10:26:19','2024-06-20 10:26:19','Unprocessed','success','2024-06-20 10:26:19','Kashmeera','2024-06-20 10:26:19','Mansi',2),(1093,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 10:26:19','2024-06-20 10:26:19','processed','success','2024-06-20 10:26:19','Kashmeera','2024-06-20 10:26:19','Mansi',3),(1094,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 12:40:27','2024-06-20 12:40:27','processed','success','2024-06-20 12:40:27','Kashmeera','2024-06-20 12:40:27','Mansi',1),(1095,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 12:40:27','2024-06-20 12:40:27','Unprocessed','success','2024-06-20 12:40:27','Kashmeera','2024-06-20 12:40:27','Mansi',2),(1096,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 12:40:27','2024-06-20 12:40:27','processed','success','2024-06-20 12:40:27','Kashmeera','2024-06-20 12:40:27','Mansi',3),(1097,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 12:49:10','2024-06-20 12:49:10','processed','success','2024-06-20 12:49:10','Kashmeera','2024-06-20 12:49:10','Mansi',1),(1098,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 12:49:10','2024-06-20 12:49:10','Unprocessed','success','2024-06-20 12:49:10','Kashmeera','2024-06-20 12:49:10','Mansi',2),(1099,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 12:49:10','2024-06-20 12:49:10','processed','success','2024-06-20 12:49:10','Kashmeera','2024-06-20 12:49:10','Mansi',3),(1100,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 12:51:57','2024-06-20 12:51:57','processed','success','2024-06-20 12:51:57','Kashmeera','2024-06-20 12:51:57','Mansi',1),(1101,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 12:51:57','2024-06-20 12:51:57','Unprocessed','success','2024-06-20 12:51:57','Kashmeera','2024-06-20 12:51:57','Mansi',2),(1102,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 12:51:57','2024-06-20 12:51:57','processed','success','2024-06-20 12:51:57','Kashmeera','2024-06-20 12:51:57','Mansi',3),(1103,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 12:56:53','2024-06-20 12:56:53','processed','success','2024-06-20 12:56:53','Kashmeera','2024-06-20 12:56:53','Mansi',1),(1104,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 12:56:53','2024-06-20 12:56:53','Unprocessed','success','2024-06-20 12:56:53','Kashmeera','2024-06-20 12:56:53','Mansi',2),(1105,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 12:56:53','2024-06-20 12:56:53','processed','success','2024-06-20 12:56:53','Kashmeera','2024-06-20 12:56:53','Mansi',3),(1106,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 13:01:22','2024-06-20 13:01:22','processed','success','2024-06-20 13:01:22','Kashmeera','2024-06-20 13:01:22','Mansi',1),(1107,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 13:01:22','2024-06-20 13:01:22','Unprocessed','success','2024-06-20 13:01:22','Kashmeera','2024-06-20 13:01:22','Mansi',2),(1108,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 13:01:22','2024-06-20 13:01:22','processed','success','2024-06-20 13:01:22','Kashmeera','2024-06-20 13:01:22','Mansi',3),(1109,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 13:28:11','2024-06-20 13:28:11','processed','success','2024-06-20 13:28:11','Kashmeera','2024-06-20 13:28:11','Mansi',1),(1110,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 13:28:11','2024-06-20 13:28:11','Unprocessed','success','2024-06-20 13:28:11','Kashmeera','2024-06-20 13:28:11','Mansi',2),(1111,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 13:28:11','2024-06-20 13:28:11','processed','success','2024-06-20 13:28:11','Kashmeera','2024-06-20 13:28:11','Mansi',3),(1112,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 13:31:29','2024-06-20 13:31:29','processed','success','2024-06-20 13:31:29','Kashmeera','2024-06-20 13:31:29','Mansi',1),(1113,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 13:31:29','2024-06-20 13:31:29','Unprocessed','success','2024-06-20 13:31:29','Kashmeera','2024-06-20 13:31:29','Mansi',2),(1114,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 13:31:29','2024-06-20 13:31:29','processed','success','2024-06-20 13:31:29','Kashmeera','2024-06-20 13:31:29','Mansi',3),(1115,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 13:51:58','2024-06-20 13:51:58','processed','success','2024-06-20 13:51:58','Kashmeera','2024-06-20 13:51:58','Mansi',1),(1116,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 13:51:58','2024-06-20 13:51:58','Unprocessed','success','2024-06-20 13:51:58','Kashmeera','2024-06-20 13:51:58','Mansi',2),(1117,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 13:51:58','2024-06-20 13:51:58','processed','success','2024-06-20 13:51:58','Kashmeera','2024-06-20 13:51:58','Mansi',3),(1118,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 13:52:47','2024-06-20 13:52:47','processed','success','2024-06-20 13:52:47','Kashmeera','2024-06-20 13:52:47','Mansi',1),(1119,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 13:52:47','2024-06-20 13:52:47','Unprocessed','success','2024-06-20 13:52:47','Kashmeera','2024-06-20 13:52:47','Mansi',2),(1120,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 13:52:47','2024-06-20 13:52:47','processed','success','2024-06-20 13:52:47','Kashmeera','2024-06-20 13:52:47','Mansi',3),(1121,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 18:24:38','2024-06-20 18:24:38','processed','success','2024-06-20 18:24:38','Kashmeera','2024-06-20 18:24:38','Mansi',1),(1122,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 18:24:38','2024-06-20 18:24:38','Unprocessed','success','2024-06-20 18:24:38','Kashmeera','2024-06-20 18:24:38','Mansi',2),(1123,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 18:24:38','2024-06-20 18:24:38','processed','success','2024-06-20 18:24:38','Kashmeera','2024-06-20 18:24:38','Mansi',3),(1124,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 19:17:44','2024-06-20 19:17:44','processed','success','2024-06-20 19:17:44','Kashmeera','2024-06-20 19:17:44','Mansi',1),(1125,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 19:17:44','2024-06-20 19:17:44','Unprocessed','success','2024-06-20 19:17:44','Kashmeera','2024-06-20 19:17:44','Mansi',2),(1126,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 19:17:44','2024-06-20 19:17:44','processed','success','2024-06-20 19:17:44','Kashmeera','2024-06-20 19:17:44','Mansi',3),(1127,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 19:18:42','2024-06-20 19:18:42','processed','success','2024-06-20 19:18:42','Kashmeera','2024-06-20 19:18:42','Mansi',1),(1128,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 19:18:42','2024-06-20 19:18:42','Unprocessed','success','2024-06-20 19:18:42','Kashmeera','2024-06-20 19:18:42','Mansi',2),(1129,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 19:18:42','2024-06-20 19:18:42','processed','success','2024-06-20 19:18:42','Kashmeera','2024-06-20 19:18:42','Mansi',3),(1130,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 19:18:58','2024-06-20 19:18:58','processed','success','2024-06-20 19:18:58','Kashmeera','2024-06-20 19:18:58','Mansi',1),(1131,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 19:18:58','2024-06-20 19:18:58','Unprocessed','success','2024-06-20 19:18:58','Kashmeera','2024-06-20 19:18:58','Mansi',2),(1132,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 19:18:58','2024-06-20 19:18:58','processed','success','2024-06-20 19:18:58','Kashmeera','2024-06-20 19:18:58','Mansi',3),(1133,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 19:19:20','2024-06-20 19:19:20','processed','success','2024-06-20 19:19:20','Kashmeera','2024-06-20 19:19:20','Mansi',1),(1134,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 19:19:20','2024-06-20 19:19:20','Unprocessed','success','2024-06-20 19:19:20','Kashmeera','2024-06-20 19:19:20','Mansi',2),(1135,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 19:19:20','2024-06-20 19:19:20','processed','success','2024-06-20 19:19:20','Kashmeera','2024-06-20 19:19:20','Mansi',3),(1136,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 19:19:30','2024-06-20 19:19:30','processed','success','2024-06-20 19:19:30','Kashmeera','2024-06-20 19:19:30','Mansi',1),(1137,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 19:19:30','2024-06-20 19:19:30','Unprocessed','success','2024-06-20 19:19:30','Kashmeera','2024-06-20 19:19:30','Mansi',2),(1138,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 19:19:30','2024-06-20 19:19:30','processed','success','2024-06-20 19:19:30','Kashmeera','2024-06-20 19:19:30','Mansi',3),(1139,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 19:22:18','2024-06-20 19:22:18','processed','success','2024-06-20 19:22:18','Kashmeera','2024-06-20 19:22:18','Mansi',1),(1140,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 19:22:18','2024-06-20 19:22:18','Unprocessed','success','2024-06-20 19:22:18','Kashmeera','2024-06-20 19:22:18','Mansi',2),(1141,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 19:22:18','2024-06-20 19:22:18','processed','success','2024-06-20 19:22:18','Kashmeera','2024-06-20 19:22:18','Mansi',3),(1142,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 19:23:05','2024-06-20 19:23:05','processed','success','2024-06-20 19:23:05','Kashmeera','2024-06-20 19:23:05','Mansi',1),(1143,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 19:23:05','2024-06-20 19:23:05','Unprocessed','success','2024-06-20 19:23:05','Kashmeera','2024-06-20 19:23:05','Mansi',2),(1144,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 19:23:05','2024-06-20 19:23:05','processed','success','2024-06-20 19:23:05','Kashmeera','2024-06-20 19:23:05','Mansi',3),(1145,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 19:23:18','2024-06-20 19:23:18','processed','success','2024-06-20 19:23:18','Kashmeera','2024-06-20 19:23:18','Mansi',1),(1146,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 19:23:18','2024-06-20 19:23:18','Unprocessed','success','2024-06-20 19:23:18','Kashmeera','2024-06-20 19:23:18','Mansi',2),(1147,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 19:23:18','2024-06-20 19:23:18','processed','success','2024-06-20 19:23:18','Kashmeera','2024-06-20 19:23:18','Mansi',3),(1148,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 19:23:54','2024-06-20 19:23:54','processed','success','2024-06-20 19:23:54','Kashmeera','2024-06-20 19:23:54','Mansi',1),(1149,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 19:23:54','2024-06-20 19:23:54','Unprocessed','success','2024-06-20 19:23:54','Kashmeera','2024-06-20 19:23:54','Mansi',2),(1150,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 19:23:54','2024-06-20 19:23:54','processed','success','2024-06-20 19:23:54','Kashmeera','2024-06-20 19:23:54','Mansi',3),(1151,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 19:24:43','2024-06-20 19:24:43','processed','success','2024-06-20 19:24:43','Kashmeera','2024-06-20 19:24:43','Mansi',1),(1152,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 19:24:43','2024-06-20 19:24:43','Unprocessed','success','2024-06-20 19:24:43','Kashmeera','2024-06-20 19:24:43','Mansi',2),(1153,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 19:24:43','2024-06-20 19:24:43','processed','success','2024-06-20 19:24:43','Kashmeera','2024-06-20 19:24:43','Mansi',3),(1154,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 19:29:24','2024-06-20 19:29:24','processed','success','2024-06-20 19:29:24','Kashmeera','2024-06-20 19:29:24','Mansi',1),(1155,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 19:29:24','2024-06-20 19:29:24','Unprocessed','success','2024-06-20 19:29:24','Kashmeera','2024-06-20 19:29:24','Mansi',2),(1156,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 19:29:24','2024-06-20 19:29:24','processed','success','2024-06-20 19:29:24','Kashmeera','2024-06-20 19:29:24','Mansi',3),(1157,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 19:43:18','2024-06-20 19:43:18','processed','success','2024-06-20 19:43:18','Kashmeera','2024-06-20 19:43:18','Mansi',1),(1158,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 19:43:18','2024-06-20 19:43:18','Unprocessed','success','2024-06-20 19:43:18','Kashmeera','2024-06-20 19:43:18','Mansi',2),(1159,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 19:43:18','2024-06-20 19:43:18','processed','success','2024-06-20 19:43:18','Kashmeera','2024-06-20 19:43:18','Mansi',3),(1160,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 19:45:05','2024-06-20 19:45:05','processed','success','2024-06-20 19:45:05','Kashmeera','2024-06-20 19:45:05','Mansi',1),(1161,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 19:45:05','2024-06-20 19:45:05','Unprocessed','success','2024-06-20 19:45:05','Kashmeera','2024-06-20 19:45:05','Mansi',2),(1162,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 19:45:05','2024-06-20 19:45:05','processed','success','2024-06-20 19:45:05','Kashmeera','2024-06-20 19:45:05','Mansi',3),(1163,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 19:45:18','2024-06-20 19:45:18','processed','success','2024-06-20 19:45:18','Kashmeera','2024-06-20 19:45:18','Mansi',1),(1164,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 19:45:18','2024-06-20 19:45:18','Unprocessed','success','2024-06-20 19:45:18','Kashmeera','2024-06-20 19:45:18','Mansi',2),(1165,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 19:45:18','2024-06-20 19:45:18','processed','success','2024-06-20 19:45:18','Kashmeera','2024-06-20 19:45:18','Mansi',3),(1166,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 19:49:25','2024-06-20 19:49:25','processed','success','2024-06-20 19:49:25','Kashmeera','2024-06-20 19:49:25','Mansi',1),(1167,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 19:49:25','2024-06-20 19:49:25','Unprocessed','success','2024-06-20 19:49:25','Kashmeera','2024-06-20 19:49:25','Mansi',2),(1168,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 19:49:25','2024-06-20 19:49:25','processed','success','2024-06-20 19:49:25','Kashmeera','2024-06-20 19:49:25','Mansi',3),(1169,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 19:52:10','2024-06-20 19:52:10','processed','success','2024-06-20 19:52:10','Kashmeera','2024-06-20 19:52:10','Mansi',1),(1170,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 19:52:10','2024-06-20 19:52:10','Unprocessed','success','2024-06-20 19:52:10','Kashmeera','2024-06-20 19:52:10','Mansi',2),(1171,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 19:52:10','2024-06-20 19:52:10','processed','success','2024-06-20 19:52:10','Kashmeera','2024-06-20 19:52:10','Mansi',3),(1172,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 19:55:30','2024-06-20 19:55:30','processed','success','2024-06-20 19:55:30','Kashmeera','2024-06-20 19:55:30','Mansi',1),(1173,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 19:55:30','2024-06-20 19:55:30','Unprocessed','success','2024-06-20 19:55:30','Kashmeera','2024-06-20 19:55:30','Mansi',2),(1174,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 19:55:30','2024-06-20 19:55:30','processed','success','2024-06-20 19:55:30','Kashmeera','2024-06-20 19:55:30','Mansi',3),(1175,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 19:56:14','2024-06-20 19:56:14','processed','success','2024-06-20 19:56:14','Kashmeera','2024-06-20 19:56:14','Mansi',1),(1176,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 19:56:14','2024-06-20 19:56:14','Unprocessed','success','2024-06-20 19:56:14','Kashmeera','2024-06-20 19:56:14','Mansi',2),(1177,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 19:56:14','2024-06-20 19:56:14','processed','success','2024-06-20 19:56:14','Kashmeera','2024-06-20 19:56:14','Mansi',3),(1178,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 19:56:43','2024-06-20 19:56:43','processed','success','2024-06-20 19:56:43','Kashmeera','2024-06-20 19:56:43','Mansi',1),(1179,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 19:56:43','2024-06-20 19:56:43','Unprocessed','success','2024-06-20 19:56:43','Kashmeera','2024-06-20 19:56:43','Mansi',2),(1180,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 19:56:43','2024-06-20 19:56:43','processed','success','2024-06-20 19:56:43','Kashmeera','2024-06-20 19:56:43','Mansi',3),(1181,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 20:01:18','2024-06-20 20:01:18','processed','success','2024-06-20 20:01:18','Kashmeera','2024-06-20 20:01:18','Mansi',1),(1182,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 20:01:18','2024-06-20 20:01:18','Unprocessed','success','2024-06-20 20:01:18','Kashmeera','2024-06-20 20:01:18','Mansi',2),(1183,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 20:01:18','2024-06-20 20:01:18','processed','success','2024-06-20 20:01:18','Kashmeera','2024-06-20 20:01:18','Mansi',3),(1184,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 20:02:05','2024-06-20 20:02:05','processed','success','2024-06-20 20:02:05','Kashmeera','2024-06-20 20:02:05','Mansi',1),(1185,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 20:02:05','2024-06-20 20:02:05','Unprocessed','success','2024-06-20 20:02:05','Kashmeera','2024-06-20 20:02:05','Mansi',2),(1186,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 20:02:05','2024-06-20 20:02:05','processed','success','2024-06-20 20:02:05','Kashmeera','2024-06-20 20:02:05','Mansi',3),(1187,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 20:02:58','2024-06-20 20:02:58','processed','success','2024-06-20 20:02:58','Kashmeera','2024-06-20 20:02:58','Mansi',1),(1188,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 20:02:58','2024-06-20 20:02:58','Unprocessed','success','2024-06-20 20:02:58','Kashmeera','2024-06-20 20:02:58','Mansi',2),(1189,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 20:02:58','2024-06-20 20:02:58','processed','success','2024-06-20 20:02:58','Kashmeera','2024-06-20 20:02:58','Mansi',3),(1190,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 20:03:51','2024-06-20 20:03:51','processed','success','2024-06-20 20:03:51','Kashmeera','2024-06-20 20:03:51','Mansi',1),(1191,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 20:03:51','2024-06-20 20:03:51','Unprocessed','success','2024-06-20 20:03:51','Kashmeera','2024-06-20 20:03:51','Mansi',2),(1192,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 20:03:51','2024-06-20 20:03:51','processed','success','2024-06-20 20:03:51','Kashmeera','2024-06-20 20:03:51','Mansi',3),(1193,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 20:23:58','2024-06-20 20:23:58','processed','success','2024-06-20 20:23:58','Kashmeera','2024-06-20 20:23:58','Mansi',1),(1194,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 20:23:58','2024-06-20 20:23:58','Unprocessed','success','2024-06-20 20:23:58','Kashmeera','2024-06-20 20:23:58','Mansi',2),(1195,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 20:23:58','2024-06-20 20:23:58','processed','success','2024-06-20 20:23:58','Kashmeera','2024-06-20 20:23:58','Mansi',3),(1196,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 21:31:32','2024-06-20 21:31:32','processed','success','2024-06-20 21:31:32','Kashmeera','2024-06-20 21:31:32','Mansi',1),(1197,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 21:31:32','2024-06-20 21:31:32','Unprocessed','success','2024-06-20 21:31:32','Kashmeera','2024-06-20 21:31:32','Mansi',2),(1198,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-20 21:31:32','2024-06-20 21:31:32','processed','success','2024-06-20 21:31:32','Kashmeera','2024-06-20 21:31:32','Mansi',3),(1199,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-21 11:11:06','2024-06-21 11:11:06','processed','success','2024-06-21 11:11:06','Kashmeera','2024-06-21 11:11:06','Mansi',1),(1200,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-21 11:11:06','2024-06-21 11:11:06','Unprocessed','success','2024-06-21 11:11:06','Kashmeera','2024-06-21 11:11:06','Mansi',2),(1201,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-21 11:11:06','2024-06-21 11:11:06','processed','success','2024-06-21 11:11:06','Kashmeera','2024-06-21 11:11:06','Mansi',3),(1202,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-21 11:16:55','2024-06-21 11:16:55','processed','success','2024-06-21 11:16:55','Kashmeera','2024-06-21 11:16:55','Mansi',1),(1203,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-21 11:16:55','2024-06-21 11:16:55','Unprocessed','success','2024-06-21 11:16:55','Kashmeera','2024-06-21 11:16:55','Mansi',2),(1204,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-21 11:16:55','2024-06-21 11:16:55','processed','success','2024-06-21 11:16:55','Kashmeera','2024-06-21 11:16:55','Mansi',3),(1205,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-21 11:19:38','2024-06-21 11:19:38','processed','success','2024-06-21 11:19:38','Kashmeera','2024-06-21 11:19:38','Mansi',1),(1206,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-21 11:19:38','2024-06-21 11:19:38','Unprocessed','success','2024-06-21 11:19:38','Kashmeera','2024-06-21 11:19:38','Mansi',2),(1207,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-21 11:19:38','2024-06-21 11:19:38','processed','success','2024-06-21 11:19:38','Kashmeera','2024-06-21 11:19:38','Mansi',3),(1208,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-23 16:06:29','2024-06-23 16:06:29','processed','success','2024-06-23 16:06:29','Kashmeera','2024-06-23 16:06:29','Mansi',1),(1209,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-23 16:06:29','2024-06-23 16:06:29','Unprocessed','success','2024-06-23 16:06:29','Kashmeera','2024-06-23 16:06:29','Mansi',2),(1210,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-23 16:06:29','2024-06-23 16:06:29','processed','success','2024-06-23 16:06:29','Kashmeera','2024-06-23 16:06:29','Mansi',3),(1211,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-23 16:10:10','2024-06-23 16:10:10','processed','success','2024-06-23 16:10:10','Kashmeera','2024-06-23 16:10:10','Mansi',1),(1212,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-23 16:10:10','2024-06-23 16:10:10','Unprocessed','success','2024-06-23 16:10:10','Kashmeera','2024-06-23 16:10:10','Mansi',2),(1213,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-23 16:10:10','2024-06-23 16:10:10','processed','success','2024-06-23 16:10:10','Kashmeera','2024-06-23 16:10:10','Mansi',3),(1214,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-23 16:33:27','2024-06-23 16:33:27','processed','success','2024-06-23 16:33:27','Kashmeera','2024-06-23 16:33:27','Mansi',1),(1215,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-23 16:33:27','2024-06-23 16:33:27','Unprocessed','success','2024-06-23 16:33:27','Kashmeera','2024-06-23 16:33:27','Mansi',2),(1216,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-23 16:33:27','2024-06-23 16:33:27','processed','success','2024-06-23 16:33:27','Kashmeera','2024-06-23 16:33:27','Mansi',3),(1217,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-23 16:38:52','2024-06-23 16:38:52','processed','success','2024-06-23 16:38:52','Kashmeera','2024-06-23 16:38:52','Mansi',1),(1218,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-23 16:38:52','2024-06-23 16:38:52','Unprocessed','success','2024-06-23 16:38:52','Kashmeera','2024-06-23 16:38:52','Mansi',2),(1219,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-23 16:38:52','2024-06-23 16:38:52','processed','success','2024-06-23 16:38:52','Kashmeera','2024-06-23 16:38:52','Mansi',3),(1220,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-23 16:52:01','2024-06-23 16:52:01','processed','success','2024-06-23 16:52:01','Kashmeera','2024-06-23 16:52:01','Mansi',1),(1221,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-23 16:52:01','2024-06-23 16:52:01','Unprocessed','success','2024-06-23 16:52:01','Kashmeera','2024-06-23 16:52:01','Mansi',2),(1222,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-23 16:52:01','2024-06-23 16:52:01','processed','success','2024-06-23 16:52:01','Kashmeera','2024-06-23 16:52:01','Mansi',3),(1223,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-23 16:55:25','2024-06-23 16:55:25','processed','success','2024-06-23 16:55:25','Kashmeera','2024-06-23 16:55:25','Mansi',1),(1224,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-23 16:55:25','2024-06-23 16:55:25','Unprocessed','success','2024-06-23 16:55:25','Kashmeera','2024-06-23 16:55:25','Mansi',2),(1225,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-23 16:55:25','2024-06-23 16:55:25','processed','success','2024-06-23 16:55:25','Kashmeera','2024-06-23 16:55:25','Mansi',3),(1226,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-23 16:57:34','2024-06-23 16:57:34','processed','success','2024-06-23 16:57:34','Kashmeera','2024-06-23 16:57:34','Mansi',1),(1227,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-23 16:57:34','2024-06-23 16:57:34','Unprocessed','success','2024-06-23 16:57:34','Kashmeera','2024-06-23 16:57:34','Mansi',2),(1228,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-23 16:57:34','2024-06-23 16:57:34','processed','success','2024-06-23 16:57:34','Kashmeera','2024-06-23 16:57:34','Mansi',3),(1229,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-23 16:59:20','2024-06-23 16:59:20','processed','success','2024-06-23 16:59:20','Kashmeera','2024-06-23 16:59:20','Mansi',1),(1230,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-23 16:59:20','2024-06-23 16:59:20','Unprocessed','success','2024-06-23 16:59:20','Kashmeera','2024-06-23 16:59:20','Mansi',2),(1231,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-23 16:59:20','2024-06-23 16:59:20','processed','success','2024-06-23 16:59:20','Kashmeera','2024-06-23 16:59:20','Mansi',3),(1232,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-23 17:01:09','2024-06-23 17:01:09','processed','success','2024-06-23 17:01:09','Kashmeera','2024-06-23 17:01:09','Mansi',1),(1233,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-23 17:01:09','2024-06-23 17:01:09','Unprocessed','success','2024-06-23 17:01:09','Kashmeera','2024-06-23 17:01:09','Mansi',2),(1234,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-23 17:01:09','2024-06-23 17:01:09','processed','success','2024-06-23 17:01:09','Kashmeera','2024-06-23 17:01:09','Mansi',3),(1235,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 08:48:52','2024-06-24 08:48:52','processed','success','2024-06-24 08:48:52','Kashmeera','2024-06-24 08:48:52','Mansi',1),(1236,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 08:48:52','2024-06-24 08:48:52','Unprocessed','success','2024-06-24 08:48:52','Kashmeera','2024-06-24 08:48:52','Mansi',2),(1237,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 08:48:52','2024-06-24 08:48:52','processed','success','2024-06-24 08:48:52','Kashmeera','2024-06-24 08:48:52','Mansi',3),(1238,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 10:38:13','2024-06-24 10:38:13','processed','success','2024-06-24 10:38:13','Kashmeera','2024-06-24 10:38:13','Mansi',1),(1239,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 10:38:13','2024-06-24 10:38:13','Unprocessed','success','2024-06-24 10:38:13','Kashmeera','2024-06-24 10:38:13','Mansi',2),(1240,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 10:38:13','2024-06-24 10:38:13','processed','success','2024-06-24 10:38:13','Kashmeera','2024-06-24 10:38:13','Mansi',3),(1241,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 10:41:37','2024-06-24 10:41:37','processed','success','2024-06-24 10:41:37','Kashmeera','2024-06-24 10:41:37','Mansi',1),(1242,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 10:41:37','2024-06-24 10:41:37','Unprocessed','success','2024-06-24 10:41:37','Kashmeera','2024-06-24 10:41:37','Mansi',2),(1243,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 10:41:37','2024-06-24 10:41:37','processed','success','2024-06-24 10:41:37','Kashmeera','2024-06-24 10:41:37','Mansi',3),(1244,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 10:45:03','2024-06-24 10:45:03','processed','success','2024-06-24 10:45:03','Kashmeera','2024-06-24 10:45:03','Mansi',1),(1245,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 10:45:03','2024-06-24 10:45:03','Unprocessed','success','2024-06-24 10:45:03','Kashmeera','2024-06-24 10:45:03','Mansi',2),(1246,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 10:45:03','2024-06-24 10:45:03','processed','success','2024-06-24 10:45:03','Kashmeera','2024-06-24 10:45:03','Mansi',3),(1247,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 10:50:23','2024-06-24 10:50:23','processed','success','2024-06-24 10:50:23','Kashmeera','2024-06-24 10:50:23','Mansi',1),(1248,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 10:50:23','2024-06-24 10:50:23','Unprocessed','success','2024-06-24 10:50:23','Kashmeera','2024-06-24 10:50:23','Mansi',2),(1249,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 10:50:23','2024-06-24 10:50:23','processed','success','2024-06-24 10:50:23','Kashmeera','2024-06-24 10:50:23','Mansi',3),(1250,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 10:54:01','2024-06-24 10:54:01','processed','success','2024-06-24 10:54:01','Kashmeera','2024-06-24 10:54:01','Mansi',1),(1251,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 10:54:01','2024-06-24 10:54:01','Unprocessed','success','2024-06-24 10:54:01','Kashmeera','2024-06-24 10:54:01','Mansi',2),(1252,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 10:54:01','2024-06-24 10:54:01','processed','success','2024-06-24 10:54:01','Kashmeera','2024-06-24 10:54:01','Mansi',3),(1253,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 11:02:34','2024-06-24 11:02:34','processed','success','2024-06-24 11:02:34','Kashmeera','2024-06-24 11:02:34','Mansi',1),(1254,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 11:02:34','2024-06-24 11:02:34','Unprocessed','success','2024-06-24 11:02:34','Kashmeera','2024-06-24 11:02:34','Mansi',2),(1255,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 11:02:34','2024-06-24 11:02:34','processed','success','2024-06-24 11:02:34','Kashmeera','2024-06-24 11:02:34','Mansi',3),(1256,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 11:08:14','2024-06-24 11:08:14','processed','success','2024-06-24 11:08:14','Kashmeera','2024-06-24 11:08:14','Mansi',1),(1257,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 11:08:14','2024-06-24 11:08:14','Unprocessed','success','2024-06-24 11:08:14','Kashmeera','2024-06-24 11:08:14','Mansi',2),(1258,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 11:08:14','2024-06-24 11:08:14','processed','success','2024-06-24 11:08:14','Kashmeera','2024-06-24 11:08:14','Mansi',3),(1259,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 11:09:24','2024-06-24 11:09:24','processed','success','2024-06-24 11:09:24','Kashmeera','2024-06-24 11:09:24','Mansi',1),(1260,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 11:09:24','2024-06-24 11:09:24','Unprocessed','success','2024-06-24 11:09:24','Kashmeera','2024-06-24 11:09:24','Mansi',2),(1261,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 11:09:24','2024-06-24 11:09:24','processed','success','2024-06-24 11:09:24','Kashmeera','2024-06-24 11:09:24','Mansi',3),(1262,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 11:10:49','2024-06-24 11:10:49','processed','success','2024-06-24 11:10:49','Kashmeera','2024-06-24 11:10:49','Mansi',1),(1263,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 11:10:49','2024-06-24 11:10:49','Unprocessed','success','2024-06-24 11:10:49','Kashmeera','2024-06-24 11:10:49','Mansi',2),(1264,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 11:10:49','2024-06-24 11:10:49','processed','success','2024-06-24 11:10:49','Kashmeera','2024-06-24 11:10:49','Mansi',3),(1265,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 11:12:46','2024-06-24 11:12:46','processed','success','2024-06-24 11:12:46','Kashmeera','2024-06-24 11:12:46','Mansi',1),(1266,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 11:12:46','2024-06-24 11:12:46','Unprocessed','success','2024-06-24 11:12:46','Kashmeera','2024-06-24 11:12:46','Mansi',2),(1267,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 11:12:46','2024-06-24 11:12:46','processed','success','2024-06-24 11:12:46','Kashmeera','2024-06-24 11:12:46','Mansi',3),(1268,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 11:14:26','2024-06-24 11:14:26','processed','success','2024-06-24 11:14:26','Kashmeera','2024-06-24 11:14:26','Mansi',1),(1269,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 11:14:26','2024-06-24 11:14:26','Unprocessed','success','2024-06-24 11:14:26','Kashmeera','2024-06-24 11:14:26','Mansi',2),(1270,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 11:14:26','2024-06-24 11:14:26','processed','success','2024-06-24 11:14:26','Kashmeera','2024-06-24 11:14:26','Mansi',3),(1271,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 11:17:27','2024-06-24 11:17:27','processed','success','2024-06-24 11:17:27','Kashmeera','2024-06-24 11:17:27','Mansi',1),(1272,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 11:17:27','2024-06-24 11:17:27','Unprocessed','success','2024-06-24 11:17:27','Kashmeera','2024-06-24 11:17:27','Mansi',2),(1273,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 11:17:27','2024-06-24 11:17:27','processed','success','2024-06-24 11:17:27','Kashmeera','2024-06-24 11:17:27','Mansi',3),(1274,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 11:21:15','2024-06-24 11:21:15','processed','success','2024-06-24 11:21:15','Kashmeera','2024-06-24 11:21:15','Mansi',1),(1275,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 11:21:15','2024-06-24 11:21:15','Unprocessed','success','2024-06-24 11:21:15','Kashmeera','2024-06-24 11:21:15','Mansi',2),(1276,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 11:21:15','2024-06-24 11:21:15','processed','success','2024-06-24 11:21:15','Kashmeera','2024-06-24 11:21:15','Mansi',3),(1277,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 11:22:52','2024-06-24 11:22:52','processed','success','2024-06-24 11:22:52','Kashmeera','2024-06-24 11:22:52','Mansi',1),(1278,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 11:22:52','2024-06-24 11:22:52','Unprocessed','success','2024-06-24 11:22:52','Kashmeera','2024-06-24 11:22:52','Mansi',2),(1279,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 11:22:52','2024-06-24 11:22:52','processed','success','2024-06-24 11:22:52','Kashmeera','2024-06-24 11:22:52','Mansi',3),(1280,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 11:23:17','2024-06-24 11:23:17','processed','success','2024-06-24 11:23:17','Kashmeera','2024-06-24 11:23:17','Mansi',1),(1281,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 11:23:17','2024-06-24 11:23:17','Unprocessed','success','2024-06-24 11:23:17','Kashmeera','2024-06-24 11:23:17','Mansi',2),(1282,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 11:23:17','2024-06-24 11:23:17','processed','success','2024-06-24 11:23:17','Kashmeera','2024-06-24 11:23:17','Mansi',3),(1283,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 11:26:12','2024-06-24 11:26:12','processed','success','2024-06-24 11:26:12','Kashmeera','2024-06-24 11:26:12','Mansi',1),(1284,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 11:26:12','2024-06-24 11:26:12','Unprocessed','success','2024-06-24 11:26:12','Kashmeera','2024-06-24 11:26:12','Mansi',2),(1285,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 11:26:12','2024-06-24 11:26:12','processed','success','2024-06-24 11:26:12','Kashmeera','2024-06-24 11:26:12','Mansi',3),(1286,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 11:26:27','2024-06-24 11:26:27','processed','success','2024-06-24 11:26:27','Kashmeera','2024-06-24 11:26:27','Mansi',1),(1287,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 11:26:27','2024-06-24 11:26:27','Unprocessed','success','2024-06-24 11:26:27','Kashmeera','2024-06-24 11:26:27','Mansi',2),(1288,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 11:26:27','2024-06-24 11:26:27','processed','success','2024-06-24 11:26:27','Kashmeera','2024-06-24 11:26:27','Mansi',3),(1289,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 11:27:06','2024-06-24 11:27:06','processed','success','2024-06-24 11:27:06','Kashmeera','2024-06-24 11:27:06','Mansi',1),(1290,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 11:27:06','2024-06-24 11:27:06','Unprocessed','success','2024-06-24 11:27:06','Kashmeera','2024-06-24 11:27:06','Mansi',2),(1291,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 11:27:06','2024-06-24 11:27:06','processed','success','2024-06-24 11:27:06','Kashmeera','2024-06-24 11:27:06','Mansi',3),(1292,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 11:27:27','2024-06-24 11:27:27','processed','success','2024-06-24 11:27:27','Kashmeera','2024-06-24 11:27:27','Mansi',1),(1293,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 11:27:27','2024-06-24 11:27:27','Unprocessed','success','2024-06-24 11:27:27','Kashmeera','2024-06-24 11:27:27','Mansi',2),(1294,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 11:27:27','2024-06-24 11:27:27','processed','success','2024-06-24 11:27:27','Kashmeera','2024-06-24 11:27:27','Mansi',3),(1295,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 11:29:04','2024-06-24 11:29:04','processed','success','2024-06-24 11:29:04','Kashmeera','2024-06-24 11:29:04','Mansi',1),(1296,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 11:29:04','2024-06-24 11:29:04','Unprocessed','success','2024-06-24 11:29:04','Kashmeera','2024-06-24 11:29:04','Mansi',2),(1297,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 11:29:04','2024-06-24 11:29:04','processed','success','2024-06-24 11:29:04','Kashmeera','2024-06-24 11:29:04','Mansi',3),(1298,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 11:32:02','2024-06-24 11:32:02','processed','success','2024-06-24 11:32:02','Kashmeera','2024-06-24 11:32:02','Mansi',1),(1299,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 11:32:02','2024-06-24 11:32:02','Unprocessed','success','2024-06-24 11:32:02','Kashmeera','2024-06-24 11:32:02','Mansi',2),(1300,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 11:32:02','2024-06-24 11:32:02','processed','success','2024-06-24 11:32:02','Kashmeera','2024-06-24 11:32:02','Mansi',3),(1301,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 11:33:08','2024-06-24 11:33:08','processed','success','2024-06-24 11:33:08','Kashmeera','2024-06-24 11:33:08','Mansi',1),(1302,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 11:33:08','2024-06-24 11:33:08','Unprocessed','success','2024-06-24 11:33:08','Kashmeera','2024-06-24 11:33:08','Mansi',2),(1303,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 11:33:08','2024-06-24 11:33:08','processed','success','2024-06-24 11:33:08','Kashmeera','2024-06-24 11:33:08','Mansi',3),(1304,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 11:33:23','2024-06-24 11:33:23','processed','success','2024-06-24 11:33:23','Kashmeera','2024-06-24 11:33:23','Mansi',1),(1305,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 11:33:23','2024-06-24 11:33:23','Unprocessed','success','2024-06-24 11:33:23','Kashmeera','2024-06-24 11:33:23','Mansi',2),(1306,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 11:33:23','2024-06-24 11:33:23','processed','success','2024-06-24 11:33:23','Kashmeera','2024-06-24 11:33:23','Mansi',3),(1307,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 11:35:45','2024-06-24 11:35:45','processed','success','2024-06-24 11:35:45','Kashmeera','2024-06-24 11:35:45','Mansi',1),(1308,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 11:35:45','2024-06-24 11:35:45','Unprocessed','success','2024-06-24 11:35:45','Kashmeera','2024-06-24 11:35:45','Mansi',2),(1309,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 11:35:45','2024-06-24 11:35:45','processed','success','2024-06-24 11:35:45','Kashmeera','2024-06-24 11:35:45','Mansi',3),(1310,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 11:37:44','2024-06-24 11:37:44','processed','success','2024-06-24 11:37:44','Kashmeera','2024-06-24 11:37:44','Mansi',1),(1311,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 11:37:44','2024-06-24 11:37:44','Unprocessed','success','2024-06-24 11:37:44','Kashmeera','2024-06-24 11:37:44','Mansi',2),(1312,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 11:37:44','2024-06-24 11:37:44','processed','success','2024-06-24 11:37:44','Kashmeera','2024-06-24 11:37:44','Mansi',3),(1313,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 11:38:24','2024-06-24 11:38:24','processed','success','2024-06-24 11:38:24','Kashmeera','2024-06-24 11:38:24','Mansi',1),(1314,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 11:38:24','2024-06-24 11:38:24','Unprocessed','success','2024-06-24 11:38:24','Kashmeera','2024-06-24 11:38:24','Mansi',2),(1315,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 11:38:24','2024-06-24 11:38:24','processed','success','2024-06-24 11:38:24','Kashmeera','2024-06-24 11:38:24','Mansi',3),(1316,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 12:08:03','2024-06-24 12:08:03','processed','success','2024-06-24 12:08:03','Kashmeera','2024-06-24 12:08:03','Mansi',1),(1317,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 12:08:03','2024-06-24 12:08:03','Unprocessed','success','2024-06-24 12:08:03','Kashmeera','2024-06-24 12:08:03','Mansi',2),(1318,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 12:08:03','2024-06-24 12:08:03','processed','success','2024-06-24 12:08:03','Kashmeera','2024-06-24 12:08:03','Mansi',3),(1319,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 12:09:21','2024-06-24 12:09:21','processed','success','2024-06-24 12:09:21','Kashmeera','2024-06-24 12:09:21','Mansi',1),(1320,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 12:09:21','2024-06-24 12:09:21','Unprocessed','success','2024-06-24 12:09:21','Kashmeera','2024-06-24 12:09:21','Mansi',2),(1321,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 12:09:21','2024-06-24 12:09:21','processed','success','2024-06-24 12:09:21','Kashmeera','2024-06-24 12:09:21','Mansi',3),(1322,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 12:09:54','2024-06-24 12:09:54','processed','success','2024-06-24 12:09:54','Kashmeera','2024-06-24 12:09:54','Mansi',1),(1323,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 12:09:54','2024-06-24 12:09:54','Unprocessed','success','2024-06-24 12:09:54','Kashmeera','2024-06-24 12:09:54','Mansi',2),(1324,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 12:09:54','2024-06-24 12:09:54','processed','success','2024-06-24 12:09:54','Kashmeera','2024-06-24 12:09:54','Mansi',3),(1325,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 12:10:11','2024-06-24 12:10:11','processed','success','2024-06-24 12:10:11','Kashmeera','2024-06-24 12:10:11','Mansi',1),(1326,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 12:10:11','2024-06-24 12:10:11','Unprocessed','success','2024-06-24 12:10:11','Kashmeera','2024-06-24 12:10:11','Mansi',2),(1327,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 12:10:11','2024-06-24 12:10:11','processed','success','2024-06-24 12:10:11','Kashmeera','2024-06-24 12:10:11','Mansi',3),(1328,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 12:10:36','2024-06-24 12:10:36','processed','success','2024-06-24 12:10:36','Kashmeera','2024-06-24 12:10:36','Mansi',1),(1329,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 12:10:36','2024-06-24 12:10:36','Unprocessed','success','2024-06-24 12:10:36','Kashmeera','2024-06-24 12:10:36','Mansi',2),(1330,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 12:10:36','2024-06-24 12:10:36','processed','success','2024-06-24 12:10:36','Kashmeera','2024-06-24 12:10:36','Mansi',3),(1331,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 12:21:19','2024-06-24 12:21:19','processed','success','2024-06-24 12:21:19','Kashmeera','2024-06-24 12:21:19','Mansi',1),(1332,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 12:21:19','2024-06-24 12:21:19','Unprocessed','success','2024-06-24 12:21:19','Kashmeera','2024-06-24 12:21:19','Mansi',2),(1333,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 12:21:19','2024-06-24 12:21:19','processed','success','2024-06-24 12:21:19','Kashmeera','2024-06-24 12:21:19','Mansi',3),(1334,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 12:23:37','2024-06-24 12:23:37','processed','success','2024-06-24 12:23:37','Kashmeera','2024-06-24 12:23:37','Mansi',1),(1335,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 12:23:37','2024-06-24 12:23:37','Unprocessed','success','2024-06-24 12:23:37','Kashmeera','2024-06-24 12:23:37','Mansi',2),(1336,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 12:23:37','2024-06-24 12:23:37','processed','success','2024-06-24 12:23:37','Kashmeera','2024-06-24 12:23:37','Mansi',3),(1337,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 12:24:22','2024-06-24 12:24:22','processed','success','2024-06-24 12:24:22','Kashmeera','2024-06-24 12:24:22','Mansi',1),(1338,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 12:24:22','2024-06-24 12:24:22','Unprocessed','success','2024-06-24 12:24:22','Kashmeera','2024-06-24 12:24:22','Mansi',2),(1339,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 12:24:22','2024-06-24 12:24:22','processed','success','2024-06-24 12:24:22','Kashmeera','2024-06-24 12:24:22','Mansi',3),(1340,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 12:25:42','2024-06-24 12:25:42','processed','success','2024-06-24 12:25:42','Kashmeera','2024-06-24 12:25:42','Mansi',1),(1341,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 12:25:43','2024-06-24 12:25:43','Unprocessed','success','2024-06-24 12:25:43','Kashmeera','2024-06-24 12:25:43','Mansi',2),(1342,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 12:25:43','2024-06-24 12:25:43','processed','success','2024-06-24 12:25:43','Kashmeera','2024-06-24 12:25:43','Mansi',3),(1343,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 12:26:43','2024-06-24 12:26:43','processed','success','2024-06-24 12:26:43','Kashmeera','2024-06-24 12:26:43','Mansi',1),(1344,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 12:26:43','2024-06-24 12:26:43','Unprocessed','success','2024-06-24 12:26:43','Kashmeera','2024-06-24 12:26:43','Mansi',2),(1345,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 12:26:43','2024-06-24 12:26:43','processed','success','2024-06-24 12:26:43','Kashmeera','2024-06-24 12:26:43','Mansi',3),(1346,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 12:30:40','2024-06-24 12:30:40','processed','success','2024-06-24 12:30:40','Kashmeera','2024-06-24 12:30:40','Mansi',1),(1347,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 12:30:40','2024-06-24 12:30:40','Unprocessed','success','2024-06-24 12:30:40','Kashmeera','2024-06-24 12:30:40','Mansi',2),(1348,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 12:30:40','2024-06-24 12:30:40','processed','success','2024-06-24 12:30:40','Kashmeera','2024-06-24 12:30:40','Mansi',3),(1349,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 12:33:38','2024-06-24 12:33:38','processed','success','2024-06-24 12:33:38','Kashmeera','2024-06-24 12:33:38','Mansi',1),(1350,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 12:33:38','2024-06-24 12:33:38','Unprocessed','success','2024-06-24 12:33:38','Kashmeera','2024-06-24 12:33:38','Mansi',2),(1351,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 12:33:38','2024-06-24 12:33:38','processed','success','2024-06-24 12:33:38','Kashmeera','2024-06-24 12:33:38','Mansi',3),(1352,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 12:39:24','2024-06-24 12:39:24','processed','success','2024-06-24 12:39:24','Kashmeera','2024-06-24 12:39:24','Mansi',1),(1353,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 12:39:24','2024-06-24 12:39:24','processed','success','2024-06-24 12:39:24','Kashmeera','2024-06-24 12:39:24','Mansi',1),(1354,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 12:39:24','2024-06-24 12:39:24','Unprocessed','success','2024-06-24 12:39:24','Kashmeera','2024-06-24 12:39:24','Mansi',2),(1355,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 12:39:24','2024-06-24 12:39:24','Unprocessed','success','2024-06-24 12:39:24','Kashmeera','2024-06-24 12:39:24','Mansi',2),(1356,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 12:39:24','2024-06-24 12:39:24','processed','success','2024-06-24 12:39:24','Kashmeera','2024-06-24 12:39:24','Mansi',3),(1357,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 12:39:24','2024-06-24 12:39:24','processed','success','2024-06-24 12:39:24','Kashmeera','2024-06-24 12:39:24','Mansi',3),(1358,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 12:40:01','2024-06-24 12:40:01','processed','success','2024-06-24 12:40:01','Kashmeera','2024-06-24 12:40:01','Mansi',1),(1359,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 12:40:01','2024-06-24 12:40:01','processed','success','2024-06-24 12:40:01','Kashmeera','2024-06-24 12:40:01','Mansi',1),(1360,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 12:40:01','2024-06-24 12:40:01','Unprocessed','success','2024-06-24 12:40:01','Kashmeera','2024-06-24 12:40:01','Mansi',2),(1361,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 12:40:02','2024-06-24 12:40:02','Unprocessed','success','2024-06-24 12:40:02','Kashmeera','2024-06-24 12:40:02','Mansi',2),(1362,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 12:40:02','2024-06-24 12:40:02','processed','success','2024-06-24 12:40:02','Kashmeera','2024-06-24 12:40:02','Mansi',3),(1363,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 12:40:02','2024-06-24 12:40:02','processed','success','2024-06-24 12:40:02','Kashmeera','2024-06-24 12:40:02','Mansi',3),(1364,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 12:43:55','2024-06-24 12:43:55','processed','success','2024-06-24 12:43:55','Kashmeera','2024-06-24 12:43:55','Mansi',1),(1365,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 12:43:55','2024-06-24 12:43:55','Unprocessed','success','2024-06-24 12:43:55','Kashmeera','2024-06-24 12:43:55','Mansi',2),(1366,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 12:43:55','2024-06-24 12:43:55','processed','success','2024-06-24 12:43:55','Kashmeera','2024-06-24 12:43:55','Mansi',3),(1367,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 12:44:11','2024-06-24 12:44:11','processed','success','2024-06-24 12:44:11','Kashmeera','2024-06-24 12:44:11','Mansi',1),(1368,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 12:44:11','2024-06-24 12:44:11','Unprocessed','success','2024-06-24 12:44:11','Kashmeera','2024-06-24 12:44:11','Mansi',2),(1369,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 12:44:11','2024-06-24 12:44:11','processed','success','2024-06-24 12:44:11','Kashmeera','2024-06-24 12:44:11','Mansi',3),(1370,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 12:45:57','2024-06-24 12:45:57','processed','success','2024-06-24 12:45:57','Kashmeera','2024-06-24 12:45:57','Mansi',1),(1371,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 12:45:57','2024-06-24 12:45:57','Unprocessed','success','2024-06-24 12:45:57','Kashmeera','2024-06-24 12:45:57','Mansi',2),(1372,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 12:45:57','2024-06-24 12:45:57','processed','success','2024-06-24 12:45:57','Kashmeera','2024-06-24 12:45:57','Mansi',3),(1373,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 14:14:05','2024-06-24 14:14:05','processed','success','2024-06-24 14:14:05','Kashmeera','2024-06-24 14:14:05','Mansi',1),(1374,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 14:14:05','2024-06-24 14:14:05','Unprocessed','success','2024-06-24 14:14:05','Kashmeera','2024-06-24 14:14:05','Mansi',2),(1375,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 14:14:05','2024-06-24 14:14:05','processed','success','2024-06-24 14:14:05','Kashmeera','2024-06-24 14:14:05','Mansi',3),(1376,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 14:22:38','2024-06-24 14:22:38','processed','success','2024-06-24 14:22:38','Kashmeera','2024-06-24 14:22:38','Mansi',1),(1377,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 14:22:38','2024-06-24 14:22:38','Unprocessed','success','2024-06-24 14:22:38','Kashmeera','2024-06-24 14:22:38','Mansi',2),(1378,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 14:22:38','2024-06-24 14:22:38','processed','success','2024-06-24 14:22:38','Kashmeera','2024-06-24 14:22:38','Mansi',3),(1379,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 14:24:13','2024-06-24 14:24:13','processed','success','2024-06-24 14:24:13','Kashmeera','2024-06-24 14:24:13','Mansi',1),(1380,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 14:24:13','2024-06-24 14:24:13','Unprocessed','success','2024-06-24 14:24:13','Kashmeera','2024-06-24 14:24:13','Mansi',2),(1381,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 14:24:13','2024-06-24 14:24:13','processed','success','2024-06-24 14:24:13','Kashmeera','2024-06-24 14:24:13','Mansi',3),(1382,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 14:28:46','2024-06-24 14:28:46','processed','success','2024-06-24 14:28:46','Kashmeera','2024-06-24 14:28:46','Mansi',1),(1383,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 14:28:46','2024-06-24 14:28:46','Unprocessed','success','2024-06-24 14:28:46','Kashmeera','2024-06-24 14:28:46','Mansi',2),(1384,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-24 14:28:46','2024-06-24 14:28:46','processed','success','2024-06-24 14:28:46','Kashmeera','2024-06-24 14:28:46','Mansi',3),(1497,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-25 09:07:02','2024-06-25 09:07:02','processed','success','2024-06-25 09:07:02','Kashmeera','2024-06-25 09:07:02','Mansi',1),(1498,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-25 09:07:02','2024-06-25 09:07:02','Unprocessed','success','2024-06-25 09:07:02','Kashmeera','2024-06-25 09:07:02','Mansi',2),(1499,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-25 09:07:02','2024-06-25 09:07:02','processed','success','2024-06-25 09:07:02','Kashmeera','2024-06-25 09:07:02','Mansi',3),(1500,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-25 10:25:17','2024-06-25 10:25:17','processed','success','2024-06-25 10:25:17','Kashmeera','2024-06-25 10:25:17','Mansi',1),(1501,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-25 10:25:17','2024-06-25 10:25:17','Unprocessed','success','2024-06-25 10:25:17','Kashmeera','2024-06-25 10:25:17','Mansi',2),(1502,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-25 10:25:17','2024-06-25 10:25:17','processed','success','2024-06-25 10:25:17','Kashmeera','2024-06-25 10:25:17','Mansi',3),(1503,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-25 10:40:05','2024-06-25 10:40:05','processed','success','2024-06-25 10:40:05','Kashmeera','2024-06-25 10:40:05','Mansi',1),(1504,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-25 10:40:05','2024-06-25 10:40:05','Unprocessed','success','2024-06-25 10:40:05','Kashmeera','2024-06-25 10:40:05','Mansi',2),(1505,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-25 10:40:05','2024-06-25 10:40:05','processed','success','2024-06-25 10:40:05','Kashmeera','2024-06-25 10:40:05','Mansi',3),(1506,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-25 10:55:32','2024-06-25 10:55:32','processed','success','2024-06-25 10:55:32','Kashmeera','2024-06-25 10:55:32','Mansi',1),(1507,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-25 10:55:32','2024-06-25 10:55:32','Unprocessed','success','2024-06-25 10:55:32','Kashmeera','2024-06-25 10:55:32','Mansi',2),(1508,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-25 10:55:32','2024-06-25 10:55:32','processed','success','2024-06-25 10:55:32','Kashmeera','2024-06-25 10:55:32','Mansi',3),(1509,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-25 10:59:04','2024-06-25 10:59:04','processed','success','2024-06-25 10:59:04','Kashmeera','2024-06-25 10:59:04','Mansi',1),(1510,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-25 10:59:04','2024-06-25 10:59:04','Unprocessed','success','2024-06-25 10:59:04','Kashmeera','2024-06-25 10:59:04','Mansi',2),(1511,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-25 10:59:05','2024-06-25 10:59:05','processed','success','2024-06-25 10:59:05','Kashmeera','2024-06-25 10:59:05','Mansi',3),(1512,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-25 11:03:38','2024-06-25 11:03:38','processed','success','2024-06-25 11:03:38','Kashmeera','2024-06-25 11:03:38','Mansi',1),(1513,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-25 11:03:38','2024-06-25 11:03:38','Unprocessed','success','2024-06-25 11:03:38','Kashmeera','2024-06-25 11:03:38','Mansi',2),(1514,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-25 11:03:38','2024-06-25 11:03:38','processed','success','2024-06-25 11:03:38','Kashmeera','2024-06-25 11:03:38','Mansi',3),(1515,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-25 11:07:09','2024-06-25 11:07:09','processed','success','2024-06-25 11:07:09','Kashmeera','2024-06-25 11:07:09','Mansi',1),(1516,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-25 11:07:09','2024-06-25 11:07:09','Unprocessed','success','2024-06-25 11:07:09','Kashmeera','2024-06-25 11:07:09','Mansi',2),(1517,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-25 11:07:09','2024-06-25 11:07:09','processed','success','2024-06-25 11:07:09','Kashmeera','2024-06-25 11:07:09','Mansi',3),(1518,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-25 11:08:30','2024-06-25 11:08:30','processed','success','2024-06-25 11:08:30','Kashmeera','2024-06-25 11:08:30','Mansi',1),(1519,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-25 11:08:30','2024-06-25 11:08:30','Unprocessed','success','2024-06-25 11:08:30','Kashmeera','2024-06-25 11:08:30','Mansi',2),(1520,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-25 11:08:30','2024-06-25 11:08:30','processed','success','2024-06-25 11:08:30','Kashmeera','2024-06-25 11:08:30','Mansi',3),(1521,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-25 11:13:32','2024-06-25 11:13:32','processed','success','2024-06-25 11:13:32','Kashmeera','2024-06-25 11:13:32','Mansi',1),(1522,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-25 11:13:32','2024-06-25 11:13:32','Unprocessed','success','2024-06-25 11:13:32','Kashmeera','2024-06-25 11:13:32','Mansi',2),(1523,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-25 11:13:32','2024-06-25 11:13:32','processed','success','2024-06-25 11:13:32','Kashmeera','2024-06-25 11:13:32','Mansi',3),(1524,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-25 11:14:05','2024-06-25 11:14:05','processed','success','2024-06-25 11:14:05','Kashmeera','2024-06-25 11:14:05','Mansi',1),(1525,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-25 11:14:05','2024-06-25 11:14:05','Unprocessed','success','2024-06-25 11:14:05','Kashmeera','2024-06-25 11:14:05','Mansi',2),(1526,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-25 11:14:05','2024-06-25 11:14:05','processed','success','2024-06-25 11:14:05','Kashmeera','2024-06-25 11:14:05','Mansi',3),(1527,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-26 09:45:56','2024-06-26 09:45:56','processed','success','2024-06-26 09:45:56','Kashmeera','2024-06-26 09:45:56','Mansi',1),(1528,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-26 09:45:56','2024-06-26 09:45:56','Unprocessed','success','2024-06-26 09:45:56','Kashmeera','2024-06-26 09:45:56','Mansi',2),(1529,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-26 09:45:56','2024-06-26 09:45:56','processed','success','2024-06-26 09:45:56','Kashmeera','2024-06-26 09:45:56','Mansi',3),(1530,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-26 10:35:06','2024-06-26 10:35:06','processed','success','2024-06-26 10:35:06','Kashmeera','2024-06-26 10:35:06','Mansi',1),(1531,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-26 10:35:06','2024-06-26 10:35:06','Unprocessed','success','2024-06-26 10:35:06','Kashmeera','2024-06-26 10:35:06','Mansi',2),(1532,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-26 10:35:06','2024-06-26 10:35:06','processed','success','2024-06-26 10:35:06','Kashmeera','2024-06-26 10:35:06','Mansi',3),(1533,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-26 10:39:26','2024-06-26 10:39:26','processed','success','2024-06-26 10:39:26','Kashmeera','2024-06-26 10:39:26','Mansi',1),(1534,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-26 10:39:26','2024-06-26 10:39:26','Unprocessed','success','2024-06-26 10:39:26','Kashmeera','2024-06-26 10:39:26','Mansi',2),(1535,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-26 10:39:26','2024-06-26 10:39:26','processed','success','2024-06-26 10:39:26','Kashmeera','2024-06-26 10:39:26','Mansi',3),(1536,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-26 10:39:55','2024-06-26 10:39:55','processed','success','2024-06-26 10:39:55','Kashmeera','2024-06-26 10:39:55','Mansi',1),(1537,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-26 10:39:55','2024-06-26 10:39:55','Unprocessed','success','2024-06-26 10:39:55','Kashmeera','2024-06-26 10:39:55','Mansi',2),(1538,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-26 10:39:55','2024-06-26 10:39:55','processed','success','2024-06-26 10:39:55','Kashmeera','2024-06-26 10:39:55','Mansi',3),(1539,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-26 10:40:10','2024-06-26 10:40:10','processed','success','2024-06-26 10:40:10','Kashmeera','2024-06-26 10:40:10','Mansi',1),(1540,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-26 10:40:10','2024-06-26 10:40:10','Unprocessed','success','2024-06-26 10:40:10','Kashmeera','2024-06-26 10:40:10','Mansi',2),(1541,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-26 10:40:10','2024-06-26 10:40:10','processed','success','2024-06-26 10:40:10','Kashmeera','2024-06-26 10:40:10','Mansi',3),(1542,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-26 10:54:41','2024-06-26 10:54:41','processed','success','2024-06-26 10:54:41','Kashmeera','2024-06-26 10:54:41','Mansi',1),(1543,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-26 10:54:41','2024-06-26 10:54:41','Unprocessed','success','2024-06-26 10:54:41','Kashmeera','2024-06-26 10:54:41','Mansi',2),(1544,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-26 10:54:41','2024-06-26 10:54:41','processed','success','2024-06-26 10:54:41','Kashmeera','2024-06-26 10:54:41','Mansi',3),(1545,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-26 10:57:44','2024-06-26 10:57:44','processed','success','2024-06-26 10:57:44','Kashmeera','2024-06-26 10:57:44','Mansi',1),(1546,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-26 10:57:44','2024-06-26 10:57:44','processed','success','2024-06-26 10:57:44','Kashmeera','2024-06-26 10:57:44','Mansi',1),(1547,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-26 10:57:44','2024-06-26 10:57:44','Unprocessed','success','2024-06-26 10:57:44','Kashmeera','2024-06-26 10:57:44','Mansi',2),(1548,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-26 10:57:44','2024-06-26 10:57:44','Unprocessed','success','2024-06-26 10:57:44','Kashmeera','2024-06-26 10:57:44','Mansi',2),(1549,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-26 10:57:44','2024-06-26 10:57:44','processed','success','2024-06-26 10:57:44','Kashmeera','2024-06-26 10:57:44','Mansi',3),(1550,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-26 10:57:44','2024-06-26 10:57:44','processed','success','2024-06-26 10:57:44','Kashmeera','2024-06-26 10:57:44','Mansi',3),(1551,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-26 11:22:48','2024-06-26 11:22:48','processed','success','2024-06-26 11:22:48','Kashmeera','2024-06-26 11:22:48','Mansi',1),(1552,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-26 11:22:48','2024-06-26 11:22:48','Unprocessed','success','2024-06-26 11:22:48','Kashmeera','2024-06-26 11:22:48','Mansi',2),(1553,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-26 11:22:48','2024-06-26 11:22:48','processed','success','2024-06-26 11:22:48','Kashmeera','2024-06-26 11:22:48','Mansi',3),(1554,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-26 11:25:27','2024-06-26 11:25:27','processed','success','2024-06-26 11:25:27','Kashmeera','2024-06-26 11:25:27','Mansi',1),(1555,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-26 11:25:27','2024-06-26 11:25:27','Unprocessed','success','2024-06-26 11:25:27','Kashmeera','2024-06-26 11:25:27','Mansi',2),(1556,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-26 11:25:27','2024-06-26 11:25:27','processed','success','2024-06-26 11:25:27','Kashmeera','2024-06-26 11:25:27','Mansi',3),(1557,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-26 12:03:44','2024-06-26 12:03:44','processed','success','2024-06-26 12:03:44','Kashmeera','2024-06-26 12:03:44','Mansi',1),(1558,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-26 12:03:44','2024-06-26 12:03:44','Unprocessed','success','2024-06-26 12:03:44','Kashmeera','2024-06-26 12:03:44','Mansi',2),(1559,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-26 12:03:44','2024-06-26 12:03:44','processed','success','2024-06-26 12:03:44','Kashmeera','2024-06-26 12:03:44','Mansi',3),(1560,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-26 13:28:56','2024-06-26 13:28:56','processed','success','2024-06-26 13:28:56','Kashmeera','2024-06-26 13:28:56','Mansi',1),(1561,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-26 13:28:56','2024-06-26 13:28:56','Unprocessed','success','2024-06-26 13:28:56','Kashmeera','2024-06-26 13:28:56','Mansi',2),(1562,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-26 13:28:56','2024-06-26 13:28:56','processed','success','2024-06-26 13:28:56','Kashmeera','2024-06-26 13:28:56','Mansi',3),(1563,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-26 14:34:18','2024-06-26 14:34:18','processed','success','2024-06-26 14:34:18','Kashmeera','2024-06-26 14:34:18','Mansi',1),(1564,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-26 14:34:18','2024-06-26 14:34:18','Unprocessed','success','2024-06-26 14:34:18','Kashmeera','2024-06-26 14:34:18','Mansi',2),(1565,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-26 14:34:18','2024-06-26 14:34:18','processed','success','2024-06-26 14:34:18','Kashmeera','2024-06-26 14:34:18','Mansi',3),(1566,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-26 14:45:53','2024-06-26 14:45:53','processed','success','2024-06-26 14:45:53','Kashmeera','2024-06-26 14:45:53','Mansi',1),(1567,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-26 14:45:53','2024-06-26 14:45:53','Unprocessed','success','2024-06-26 14:45:53','Kashmeera','2024-06-26 14:45:53','Mansi',2),(1568,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-26 14:45:53','2024-06-26 14:45:53','processed','success','2024-06-26 14:45:53','Kashmeera','2024-06-26 14:45:53','Mansi',3),(1569,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-26 14:56:25','2024-06-26 14:56:25','processed','success','2024-06-26 14:56:25','Kashmeera','2024-06-26 14:56:25','Mansi',1),(1570,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-26 14:56:25','2024-06-26 14:56:25','Unprocessed','success','2024-06-26 14:56:25','Kashmeera','2024-06-26 14:56:25','Mansi',2),(1571,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-26 14:56:25','2024-06-26 14:56:25','processed','success','2024-06-26 14:56:25','Kashmeera','2024-06-26 14:56:25','Mansi',3),(1572,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-26 16:10:20','2024-06-26 16:10:20','processed','success','2024-06-26 16:10:20','Kashmeera','2024-06-26 16:10:20','Mansi',1),(1573,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-26 16:10:20','2024-06-26 16:10:20','Unprocessed','success','2024-06-26 16:10:20','Kashmeera','2024-06-26 16:10:20','Mansi',2),(1574,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-26 16:10:20','2024-06-26 16:10:20','processed','success','2024-06-26 16:10:20','Kashmeera','2024-06-26 16:10:20','Mansi',3),(1575,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-27 11:12:33','2024-06-27 11:12:33','processed','success','2024-06-27 11:12:33','Kashmeera','2024-06-27 11:12:33','Mansi',1),(1576,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-27 11:12:33','2024-06-27 11:12:33','Unprocessed','success','2024-06-27 11:12:33','Kashmeera','2024-06-27 11:12:33','Mansi',2),(1577,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-27 11:12:33','2024-06-27 11:12:33','processed','success','2024-06-27 11:12:33','Kashmeera','2024-06-27 11:12:33','Mansi',3),(1578,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-27 13:54:42','2024-06-27 13:54:42','processed','success','2024-06-27 13:54:42','Kashmeera','2024-06-27 13:54:42','Mansi',1),(1579,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-27 13:54:42','2024-06-27 13:54:42','Unprocessed','success','2024-06-27 13:54:42','Kashmeera','2024-06-27 13:54:42','Mansi',2),(1580,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-27 13:54:42','2024-06-27 13:54:42','processed','success','2024-06-27 13:54:42','Kashmeera','2024-06-27 13:54:42','Mansi',3),(1581,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-27 13:56:08','2024-06-27 13:56:08','processed','success','2024-06-27 13:56:08','Kashmeera','2024-06-27 13:56:08','Mansi',1),(1582,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-27 13:56:08','2024-06-27 13:56:08','Unprocessed','success','2024-06-27 13:56:08','Kashmeera','2024-06-27 13:56:08','Mansi',2),(1583,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-27 13:56:08','2024-06-27 13:56:08','processed','success','2024-06-27 13:56:08','Kashmeera','2024-06-27 13:56:08','Mansi',3),(1584,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-27 14:29:16','2024-06-27 14:29:16','processed','success','2024-06-27 14:29:16','Kashmeera','2024-06-27 14:29:16','Mansi',1),(1585,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-27 14:29:16','2024-06-27 14:29:16','Unprocessed','success','2024-06-27 14:29:16','Kashmeera','2024-06-27 14:29:16','Mansi',2),(1586,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-27 14:29:16','2024-06-27 14:29:16','processed','success','2024-06-27 14:29:16','Kashmeera','2024-06-27 14:29:16','Mansi',3),(1587,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-27 14:33:42','2024-06-27 14:33:42','processed','success','2024-06-27 14:33:42','Kashmeera','2024-06-27 14:33:42','Mansi',1),(1588,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-27 14:33:42','2024-06-27 14:33:42','Unprocessed','success','2024-06-27 14:33:42','Kashmeera','2024-06-27 14:33:42','Mansi',2),(1589,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-27 14:33:42','2024-06-27 14:33:42','processed','success','2024-06-27 14:33:42','Kashmeera','2024-06-27 14:33:42','Mansi',3),(1590,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-27 14:34:55','2024-06-27 14:34:55','processed','success','2024-06-27 14:34:55','Kashmeera','2024-06-27 14:34:55','Mansi',1),(1591,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-27 14:34:55','2024-06-27 14:34:55','Unprocessed','success','2024-06-27 14:34:55','Kashmeera','2024-06-27 14:34:55','Mansi',2),(1592,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-27 14:34:55','2024-06-27 14:34:55','processed','success','2024-06-27 14:34:55','Kashmeera','2024-06-27 14:34:55','Mansi',3),(1593,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-27 14:37:08','2024-06-27 14:37:08','processed','success','2024-06-27 14:37:08','Kashmeera','2024-06-27 14:37:08','Mansi',1),(1594,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-27 14:37:08','2024-06-27 14:37:08','Unprocessed','success','2024-06-27 14:37:08','Kashmeera','2024-06-27 14:37:08','Mansi',2),(1595,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-27 14:37:08','2024-06-27 14:37:08','processed','success','2024-06-27 14:37:08','Kashmeera','2024-06-27 14:37:08','Mansi',3),(1596,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-27 14:37:25','2024-06-27 14:37:25','processed','success','2024-06-27 14:37:25','Kashmeera','2024-06-27 14:37:25','Mansi',1),(1597,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-27 14:37:25','2024-06-27 14:37:25','Unprocessed','success','2024-06-27 14:37:25','Kashmeera','2024-06-27 14:37:25','Mansi',2),(1598,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-27 14:37:25','2024-06-27 14:37:25','processed','success','2024-06-27 14:37:25','Kashmeera','2024-06-27 14:37:25','Mansi',3),(1599,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-27 14:52:43','2024-06-27 14:52:43','processed','success','2024-06-27 14:52:43','Kashmeera','2024-06-27 14:52:43','Mansi',1),(1600,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-27 14:52:43','2024-06-27 14:52:43','Unprocessed','success','2024-06-27 14:52:43','Kashmeera','2024-06-27 14:52:43','Mansi',2),(1601,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-27 14:52:43','2024-06-27 14:52:43','processed','success','2024-06-27 14:52:43','Kashmeera','2024-06-27 14:52:43','Mansi',3),(1602,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-27 14:54:07','2024-06-27 14:54:07','processed','success','2024-06-27 14:54:07','Kashmeera','2024-06-27 14:54:07','Mansi',1),(1603,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-27 14:54:07','2024-06-27 14:54:07','Unprocessed','success','2024-06-27 14:54:07','Kashmeera','2024-06-27 14:54:07','Mansi',2),(1604,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-27 14:54:07','2024-06-27 14:54:07','processed','success','2024-06-27 14:54:07','Kashmeera','2024-06-27 14:54:07','Mansi',3),(1605,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-27 15:29:52','2024-06-27 15:29:52','processed','success','2024-06-27 15:29:52','Kashmeera','2024-06-27 15:29:52','Mansi',1),(1606,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-27 15:29:52','2024-06-27 15:29:52','processed','success','2024-06-27 15:29:52','Kashmeera','2024-06-27 15:29:52','Mansi',1),(1607,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-27 15:29:52','2024-06-27 15:29:52','Unprocessed','success','2024-06-27 15:29:52','Kashmeera','2024-06-27 15:29:52','Mansi',2),(1608,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-27 15:29:52','2024-06-27 15:29:52','Unprocessed','success','2024-06-27 15:29:52','Kashmeera','2024-06-27 15:29:52','Mansi',2),(1609,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-27 15:29:52','2024-06-27 15:29:52','processed','success','2024-06-27 15:29:52','Kashmeera','2024-06-27 15:29:52','Mansi',3),(1610,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-27 15:29:52','2024-06-27 15:29:52','processed','success','2024-06-27 15:29:52','Kashmeera','2024-06-27 15:29:52','Mansi',3),(1611,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-28 14:51:47','2024-06-28 14:51:47','processed','success','2024-06-28 14:51:47','Kashmeera','2024-06-28 14:51:47','Mansi',1),(1612,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-28 14:51:47','2024-06-28 14:51:47','Unprocessed','success','2024-06-28 14:51:47','Kashmeera','2024-06-28 14:51:47','Mansi',2),(1613,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-28 14:51:47','2024-06-28 14:51:47','processed','success','2024-06-28 14:51:47','Kashmeera','2024-06-28 14:51:47','Mansi',3),(1614,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-28 14:52:45','2024-06-28 14:52:45','processed','success','2024-06-28 14:52:45','Kashmeera','2024-06-28 14:52:45','Mansi',1),(1615,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-28 14:52:45','2024-06-28 14:52:45','Unprocessed','success','2024-06-28 14:52:45','Kashmeera','2024-06-28 14:52:45','Mansi',2),(1616,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-28 14:52:45','2024-06-28 14:52:45','processed','success','2024-06-28 14:52:45','Kashmeera','2024-06-28 14:52:45','Mansi',3),(1617,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-28 16:08:29','2024-06-28 16:08:29','processed','success','2024-06-28 16:08:29','Kashmeera','2024-06-28 16:08:29','Mansi',1),(1618,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-28 16:08:29','2024-06-28 16:08:29','Unprocessed','success','2024-06-28 16:08:29','Kashmeera','2024-06-28 16:08:29','Mansi',2),(1619,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-28 16:08:29','2024-06-28 16:08:29','processed','success','2024-06-28 16:08:29','Kashmeera','2024-06-28 16:08:29','Mansi',3),(1620,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-28 16:26:58','2024-06-28 16:26:58','processed','success','2024-06-28 16:26:58','Kashmeera','2024-06-28 16:26:58','Mansi',1),(1621,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-28 16:26:58','2024-06-28 16:26:58','Unprocessed','success','2024-06-28 16:26:58','Kashmeera','2024-06-28 16:26:58','Mansi',2),(1622,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-06-28 16:26:58','2024-06-28 16:26:58','processed','success','2024-06-28 16:26:58','Kashmeera','2024-06-28 16:26:58','Mansi',3),(1623,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-01 12:03:59','2024-07-01 12:03:59','processed','success','2024-07-01 12:03:59','Kashmeera','2024-07-01 12:03:59','Mansi',1),(1624,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-01 12:03:59','2024-07-01 12:03:59','Unprocessed','success','2024-07-01 12:03:59','Kashmeera','2024-07-01 12:03:59','Mansi',2),(1625,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-01 12:03:59','2024-07-01 12:03:59','processed','success','2024-07-01 12:03:59','Kashmeera','2024-07-01 12:03:59','Mansi',3),(1626,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-02 12:05:34','2024-07-02 12:05:34','processed','success','2024-07-02 12:05:34','Kashmeera','2024-07-02 12:05:34','Mansi',1),(1627,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-02 12:05:34','2024-07-02 12:05:34','Unprocessed','success','2024-07-02 12:05:34','Kashmeera','2024-07-02 12:05:34','Mansi',2),(1628,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-02 12:05:34','2024-07-02 12:05:34','processed','success','2024-07-02 12:05:34','Kashmeera','2024-07-02 12:05:34','Mansi',3),(1629,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-02 12:31:51','2024-07-02 12:31:51','processed','success','2024-07-02 12:31:51','Kashmeera','2024-07-02 12:31:51','Mansi',1),(1630,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-02 12:31:51','2024-07-02 12:31:51','Unprocessed','success','2024-07-02 12:31:51','Kashmeera','2024-07-02 12:31:51','Mansi',2),(1631,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-02 12:31:51','2024-07-02 12:31:51','processed','success','2024-07-02 12:31:51','Kashmeera','2024-07-02 12:31:51','Mansi',3),(1632,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-02 12:33:09','2024-07-02 12:33:09','processed','success','2024-07-02 12:33:09','Kashmeera','2024-07-02 12:33:09','Mansi',1),(1633,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-02 12:33:09','2024-07-02 12:33:09','Unprocessed','success','2024-07-02 12:33:09','Kashmeera','2024-07-02 12:33:09','Mansi',2),(1634,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-02 12:33:09','2024-07-02 12:33:09','processed','success','2024-07-02 12:33:09','Kashmeera','2024-07-02 12:33:09','Mansi',3),(1635,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-02 12:34:06','2024-07-02 12:34:06','processed','success','2024-07-02 12:34:06','Kashmeera','2024-07-02 12:34:06','Mansi',1),(1636,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-02 12:34:06','2024-07-02 12:34:06','Unprocessed','success','2024-07-02 12:34:06','Kashmeera','2024-07-02 12:34:06','Mansi',2),(1637,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-02 12:34:06','2024-07-02 12:34:06','processed','success','2024-07-02 12:34:06','Kashmeera','2024-07-02 12:34:06','Mansi',3),(1638,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-02 12:35:11','2024-07-02 12:35:11','processed','success','2024-07-02 12:35:11','Kashmeera','2024-07-02 12:35:11','Mansi',1),(1639,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-02 12:35:11','2024-07-02 12:35:11','Unprocessed','success','2024-07-02 12:35:11','Kashmeera','2024-07-02 12:35:11','Mansi',2),(1640,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-02 12:35:11','2024-07-02 12:35:11','processed','success','2024-07-02 12:35:11','Kashmeera','2024-07-02 12:35:11','Mansi',3),(1641,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-02 12:42:04','2024-07-02 12:42:04','processed','success','2024-07-02 12:42:04','Kashmeera','2024-07-02 12:42:04','Mansi',1),(1642,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-02 12:42:04','2024-07-02 12:42:04','Unprocessed','success','2024-07-02 12:42:04','Kashmeera','2024-07-02 12:42:04','Mansi',2),(1643,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-02 12:42:04','2024-07-02 12:42:04','processed','success','2024-07-02 12:42:04','Kashmeera','2024-07-02 12:42:04','Mansi',3),(1644,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-02 14:38:46','2024-07-02 14:38:46','processed','success','2024-07-02 14:38:46','Kashmeera','2024-07-02 14:38:46','Mansi',1),(1645,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-02 14:38:46','2024-07-02 14:38:46','Unprocessed','success','2024-07-02 14:38:46','Kashmeera','2024-07-02 14:38:46','Mansi',2),(1646,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-02 14:38:46','2024-07-02 14:38:46','processed','success','2024-07-02 14:38:46','Kashmeera','2024-07-02 14:38:46','Mansi',3),(1647,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-04 16:57:49','2024-07-04 16:57:49','processed','success','2024-07-04 16:57:49','Kashmeera','2024-07-04 16:57:49','Mansi',1),(1648,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-04 16:57:49','2024-07-04 16:57:49','Unprocessed','success','2024-07-04 16:57:49','Kashmeera','2024-07-04 16:57:49','Mansi',2),(1649,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-04 16:57:49','2024-07-04 16:57:49','processed','success','2024-07-04 16:57:49','Kashmeera','2024-07-04 16:57:49','Mansi',3),(1650,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-05 13:38:46','2024-07-05 13:38:46','processed','success','2024-07-05 13:38:46','Kashmeera','2024-07-05 13:38:46','Mansi',1),(1651,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-05 13:38:46','2024-07-05 13:38:46','Unprocessed','success','2024-07-05 13:38:46','Kashmeera','2024-07-05 13:38:46','Mansi',2),(1652,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-05 13:38:46','2024-07-05 13:38:46','processed','success','2024-07-05 13:38:46','Kashmeera','2024-07-05 13:38:46','Mansi',3),(1653,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-10 14:38:21','2024-07-10 14:38:21','processed','success','2024-07-10 14:38:21','Kashmeera','2024-07-10 14:38:21','Mansi',1),(1654,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-10 14:38:21','2024-07-10 14:38:21','Unprocessed','success','2024-07-10 14:38:21','Kashmeera','2024-07-10 14:38:21','Mansi',2),(1655,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-10 14:38:21','2024-07-10 14:38:21','processed','success','2024-07-10 14:38:21','Kashmeera','2024-07-10 14:38:21','Mansi',3),(1656,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-10 17:20:58','2024-07-10 17:20:58','processed','success','2024-07-10 17:20:58','Kashmeera','2024-07-10 17:20:58','Mansi',1),(1657,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-10 17:20:58','2024-07-10 17:20:58','Unprocessed','success','2024-07-10 17:20:58','Kashmeera','2024-07-10 17:20:58','Mansi',2),(1658,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-10 17:20:58','2024-07-10 17:20:58','processed','success','2024-07-10 17:20:58','Kashmeera','2024-07-10 17:20:58','Mansi',3),(1659,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-10 17:42:21','2024-07-10 17:42:21','processed','success','2024-07-10 17:42:21','Kashmeera','2024-07-10 17:42:21','Mansi',1),(1660,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-10 17:42:21','2024-07-10 17:42:21','Unprocessed','success','2024-07-10 17:42:21','Kashmeera','2024-07-10 17:42:21','Mansi',2),(1661,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-10 17:42:21','2024-07-10 17:42:21','processed','success','2024-07-10 17:42:21','Kashmeera','2024-07-10 17:42:21','Mansi',3),(1662,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-10 17:42:58','2024-07-10 17:42:58','processed','success','2024-07-10 17:42:58','Kashmeera','2024-07-10 17:42:58','Mansi',1),(1663,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-10 17:42:58','2024-07-10 17:42:58','Unprocessed','success','2024-07-10 17:42:58','Kashmeera','2024-07-10 17:42:58','Mansi',2),(1664,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-10 17:42:58','2024-07-10 17:42:58','processed','success','2024-07-10 17:42:58','Kashmeera','2024-07-10 17:42:58','Mansi',3),(1665,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-10 17:43:19','2024-07-10 17:43:19','processed','success','2024-07-10 17:43:19','Kashmeera','2024-07-10 17:43:19','Mansi',1),(1666,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-10 17:43:19','2024-07-10 17:43:19','Unprocessed','success','2024-07-10 17:43:19','Kashmeera','2024-07-10 17:43:19','Mansi',2),(1667,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-10 17:43:19','2024-07-10 17:43:19','processed','success','2024-07-10 17:43:19','Kashmeera','2024-07-10 17:43:19','Mansi',3),(1668,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-10 17:54:34','2024-07-10 17:54:34','processed','success','2024-07-10 17:54:34','Kashmeera','2024-07-10 17:54:34','Mansi',1),(1669,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-10 17:54:34','2024-07-10 17:54:34','Unprocessed','success','2024-07-10 17:54:34','Kashmeera','2024-07-10 17:54:34','Mansi',2),(1670,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-10 17:54:34','2024-07-10 17:54:34','processed','success','2024-07-10 17:54:34','Kashmeera','2024-07-10 17:54:34','Mansi',3),(1671,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-10 17:54:43','2024-07-10 17:54:43','processed','success','2024-07-10 17:54:43','Kashmeera','2024-07-10 17:54:43','Mansi',1),(1672,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-10 17:54:43','2024-07-10 17:54:43','Unprocessed','success','2024-07-10 17:54:43','Kashmeera','2024-07-10 17:54:43','Mansi',2),(1673,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-10 17:54:43','2024-07-10 17:54:43','processed','success','2024-07-10 17:54:43','Kashmeera','2024-07-10 17:54:43','Mansi',3),(1674,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-11 11:23:44','2024-07-11 11:23:44','processed','success','2024-07-11 11:23:44','Kashmeera','2024-07-11 11:23:44','Mansi',1),(1675,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-11 11:23:44','2024-07-11 11:23:44','Unprocessed','success','2024-07-11 11:23:44','Kashmeera','2024-07-11 11:23:44','Mansi',2),(1676,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-11 11:23:44','2024-07-11 11:23:44','processed','success','2024-07-11 11:23:44','Kashmeera','2024-07-11 11:23:44','Mansi',3),(1677,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-11 14:01:09','2024-07-11 14:01:09','processed','success','2024-07-11 14:01:09','Kashmeera','2024-07-11 14:01:09','Mansi',1),(1678,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-11 14:01:09','2024-07-11 14:01:09','Unprocessed','success','2024-07-11 14:01:09','Kashmeera','2024-07-11 14:01:09','Mansi',2),(1679,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-11 14:01:09','2024-07-11 14:01:09','processed','success','2024-07-11 14:01:09','Kashmeera','2024-07-11 14:01:09','Mansi',3),(1680,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-11 16:51:15','2024-07-11 16:51:15','processed','success','2024-07-11 16:51:15','Kashmeera','2024-07-11 16:51:15','Mansi',1),(1681,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-11 16:51:15','2024-07-11 16:51:15','Unprocessed','success','2024-07-11 16:51:15','Kashmeera','2024-07-11 16:51:15','Mansi',2),(1682,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-11 16:51:15','2024-07-11 16:51:15','processed','success','2024-07-11 16:51:15','Kashmeera','2024-07-11 16:51:15','Mansi',3),(1683,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-12 12:38:43','2024-07-12 12:38:43','processed','success','2024-07-12 12:38:43','Kashmeera','2024-07-12 12:38:43','Mansi',1),(1684,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-12 12:38:43','2024-07-12 12:38:43','Unprocessed','success','2024-07-12 12:38:43','Kashmeera','2024-07-12 12:38:43','Mansi',2),(1685,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-12 12:38:43','2024-07-12 12:38:43','processed','success','2024-07-12 12:38:43','Kashmeera','2024-07-12 12:38:43','Mansi',3),(1686,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-15 13:26:13','2024-07-15 13:26:13','processed','success','2024-07-15 13:26:13','Kashmeera','2024-07-15 13:26:13','Mansi',1),(1687,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-15 13:26:13','2024-07-15 13:26:13','Unprocessed','success','2024-07-15 13:26:13','Kashmeera','2024-07-15 13:26:13','Mansi',2),(1688,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-15 13:26:13','2024-07-15 13:26:13','processed','success','2024-07-15 13:26:13','Kashmeera','2024-07-15 13:26:13','Mansi',3),(1689,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-15 15:59:13','2024-07-15 15:59:13','processed','success','2024-07-15 15:59:13','Kashmeera','2024-07-15 15:59:13','Mansi',1),(1690,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-15 15:59:13','2024-07-15 15:59:13','Unprocessed','success','2024-07-15 15:59:13','Kashmeera','2024-07-15 15:59:13','Mansi',2),(1691,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-15 15:59:13','2024-07-15 15:59:13','processed','success','2024-07-15 15:59:13','Kashmeera','2024-07-15 15:59:13','Mansi',3),(1692,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-15 16:09:22','2024-07-15 16:09:22','processed','success','2024-07-15 16:09:22','Kashmeera','2024-07-15 16:09:22','Mansi',1),(1693,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-15 16:09:22','2024-07-15 16:09:22','Unprocessed','success','2024-07-15 16:09:22','Kashmeera','2024-07-15 16:09:22','Mansi',2),(1694,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-15 16:09:22','2024-07-15 16:09:22','processed','success','2024-07-15 16:09:22','Kashmeera','2024-07-15 16:09:22','Mansi',3),(1695,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-15 16:19:20','2024-07-15 16:19:20','processed','success','2024-07-15 16:19:20','Kashmeera','2024-07-15 16:19:20','Mansi',1),(1696,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-15 16:19:20','2024-07-15 16:19:20','Unprocessed','success','2024-07-15 16:19:20','Kashmeera','2024-07-15 16:19:20','Mansi',2),(1697,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-15 16:19:20','2024-07-15 16:19:20','processed','success','2024-07-15 16:19:20','Kashmeera','2024-07-15 16:19:20','Mansi',3),(1698,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-18 15:29:16','2024-07-18 15:29:16','processed','success','2024-07-18 15:29:16','Kashmeera','2024-07-18 15:29:16','Mansi',1),(1699,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-18 15:29:16','2024-07-18 15:29:16','processed','success','2024-07-18 15:29:16','Kashmeera','2024-07-18 15:29:16','Mansi',1),(1700,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-18 15:29:16','2024-07-18 15:29:16','Unprocessed','success','2024-07-18 15:29:16','Kashmeera','2024-07-18 15:29:16','Mansi',2),(1701,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-18 15:29:16','2024-07-18 15:29:16','Unprocessed','success','2024-07-18 15:29:16','Kashmeera','2024-07-18 15:29:16','Mansi',2),(1702,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-18 15:29:16','2024-07-18 15:29:16','processed','success','2024-07-18 15:29:16','Kashmeera','2024-07-18 15:29:16','Mansi',3),(1703,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-18 15:29:16','2024-07-18 15:29:16','processed','success','2024-07-18 15:29:16','Kashmeera','2024-07-18 15:29:16','Mansi',3),(1704,1,2,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-18 15:45:05','2024-07-18 15:45:05','processed','success','2024-07-18 15:45:05','Kashmeera','2024-07-18 15:45:05','Mansi',1),(1705,1,3,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-18 15:45:05','2024-07-18 15:45:05','Unprocessed','success','2024-07-18 15:45:05','Kashmeera','2024-07-18 15:45:05','Mansi',2),(1706,1,1,101,'Motor fleet Process','PriyankaYadav',211,'2024-07-18 15:45:05','2024-07-18 15:45:05','processed','success','2024-07-18 15:45:05','Kashmeera','2024-07-18 15:45:05','Mansi',3);
/*!40000 ALTER TABLE `tbl_realtimedata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_rolemst`
--

DROP TABLE IF EXISTS `tbl_rolemst`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_rolemst` (
  `role_id` int NOT NULL,
  `name` varchar(45) NOT NULL,
  `CreatedDate` timestamp NULL DEFAULT NULL,
  `CreatedBy` varchar(100) DEFAULT NULL,
  `UpdatedDate` timestamp NULL DEFAULT NULL,
  `UpdatedBy` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_rolemst`
--

LOCK TABLES `tbl_rolemst` WRITE;
/*!40000 ALTER TABLE `tbl_rolemst` DISABLE KEYS */;
INSERT INTO `tbl_rolemst` VALUES (1,'USER','2024-02-27 06:02:22','Kiran','2024-02-27 06:02:22','Kiran'),(2,'ADMIN','2024-02-27 06:03:06','Clover','2024-02-27 06:03:06','Clover');
/*!40000 ALTER TABLE `tbl_rolemst` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(50) NOT NULL,
  `role_id` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'vaibhav.dhokate@cloverinfotech.com','123','user',0),(2,'dhoktevaibhav@mail.com','123','user',0),(3,'dhoktevaibhav1234@gmail.com','123','user',0),(4,'vaibhav.dhokate@cloverinfotech.com','123','admin',0),(5,'vaibhav.dhokate@cloverinfotech.com','123','admin',0),(6,'vaibhav.dhokate@cloverinfotech.com','123','admin',0),(7,'dhoktevaibhavmail.com','123','admin',0),(8,'vaibhav','123','user',0),(9,'vaibhavdhokate','123','user',0),(10,'vaibhav.dhokate@cloverinfotech.com','123','admin',0),(11,'vaibhav','123','user',0);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_bot_names`
--

DROP TABLE IF EXISTS `user_bot_names`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_bot_names` (
  `user_id` bigint NOT NULL,
  `bot_names` varchar(255) DEFAULT NULL,
  KEY `FKgulupw5lfdjfp5bccc2y41roi` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_bot_names`
--

LOCK TABLES `user_bot_names` WRITE;
/*!40000 ALTER TABLE `user_bot_names` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_bot_names` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_bot_names1`
--

DROP TABLE IF EXISTS `user_bot_names1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_bot_names1` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `bot_names` varchar(255) DEFAULT NULL,
  KEY `fk_user_bot_login` (`user_id`),
  CONSTRAINT `fk_user_bot_login` FOREIGN KEY (`user_id`) REFERENCES `login` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_bot_names1`
--

LOCK TABLES `user_bot_names1` WRITE;
/*!40000 ALTER TABLE `user_bot_names1` DISABLE KEYS */;
INSERT INTO `user_bot_names1` VALUES (1,'TradeQuery'),(2,'policyData'),(3,'TradeQuery'),(4,'policyData'),(5,'TradeQuery');
/*!40000 ALTER TABLE `user_bot_names1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_department_names`
--

DROP TABLE IF EXISTS `user_department_names`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_department_names` (
  `user_id` bigint NOT NULL,
  `department_names` varchar(255) DEFAULT NULL,
  KEY `FKcsb4yl7vd6rnc5n39k3mvfliv` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_department_names`
--

LOCK TABLES `user_department_names` WRITE;
/*!40000 ALTER TABLE `user_department_names` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_department_names` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_department_names1`
--

DROP TABLE IF EXISTS `user_department_names1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_department_names1` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `department_names` varchar(255) DEFAULT NULL,
  KEY `fk_user_department_login` (`user_id`),
  CONSTRAINT `fk_user_department_login` FOREIGN KEY (`user_id`) REFERENCES `login` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_department_names1`
--

LOCK TABLES `user_department_names1` WRITE;
/*!40000 ALTER TABLE `user_department_names1` DISABLE KEYS */;
INSERT INTO `user_department_names1` VALUES (1,'Coe'),(2,'Finance'),(3,'Sales'),(4,'Finance'),(5,'Sales');
/*!40000 ALTER TABLE `user_department_names1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_location_names`
--

DROP TABLE IF EXISTS `user_location_names`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_location_names` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `location_names` varchar(255) DEFAULT NULL,
  KEY `fk_user_location_login` (`user_id`),
  CONSTRAINT `FK3q6alrx9h0bk4vblm7db1ts8g` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  CONSTRAINT `fk_user_location_login` FOREIGN KEY (`user_id`) REFERENCES `login` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_location_names`
--

LOCK TABLES `user_location_names` WRITE;
/*!40000 ALTER TABLE `user_location_names` DISABLE KEYS */;
INSERT INTO `user_location_names` VALUES (1,'Panvel'),(2,'Kurla'),(3,'Kurla'),(4,'Panvel'),(5,'Andheri');
/*!40000 ALTER TABLE `user_location_names` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vaibhav`
--

DROP TABLE IF EXISTS `vaibhav`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vaibhav` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Value` varchar(50) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vaibhav`
--

LOCK TABLES `vaibhav` WRITE;
/*!40000 ALTER TABLE `vaibhav` DISABLE KEYS */;
/*!40000 ALTER TABLE `vaibhav` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vaibhavdemo`
--

DROP TABLE IF EXISTS `vaibhavdemo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vaibhavdemo` (
  `name` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vaibhavdemo`
--

LOCK TABLES `vaibhavdemo` WRITE;
/*!40000 ALTER TABLE `vaibhavdemo` DISABLE KEYS */;
INSERT INTO `vaibhavdemo` VALUES ('Asif'),('Farhan');
/*!40000 ALTER TABLE `vaibhavdemo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `values`
--

DROP TABLE IF EXISTS `values`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `values` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Value` varchar(50) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `values`
--

LOCK TABLES `values` WRITE;
/*!40000 ALTER TABLE `values` DISABLE KEYS */;
/*!40000 ALTER TABLE `values` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'automation4'
--
/*!50003 DROP PROCEDURE IF EXISTS `BotNamedQuery_BotNameInsertStoreProcedure` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE PROCEDURE `BotNamedQuery_BotNameInsertStoreProcedure`( 
                                    in pbotNames varchar(100)
									)
begin	
    START TRANSACTION;
	
		INSERT INTO user_bot_names1
								( 
								 bot_names)
					VALUES     (pbotNames
								 );
        commit;
  end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `BotNamedQuery_BotNameUpdateStoreProcedure` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE PROCEDURE `BotNamedQuery_BotNameUpdateStoreProcedure`( 
					               in p_id int, 
                                    in pbotNames varchar(100)
									)
begin	
    START TRANSACTION;
	   UPDATE  user_bot_names1
        SET 
            bot_names = pbotNames
        WHERE user_id = p_id;
        commit;
  end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `DepartmentNamedQuery_DepartmentNameInsertStoreProcedure` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE PROCEDURE `DepartmentNamedQuery_DepartmentNameInsertStoreProcedure`( 
                                    in pdepartmentNames varchar(100)
									)
begin	
    START TRANSACTION;
	
		INSERT INTO user_department_names1
								( department_names)
					VALUES     (pdepartmentNames);
        commit;
  end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `DepartmentNamedQuery_DepartmentNameUpdateStoreProcedure` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE PROCEDURE `DepartmentNamedQuery_DepartmentNameUpdateStoreProcedure`( 
                                    in p_id int, 
                                    in pdepartmentNames varchar(100)
									)
begin	
    START TRANSACTION;
        UPDATE user_department_names1
        SET 
            department_names = pdepartmentNames
        WHERE user_id = p_id;
        commit;
  end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getlocation` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE PROCEDURE `getlocation`()
BEGIN
  select * from tbl_location;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_BotDetails` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE PROCEDURE `get_BotDetails`()
begin
select * from tbl_botname;

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_ChartData_Tbl_RealTimeBind` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE PROCEDURE `get_ChartData_Tbl_RealTimeBind`(In pLocationId int, In pDepartmentId int, In pBotId int)
begin
Select count(case when (botId = pBotId  or DepartmentId = pDepartmentId  or LocationId=pLocationId )  then 1 else null end)as total_Bot_count,
 count(case when  ( botId = pBotId and Status = 'processed')  OR ( DepartmentId = pDepartmentId and Status = 'processed') OR ( LocationId = pLocationId and Status = 'processed')   then 1 else null end) as Processed,
 count(case when ( botId = pBotId and Status = 'unprocessed') OR ( DepartmentId = pDepartmentId and Status = 'unprocessed') OR ( LocationId = pLocationId and Status = 'unprocessed')then 1 else null end) as Unprocessed
 /*count(case when product='B' and amount>200 then 1 else null end) as B_count*/
 from tbl_realtimedata;


 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_TblBotName1` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE PROCEDURE `get_TblBotName1`()
BEGIN
	Select  B.BotId,B.BotName,B.CreatedDate from tbl_botname B;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_TblDepartment` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE PROCEDURE `get_TblDepartment`()
BEGIN
	Select  D.DepartmentId,D.DepartmentName from tbl_department D;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_Tbllocation1` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE PROCEDURE `get_Tbllocation1`()
BEGIN

	Select  L.LocationId,L.LocationName from tbl_location L;	
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_Tblloginmodel` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE PROCEDURE `get_Tblloginmodel`(in iUserId int)
BEGIN
    SELECT 
        L.id,
        L.username,
        L.role,
        ubn.bot_names,
        dept.department_names,
        location.location_names
    FROM 
        login L
    LEFT JOIN 
        user_bot_names1 ubn ON L.id = ubn.user_id
    LEFT JOIN 
        user_department_names1 dept ON L.id = dept.user_id
    LEFT JOIN 
        user_location_names location ON L.id = location.user_id
        WHERE 
        L.id=iUserId;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_TblRolemst` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE PROCEDURE `get_TblRolemst`()
BEGIN

	Select  R.role_id, R.name from tbl_rolemst R;	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_Tbl_RealTimeBind` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE PROCEDURE `get_Tbl_RealTimeBind`(In pLocationId int, In pDepartmentId int, In pBotId int)
begin
select * from tbl_realtimedata where LocationId = pLocationId and DepartmentId= pDepartmentId and BotId= pBotId and status= 'process'; 
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_Tbl_RealTimeBind1` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE PROCEDURE `get_Tbl_RealTimeBind1`(In pLocationId int, In pDepartmentId int, In pBotId int)
BEGIN
	Select  ProcessId, B.BotName,L.LocationName,DepartmentName,Process_Name,R.Status,R.Remarks,R.CreatedBy from tbl_realtimedata R join tbl_location L
	on R.LocationId = L.LocationId join tbl_botname B on B.botId = R.BotId
	join tbl_department D on D.DepartmentId = R.DepartmentId
    where R.LocationId = pLocationId and R.DepartmentId= pDepartmentId and R.BotId= pBotId and status= 'process'; 
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_Tbl_RealTimeBindData2` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE PROCEDURE `get_Tbl_RealTimeBindData2`(
    IN pLocationId INT,
    IN pDepartmentId INT,
    IN pBotId INT,
    IN pType VARCHAR(100),
    IN pSearch VARCHAR(100)
)
BEGIN
    DECLARE v_sql VARCHAR(4000);
    DECLARE v_sql_full VARCHAR(4000);

    SET v_sql = 'SELECT 
                    ProcessId, 
                    B.BotName,
                    L.LocationName,
                    D.DepartmentName,
                    Process_Name,
                    R.Status,
                    R.Remarks,
                    R.CreatedBy,
                    StartTime
                 FROM 
                    tbl_realtimedata R
                    JOIN tbl_location L ON L.LocationId = R.LocationId
                    JOIN tbl_botname B ON B.BotId = R.BotId
                    JOIN tbl_department D ON D.DepartmentId = R.DepartmentId
                 WHERE 1=1';

    -- Apply combined condition for BotId and DepartmentId
    IF pBotId != 0 AND pDepartmentId != 0 THEN
        SET v_sql = CONCAT(v_sql, ' AND R.BotId = ', pBotId, ' AND R.DepartmentId = ', pDepartmentId);
    END IF;

   IF pBotId != 0 AND pDepartmentId != 0 AND pLocationId !=0 THEN
        SET v_sql = CONCAT(v_sql, ' AND R.BotId = ', pBotId, ' AND R.DepartmentId = ', pDepartmentId,' AND R.LocationId = ',pLocationId);
    END IF;

    -- Apply condition for BotId if not zero
    IF pBotId IS NOT NULL AND pBotId != 0 THEN
        SET v_sql = CONCAT(v_sql, ' AND R.BotId = ', pBotId);
    END IF;

    -- Apply condition for DepartmentId if not zero
    IF pDepartmentId IS NOT NULL AND pDepartmentId != 0 THEN
        SET v_sql = CONCAT(v_sql, ' AND R.DepartmentId = ', pDepartmentId);
    END IF;

    -- Apply condition for LocationId if not zero
    IF pLocationId IS NOT NULL AND pLocationId != 0 THEN
        SET v_sql = CONCAT(v_sql, ' AND R.LocationId = ', pLocationId);
    END IF;


    SET @v_sql_full = v_sql;

    PREPARE stmt FROM @v_sql_full;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_Tbl_RealTimeBindData3` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE PROCEDURE `get_Tbl_RealTimeBindData3`()
BEGIN
	Select  ProcessId, B.BotName,L.LocationName,DepartmentName,Process_Name,R.Status,R.Remarks,R.CreatedBy from tbl_realtimedata R join tbl_location L
	on R.LocationId = L.LocationId join tbl_botname B on B.botId = R.BotId
	join tbl_department D on D.DepartmentId = R.DepartmentId;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_tbl_realtimedata` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE PROCEDURE `get_tbl_realtimedata`(In pLocationId int, In pDepartmentId int, In pBotId int, OUT processcount int)
begin
select count(processId) from tbl_realtimedata where LocationId = pLocationId and DepartmentId= pDepartmentId and BotId= pBotId and status= 'process' into processcount;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `InsertDataFromJson` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE PROCEDURE `InsertDataFromJson`(json_data JSON)
BEGIN
  Select json_data;
  INSERT INTO Kusers (id, Nname, email) 
  SELECT id, Nname, email
  FROM JSON_TABLE(json_data, '$[*]' COLUMNS (
    id INT PATH '$.id',
    Nname VARCHAR(255) PATH '$.Nname',
    email VARCHAR(255) PATH '$.email'
  )) AS data;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `locationNamedQuery_NameInsertStoreProcedure` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE PROCEDURE `locationNamedQuery_NameInsertStoreProcedure`( 
                                    in plocationNames varchar(100)
									)
begin	
    START TRANSACTION;
	
		INSERT INTO user_location_names
								( 
								 location_names)
					VALUES     (plocationNames
								 );
        commit;
  end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `locationNamedQuery_NameUpdateStoreProcedure` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE PROCEDURE `locationNamedQuery_NameUpdateStoreProcedure`(
                                    in p_id int, 
                                    in plocationNames varchar(100)
)
begin	
    START TRANSACTION;
        UPDATE user_location_names
        SET 
            location_names = plocationNames
        WHERE user_id = p_id;
        commit;
  end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `PrintHi` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE PROCEDURE `PrintHi`()
BEGIN
    SELECT 'hi' AS message;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `PrintHiii` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE PROCEDURE `PrintHiii`()
BEGIN
    SELECT 'hi' AS message;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ReturnInputParameters` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE PROCEDURE `ReturnInputParameters`(
    IN p_ProcessId1 INT,
    IN p_BotId1 VARCHAR(255),
    IN p_DepartmentId1 VARCHAR(255),
    IN p_LocationId1 VARCHAR(255),
    IN p_Transaction_ID1 INT,
    IN p_Process_Name1 VARCHAR(255),
    IN p_Host_Name1 VARCHAR(255),
    IN p_CreatedBy1 VARCHAR(255),
    IN p_Status1 VARCHAR(255),
    IN p_Remarks1 VARCHAR(255)
)
BEGIN
    SELECT p_ProcessId1 AS ProcessId,
           p_BotId1 AS BotId,
           p_DepartmentId1 AS DepartmentId,
           p_LocationId1 AS LocationId,
           p_Transaction_ID1 AS Transaction_ID,
           p_Process_Name1 AS Process_Name,
           p_Host_Name1 AS Host_Name,
           p_CreatedBy1 AS CreatedBy,
           p_Status1 AS Status,
           p_Remarks1 AS Remarks;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Usp_BotDuration` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE PROCEDURE `Usp_BotDuration`( in Botname varchar(100))
BEGIN
	Select  BotId,Duration,BotName from tbl_botname where BotName=Botname limit 1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Usp_Delete_BotName` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE PROCEDURE `Usp_Delete_BotName`(
    IN p_BotId INT
)
BEGIN
    DELETE FROM tbl_botname WHERE BotId = p_BotId LIMIT 1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Usp_Delete_Location` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE PROCEDURE `Usp_Delete_Location`(IN p_LocationId INT)
BEGIN
    DELETE FROM tbl_location WHERE LocationId = p_LocationId Limit 1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Usp_Delete_tbl_department` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE PROCEDURE `Usp_Delete_tbl_department`(IN p_DepartmentId INT)
BEGIN
    DELETE FROM tbl_department WHERE DepartmentId = p_DepartmentId  LIMIT 1 ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Usp_Delete_User` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE PROCEDURE `Usp_Delete_User`(
    IN p_BotId INT
)
BEGIN
    DELETE FROM login WHERE id = p_BotId LIMIT 1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Usp_DepartmentbtMst` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE PROCEDURE `Usp_DepartmentbtMst`()
begin
select DepartmentId, DepartmentName, CreatedDate, CreatedBy, UpdatedDate, UpdatedBy, IsActive from tbl_department where isActive = 1;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Usp_EditDepartment` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE PROCEDURE `Usp_EditDepartment`( in iDepartmentId int)
Begin
Select DepartmentId,DepartmentName,CreatedDate,CreatedBy,UpdatedDate,UpdatedBy,IsActive from tbl_department where DepartmentId = iDepartmentId;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Usp_EditLocation` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE PROCEDURE `Usp_EditLocation`( in iLocationId int)
Begin
Select LocationId,LocationName,CreatedDate,CreatedBy,UpdatedDate,UpdatedBy,IsActive from tbl_location where LocationId = iLocationId;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Usp_get_BotData` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE PROCEDURE `Usp_get_BotData`(in iBotid int)
Begin
select BotId, BotName, LocationId, DepartmentId ,CreatedBy, UpdatedBy,IsActive from tbl_botname where BotId=iBotId;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Usp_get_UserData` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE PROCEDURE `Usp_get_UserData`(in iUserid int)
Begin
 SELECT 
	
        L.username,
        L.role,
        ubn.bot_names,
        dept.department_names,
        location.location_names
    FROM 
        login L
    LEFT JOIN 
        user_bot_names1 ubn ON L.id = ubn.user_id
    LEFT JOIN 
        user_department_names1 dept ON L.id = dept.user_id
    LEFT JOIN 
        user_location_names location ON L.id = location.user_id
        WHERE 
        L.id=iUserid;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Usp_InsertExcel_Bot` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE PROCEDURE `Usp_InsertExcel_Bot`(
									in LocationId int, 
                                    in DepartmentId int,
									 in BotName varchar(100),
									 in CreatedDate datetime,
									 in CreatedBy varchar(100),
									 in UpdatedDate datetime,
									 in	UpdatedBy varchar(100),
									 in IsActive boolean)
begin
INSERT INTO tbl_botname
                        (
                        LocationId, 
                        DepartmentId,
						 BotName,
						 CreatedDate,
						 CreatedBy,
						 UpdatedDate,
						 UpdatedBy,
						 IsActive)
            VALUES     (
						LocationId, 
                        DepartmentId,
						 BotName,
						 CreatedDate,
						 CreatedBy,
						 UpdatedDate,
						 UpdatedBy,
						 IsActive);
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Usp_InsertExcel_Department` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE PROCEDURE `Usp_InsertExcel_Department`(
									in department_id int, 
                                  
									 in DepartmentName varchar(100),
									 in CreatedDate datetime,
									 in CreatedBy varchar(100),
									 in UpdatedDate datetime,
									 in	UpdatedBy varchar(100),
									 in IsActive boolean)
begin
INSERT INTO tbl_department
                        (
                        department_id, 
                        
						 DepartmentName,
						 CreatedDate,
						 CreatedBy,
						 UpdatedDate,
						 UpdatedBy,
						 IsActive)
            VALUES     (
						department_id, 
                       
						 DepartmentName,
						 CreatedDate,
						 CreatedBy,
						 UpdatedDate,
						 UpdatedBy,
						 IsActive);
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Usp_InsertExcel_Location` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE PROCEDURE `Usp_InsertExcel_Location`(in id int, 
									in location_id int, 
                                    in p_Location_Id int,
									 in LocationName varchar(100),
									 in CreatedDate datetime,
									 in CreatedBy varchar(100),
									 in UpdatedDate datetime,
									 in	UpdatedBy varchar(100),
									 in IsActive boolean)
begin
INSERT INTO tbl_location
                        (id,
                        location_id, 
                        
						 LocationName,
						 CreatedDate,
						 CreatedBy,
						 UpdatedDate,
						 UpdatedBy,
						 IsActive)
            VALUES     (id,
						location_id, 
                       
						 LocationName,
						 CreatedDate,
						 CreatedBy,
						 UpdatedDate,
						 UpdatedBy,
						 IsActive);
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Usp_InsertExcel_Realtimedata` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE PROCEDURE `Usp_InsertExcel_Realtimedata`(
    IN p_ProcessId INT,
    IN p_BotId INT,
    IN p_DepartmentId INT,
    IN p_LocationId INT,
    IN p_Process_Name VARCHAR(255),
    IN p_Host_Name VARCHAR(255),
    IN p_Transaction_ID INT,
    IN p_Status VARCHAR(255),
    IN p_Remarks VARCHAR(255),
    IN p_CreatedBy VARCHAR(255),
    IN p_UpdatedBy VARCHAR(255),
    IN p_IsActive INT
)
BEGIN
    -- Insert logic with LIMIT clause
    INSERT INTO tbl_realtimedata (
       
        BotId,
        DepartmentId,
        LocationId,
        Process_Name,
        Host_Name,
        Transaction_ID,
        StartTime,
        EndTime,
        Status,
        Remarks,
        CreatedDate,
        CreatedBy,
        UpdatedDate,
        UpdatedBy,
        IsActive
    ) 
    SELECT 
       
        p_BotId,
        p_DepartmentId,
        p_LocationId,
        p_Process_Name,
        p_Host_Name,
        p_Transaction_ID,
        current_timestamp(),
        current_timestamp(),
        p_Status,
        p_Remarks,
        current_timestamp(),
        p_CreatedBy,
        current_timestamp(),
        p_UpdatedBy,
        p_IsActive
    FROM 
        dual  -- dual is a dummy table in MySQL, you can use it to insert a single row
    LIMIT 1;  -- Limit the number of rows inserted to 1
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Usp_Insert_BotName1` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE PROCEDURE `Usp_Insert_BotName1`(
                                 in BotName varchar(100),
									in LocationId  int, 
									in DepartmentId int, 								
									in CreatedBy varchar(100),
									
									in UpdatedBy varchar(100),

                                    IN IsActive BOOLEAN,
                                    IN ActionType NVARCHAR(20)
									)
begin	
    START TRANSACTION;
	If ActionType = 'Insert' then
		INSERT INTO tbl_botname
								( 
								 BotName,
								 LocationId, 
								 DepartmentId, 
								 CreatedDate,
								 CreatedBy,
								 UpdatedDate,
								 UpdatedBy,
								 IsActive)
					VALUES     (
								 BotName,
								 LocationId, 
								 DepartmentId, 
								 current_timestamp(),
								 CreatedBy,
								 current_timestamp(),
								 UpdatedBy,
								 true);
		ElseIf  ActionType ='Update' then
			UPDATE  Tbl_BotName
					Set	 
					     BotName = BotName,
						 LocationId =LocationId, 
						 DepartmentId = DepartmentId, 
						 CreatedDate = current_timestamp(),
						 CreatedBy = CreatedBy,
						 UpdatedDate = current_timestamp(),
						 UpdatedBy = UpdatedBy,
						 IsActive = true
				where  BotId = BotId ;
		else
			Delete from Tbl_BotName where BotId = BotId;
		end if;
        commit;
  end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Usp_Insert_Department` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE PROCEDURE `Usp_Insert_Department`(
                                       IN DepartmentName VARCHAR(100),
                                       IN CreatedDate DATETIME,
                                       IN CreatedBy VARCHAR(100),
                                       IN UpdatedDate DATETIME,
                                       IN UpdatedBy VARCHAR(100),
                                       IN IsActive BOOLEAN,
                                       IN typecal NVARCHAR(20))
BEGIN
    IF typecal = 'INSERT' THEN
        BEGIN
            INSERT INTO tbl_department
                        (
                         DepartmentName,
                         CreatedDate,
                         CreatedBy,
                         UpdatedDate,
                         UpdatedBy,
                         IsActive)
            VALUES      (
                          DepartmentName,
                          CreatedDate,
                          CreatedBy,
                          UpdatedDate,
                          UpdatedBy,
                          IsActive);
        END;
    END IF;

    IF typecal = 'UPDATE' THEN
        BEGIN
            UPDATE tbl_department
            SET    DepartmentName = DepartmentName,
                   CreatedDate = CreatedDate,
                   CreatedBy = CreatedBy,
                   UpdatedDate = UpdatedDate,
                   UpdatedBy = UpdatedBy,
                   IsActive = IsActive
            WHERE  DepartmentId = DepartmentId;
        END;
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Usp_Insert_Department1` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE PROCEDURE `Usp_Insert_Department1`(IN department_id int,
                                       IN DepartmentName VARCHAR(100),
                                       IN CreatedDate DATETIME,
                                       IN CreatedBy VARCHAR(100),
                                       IN UpdatedDate DATETIME,
                                       IN UpdatedBy VARCHAR(100),
                                       IN IsActive BOOLEAN,
                                       IN typecal NVARCHAR(20))
BEGIN
    IF typecal = 'INSERT' THEN
        BEGIN
            INSERT INTO tbl_department
                        (department_id,
                         DepartmentName,
                         CreatedDate,
                         CreatedBy,
                         UpdatedDate,
                         UpdatedBy,
                         IsActive)
            VALUES      (department_id,
                          DepartmentName,
                          CreatedDate,
                          CreatedBy,
                          UpdatedDate,
                          UpdatedBy,
                          IsActive);
        END;
    END IF;

    IF typecal = 'UPDATE' THEN
        BEGIN
            UPDATE tbl_department
            SET   department_id=department_id,
            DepartmentName = DepartmentName,
                   CreatedDate = CreatedDate,
                   CreatedBy = CreatedBy,
                   UpdatedDate = UpdatedDate,
                   UpdatedBy = UpdatedBy,
                   IsActive = IsActive
            WHERE  DepartmentId = DepartmentId;
        END;
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Usp_Insert_Location` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE PROCEDURE `Usp_Insert_Location`(in id int, 
									in location_id int, 
									 in LocationName varchar(100),
									 in CreatedDate datetime,
									 in CreatedBy varchar(100),
									 in UpdatedDate datetime,
									 in	UpdatedBy varchar(100),
									 in IsActive boolean)
begin
INSERT INTO tbl_location
                        (id,
                        location_id, 
						 LocationName,
						 CreatedDate,
						 CreatedBy,
						 UpdatedDate,
						 UpdatedBy,
						 IsActive)
            VALUES     (id,
						location_id, 
						 LocationName,
						 CreatedDate,
						 CreatedBy,
						 UpdatedDate,
						 UpdatedBy,
						 IsActive);
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Usp_Insert_Location1` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE PROCEDURE `Usp_Insert_Location1`(in LocationId int,
                                    in id int, 
									in location_id int, 
									 in LocationName varchar(100),
									 in CreatedDate datetime,
									 in CreatedBy varchar(100),
									 in UpdatedDate datetime,
									 in	UpdatedBy varchar(100),
									 in IsActive boolean,
                                     in ActionType NVARCHAR(20))
begin	
    START TRANSACTION;
	If ActionType = 'Insert' then
		INSERT INTO tbl_location
                        (id,
                        location_id, 
						 LocationName,
						 CreatedDate,
						 CreatedBy,
						 UpdatedDate,
						 UpdatedBy,
						 IsActive)
            VALUES     (id,
						location_id, 
						 LocationName,
						 CreatedDate,
						 CreatedBy,
						 UpdatedDate,
						 UpdatedBy,
						 IsActive);
else
			Delete from tbl_location where LocationId = LocationId;
		end if;
        commit;
  end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Usp_Insert_Location2` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE PROCEDURE `Usp_Insert_Location2`(
                                    in id int, 
									in location_id int, 
									 in LocationName varchar(100),
									 in CreatedDate datetime,
									 in CreatedBy varchar(100),
									 in UpdatedDate datetime,
									 in	UpdatedBy varchar(100),
									 in IsActive boolean,
                                     in ActionType NVARCHAR(20))
begin	
    START TRANSACTION;
	If ActionType = 'Insert' then
		INSERT INTO tbl_location
                        (id,
                        location_id, 
						 LocationName,
						 CreatedDate,
						 CreatedBy,
						 UpdatedDate,
						 UpdatedBy,
						 IsActive)
            VALUES     (id,
						location_id, 
						 LocationName,
						 CreatedDate,
						 CreatedBy,
						 UpdatedDate,
						 UpdatedBy,
						 IsActive);
else
			Delete from tbl_location where LocationName = LocationName;
		end if;
        commit;
  end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Usp_Insert_RealTimeData` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE PROCEDURE `Usp_Insert_RealTimeData`(in ProcessId int,
                                         in BotId int,
                                         in DepartmentId int,
                                         LocationId int,
										 in Process_Name varchar(100),
										 in Host_Name varchar(100),
										 in Transaction_ID int,
										 in StartTime Datetime,
										 in EndTime Datetime ,
										 in Status varchar(100),
                                         in Remarks varchar(100),
                                         in CreatedDate Datetime,
                                         in CreatedBy varchar(100),
                                         in UpdatedDate datetime,
                                         in UpdatedBy varchar(100),
										 in IsActive Boolean )
begin
INSERT INTO tbl_realtimedata
                        ( ProcessId,
						  BotId,
						  DepartmentId,
                          LocationId,
						  Process_Name,
						  Host_Name,
						  Transaction_ID,
						  StartTime,
						  EndTime,
						  Status,
						  Remarks,
						  CreatedDate,
						  CreatedBy,
						  UpdatedDate,
						  UpdatedBy,
						  IsActive)
            VALUES     (ProcessId,
						  BotId,
						  DepartmentId,
                          LocationId,
						  Process_Name,
						  Host_Name,
						  Transaction_ID,
						  StartTime,
						  EndTime,
						  Status,
						  Remarks,
						  CreatedDate,
						  CreatedBy,
						  UpdatedDate,
						  UpdatedBy,
						  IsActive);

end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Usp_Insert_UserRegister` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE PROCEDURE `Usp_Insert_UserRegister`( 
                                    in username varchar(100),
									in password varchar(100), 
									in role_id varchar(100), 
									in CreatedBy varchar(100),									
									in UpdatedBy varchar(100),
                                    in retry_pass varchar(100),
                                    in ActionType nvarchar(20))
begin	
    START TRANSACTION;
	If ActionType = 'Insert' then
		INSERT INTO login
								( 
								 username,
								 password, 
								 role, 
                                 role_id,
								 CreatedDate,
								 CreatedBy,
								 UpdatedDate,
								 UpdatedBy,
								 retry_pass)
					VALUES     (
								 username,
								 password, 
								 role_id, 
                                 1,
								 current_timestamp(),
								 CreatedBy,
								 current_timestamp(),
								 UpdatedBy,
								 retry_pass);
		end if;
        commit;
  end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Usp_LocationMst1` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE PROCEDURE `Usp_LocationMst1`()
begin
select LocationId, LocationName, DATE_FORMAT(CreatedDate, "%M %d %Y") as CreatedDate, CreatedBy, DATE_FORMAT(UpdatedDate, "%M %d %Y") as UpdatedDate, UpdatedBy, IsActive from tbl_location;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Usp_LoginD` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE PROCEDURE `Usp_LoginD`(In pusername varchar(100), In ppassword varchar(100))
begin
 Select * from login where username=pusername and password=ppassword;
 End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Usp_MstBotDetail` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE PROCEDURE `Usp_MstBotDetail`()
Begin
Select BotId,BotName,L.LocationId,L.LocationName,D.DepartmentId,D.DepartmentName,DATE_FORMAT(B.CreatedDate, "%M %d %Y") as CreatedDate,
B.CreatedBy,DATE_FORMAT(B.UpdatedDate,"%M %d %Y") as UpdatedDate,B.UpdatedBy,B.IsActive from tbl_botname B join tbl_department D on B.DepartmentID = D.DepartmentId
join tbl_location L on B.LocationId = L.locationId;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Usp_MstDepartmentDetail1` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE PROCEDURE `Usp_MstDepartmentDetail1`()
Begin
Select DepartmentId,DepartmentName,DATE_FORMAT(CreatedDate, "%M %d %Y") as CreatedDate,CreatedBy,DATE_FORMAT(UpdatedDate,"%M %d %Y") as UpdatedDate,UpdatedBy,IsActive from tbl_department;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Usp_MstDepartment_Detail` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE PROCEDURE `Usp_MstDepartment_Detail`()
Begin
Select DepartmentId,DepartmentName,DATE_FORMAT(CreatedDate, "%M %d %Y") as CreatedDate,CreatedBy,DATE_FORMAT(UpdatedDate,"%M %d %Y") as UpdatedDate,UpdatedBy,IsActive from tbl_department;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Usp_Update_BotName` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE PROCEDURE `Usp_Update_BotName`(
     IN p_BotId MEDIUMINT,
    IN p_BotName VARCHAR(100),
    IN p_LocationId MEDIUMINT,
     IN p_DepartmentId MEDIUMINT,
    IN p_CreatedBy VARCHAR(100),
    IN p_UpdatedBy VARCHAR(100),
    IN p_IsActive BOOLEAN
   
)
BEGIN
    UPDATE tbl_botname
    SET
        BotName = p_BotName,
        LocationId= p_LocationId,
        DepartmentId=p_DepartmentId,
        CreatedDate = current_timestamp(),
        CreatedBy = p_CreatedBy,
        UpdatedDate = current_timestamp(),
        UpdatedBy = p_UpdatedBy,
        IsActive = p_IsActive
       
    WHERE
        BotId = p_BotId
    LIMIT 1;
    
    -- You can add additional logic or error handling here if needed
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Usp_Update_Department` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE PROCEDURE `Usp_Update_Department`(
    IN p_DepartmentId MEDIUMINT,
    IN p_DepartmentName VARCHAR(100),
    IN p_CreatedDate DATETIME,
    IN p_CreatedBy VARCHAR(100),
    IN p_UpdatedDate DATETIME,
    IN p_UpdatedBy VARCHAR(100),
    IN p_IsActive BOOLEAN
)
BEGIN
    UPDATE tbl_department
    SET
        DepartmentName = p_DepartmentName,
        CreatedDate = p_CreatedDate,
        CreatedBy = p_CreatedBy,
        UpdatedDate = p_UpdatedDate,
        UpdatedBy = p_UpdatedBy,
        IsActive = p_IsActive
    WHERE
        DepartmentId = p_DepartmentId
    LIMIT 1;
    
    -- You can add additional logic or error handling here if needed
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Usp_Update_Location` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE PROCEDURE `Usp_Update_Location`(
    IN p_LocationId INT,
    IN p_location_id INT,
    IN p_LocationName VARCHAR(255),
    IN p_CreatedBy VARCHAR(255),
    IN p_UpdatedBy VARCHAR(255),
    IN p_IsActive BOOLEAN
)
BEGIN
    UPDATE tbl_location
    SET
        location_id = p_LocationId,
        LocationName = p_LocationName,
        CreatedDate = current_timestamp(),
        CreatedBy = p_CreatedBy,
        UpdatedDate = current_timestamp(),
        UpdatedBy = p_UpdatedBy,
        IsActive = p_IsActive
    WHERE
        LocationId = p_LocationId
        LIMIT 1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Usp_Update_login` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE PROCEDURE `Usp_Update_login`(
   IN p_UserName VARCHAR(100),
  IN p_CreatedBy VARCHAR(100),
    IN p_UpdatedBy VARCHAR(100),
    IN Role VARCHAR(100),
    IN p_id INT
)
BEGIN
    UPDATE login
    SET
        username= p_UserName,
        CreatedDate = current_timestamp(),
        CreatedBy = p_CreatedBy,
        UpdatedDate = current_timestamp(),
        UpdatedBy = p_UpdatedBy,
        role = Role
       
    WHERE
        Id = p_id
    LIMIT 1;
    
    -- You can add additional logic or error handling here if needed
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Usp_Update_UserRegister` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE PROCEDURE `Usp_Update_UserRegister`( 
                                    in p_id int,
                                    in username varchar(100),
									in role_id varchar(100), 
									in CreatedBy varchar(100),									
									in UpdatedBy varchar(100),
                                    in ActionType nvarchar(20))
begin	
    START TRANSACTION;
	  IF ActionType = 'Update' THEN
        UPDATE login
        SET 
            username = username,
            role = role_id,
            CreatedBy = CreatedBy,
            UpdatedDate = CURRENT_TIMESTAMP(),
            UpdatedBy = UpdatedBy
        WHERE id = p_id;
		end if;
        commit;
  end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Usp_UserDetail` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE PROCEDURE `Usp_UserDetail`()
BEGIN

    SELECT 
        L.id, 
        L.username, 
        L.role, 
        DATE_FORMAT(L.CreatedDate, "%M %d %Y") AS CreatedDate,
        L.CreatedBy, 
        DATE_FORMAT(L.UpdatedDate, "%M %d %Y") AS UpdatedDate, 
        L.UpdatedBy
       
    FROM 
        login L
   
   ;
   
    
   

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `vaibhavStoredProcedure` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE PROCEDURE `vaibhavStoredProcedure`(IN ArrayDemo VARCHAR(100))
BEGIN
      SELECT * FROM vaibhavDemo  WHERE FIND_IN_SET(name, ArrayDemo);
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-21 11:40:53
