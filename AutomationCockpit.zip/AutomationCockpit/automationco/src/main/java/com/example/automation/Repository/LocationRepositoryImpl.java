package com.example.automation.Repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.StoredProcedureQuery;

import com.example.automation.Model.DashboardModel;

public interface LocationRepositoryImpl {
//	public class DashboardRepo implements LocationRepositoryImpl{
//		
//		@PersistenceContext
//		private DashboardModel _entityManager;
//		
//		@Override
//		//public List<DashboardModel> getLocation(){
//			//StoredProcedureQuery findAllLocation= _entityManager.createNamedStoredProcedureQuery("Usp_Tbl_Location");
//			//return findAllLocation.getResultList();
//		}
//	}

	//List<DashboardModel> getLocation();
	}
//}
