package com.example.automation.Domain;

import java.util.*;
public class DashboardDomain {
	
	private Long id;
    private String Location;
    
    public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUsername() {
		return Location;
	}

}
